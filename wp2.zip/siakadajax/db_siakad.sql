/*
SQLyog Community v12.4.3 (64 bit)
MySQL - 5.6.12-log : Database - db_siakad
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


/*Table structure for table `asal_sekolah` */

DROP TABLE IF EXISTS `asal_sekolah`;

CREATE TABLE `asal_sekolah` (
  `nim` varchar(20) DEFAULT NULL,
  `jurusan` varchar(30) DEFAULT NULL,
  `thn_lulus` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `asal_sekolah` */

/*Table structure for table `biodata_ortu` */

DROP TABLE IF EXISTS `biodata_ortu`;

CREATE TABLE `biodata_ortu` (
  `nim` varchar(20) DEFAULT NULL,
  `nm_ayah` varchar(50) DEFAULT NULL,
  `nm_ibu` varchar(50) DEFAULT NULL,
  `pekerjaan_ayah` varchar(50) DEFAULT NULL,
  `pekerjaan_ibu` varchar(50) DEFAULT NULL,
  `alamat_ortu` text,
  `penghasilan_ayah` varchar(30) DEFAULT NULL,
  `penghasilan_ibu` varchar(30) DEFAULT NULL,
  `nohp_ortu` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `biodata_ortu` */

/*Table structure for table `biodata_pribadi` */

DROP TABLE IF EXISTS `biodata_pribadi`;

CREATE TABLE `biodata_pribadi` (
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `jk` enum('Laki-laki','Perempuan') DEFAULT NULL,
  `agama` varchar(15) DEFAULT NULL,
  `tempat_lahir` varchar(50) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  `alamat` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `biodata_pribadi` */

/*Table structure for table `daftar_kp` */

DROP TABLE IF EXISTS `daftar_kp`;

CREATE TABLE `daftar_kp` (
  `id_daftar` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `tempat` varchar(100) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_daftar`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `daftar_kp` */

insert  into `daftar_kp`(`id_daftar`,`nim`,`tempat`,`id_prodi`) values 
(1,'1402126','PT. Sumber Kawan Lama',4);

/*Table structure for table `daftar_ulang` */

DROP TABLE IF EXISTS `daftar_ulang`;

CREATE TABLE `daftar_ulang` (
  `id_daftar_ulang` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `semester` int(3) DEFAULT NULL,
  `tahun_akademik` varchar(10) DEFAULT NULL,
  `id_prodi` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_daftar_ulang`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `daftar_ulang` */

insert  into `daftar_ulang`(`id_daftar_ulang`,`nim`,`nama`,`semester`,`tahun_akademik`,`id_prodi`) values 
(1,'1402126','Boy Kurniawan',3,'20171','4'),
(2,'','Prodi Tehnik Informatika',1,'20171',''),
(3,'1254634','rebi',0,'20172','3'),
(4,'1254634','rebi',1,'20172','3');

/*Table structure for table `dosen` */

DROP TABLE IF EXISTS `dosen`;

CREATE TABLE `dosen` (
  `id_dosen` int(5) NOT NULL AUTO_INCREMENT,
  `nidn` varchar(20) DEFAULT NULL,
  `nm_dosen` varchar(50) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_dosen`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `dosen` */

insert  into `dosen`(`id_dosen`,`nidn`,`nm_dosen`,`id_prodi`) values 
(2,'NID2222','Yeni Safitri, M.Kom',4),
(3,'NID11111','Yuda Alamsyah, M.Kom',4);

/*Table structure for table `dosen_pa` */

DROP TABLE IF EXISTS `dosen_pa`;

CREATE TABLE `dosen_pa` (
  `id_pa` int(11) NOT NULL AUTO_INCREMENT,
  `nidn` varchar(20) DEFAULT NULL,
  `nim` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_pa`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `dosen_pa` */

insert  into `dosen_pa`(`id_pa`,`nidn`,`nim`) values 
(1,'NID2222','1402456'),
(2,'NID2222','1402145');

/*Table structure for table `informasi` */

DROP TABLE IF EXISTS `informasi`;

CREATE TABLE `informasi` (
  `id_informasi` int(3) NOT NULL AUTO_INCREMENT,
  `informasi` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_informasi`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `informasi` */

insert  into `informasi`(`id_informasi`,`informasi`,`tanggal`) values 
(1,'Kepada seluruh mahasiswa universitas nurdin hamzah jambi agar mendaftarkan nim untuk mengakses halaman akademik ini . pendaftaran bisa di prodi ','2017-10-29 23:47:32');

/*Table structure for table `ipk_mhs` */

DROP TABLE IF EXISTS `ipk_mhs`;

CREATE TABLE `ipk_mhs` (
  `id_ipk` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `ipk` float DEFAULT NULL,
  `thn_akademik` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_ipk`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `ipk_mhs` */

insert  into `ipk_mhs`(`id_ipk`,`nim`,`ipk`,`thn_akademik`) values 
(3,'1402126',3.7,'20171'),
(5,'1402456',0,'20171'),
(6,'1402126',0,'20172');

/*Table structure for table `jadwal_kuliah` */

DROP TABLE IF EXISTS `jadwal_kuliah`;

CREATE TABLE `jadwal_kuliah` (
  `id_jadwal` int(11) NOT NULL AUTO_INCREMENT,
  `hari` varchar(10) DEFAULT NULL,
  `kd_matkul` varchar(10) DEFAULT NULL,
  `id_ruang` int(5) DEFAULT NULL,
  `jam_mulai` time DEFAULT NULL,
  `jam_selesai` time DEFAULT NULL,
  `id_dosen` int(5) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  `id_semester` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_jadwal`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `jadwal_kuliah` */

insert  into `jadwal_kuliah`(`id_jadwal`,`hari`,`kd_matkul`,`id_ruang`,`jam_mulai`,`jam_selesai`,`id_dosen`,`id_prodi`,`id_semester`) values 
(2,'Rabu','KD64573',1,'07:00:00','08:45:00',2,4,2),
(3,'Selasa','MK055463',2,'09:00:00','11:30:00',3,4,2),
(4,'Selasa','KD64573',1,'00:00:00','00:00:00',3,4,2);

/*Table structure for table `kelas` */

DROP TABLE IF EXISTS `kelas`;

CREATE TABLE `kelas` (
  `id_kelas` int(5) NOT NULL AUTO_INCREMENT,
  `kelas` varchar(15) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_kelas`),
  KEY `id_kelas` (`id_kelas`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `kelas` */

insert  into `kelas`(`id_kelas`,`kelas`,`id_prodi`) values 
(1,'TI A',4);

/*Table structure for table `krs` */

DROP TABLE IF EXISTS `krs`;

CREATE TABLE `krs` (
  `id_krs` int(20) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `kd_matkul` varchar(20) DEFAULT NULL,
  `thn_akademik` varchar(30) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '0',
  PRIMARY KEY (`id_krs`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

/*Data for the table `krs` */

insert  into `krs`(`id_krs`,`nim`,`kd_matkul`,`thn_akademik`,`status`) values 
(47,'1402126','C2KB1316','20171','1'),
(48,'1402126','MK65364','20171','1'),
(49,'1402126','MK055463','20171','1'),
(51,'1402126','KD64573','20172','0');

/*Table structure for table `mahasiswa` */

DROP TABLE IF EXISTS `mahasiswa`;

CREATE TABLE `mahasiswa` (
  `id_mahasiswa` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `nama_lengkap` varchar(50) DEFAULT NULL,
  `alamat` text,
  `nohp` varchar(12) DEFAULT NULL,
  `jk` enum('Laki-laki','Perempuan') DEFAULT NULL,
  `tempat` varchar(30) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `id_prodi` int(11) DEFAULT NULL,
  `foto_mahasiswa` text,
  `password` varchar(30) DEFAULT NULL,
  `dosen_pa` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_mahasiswa`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `mahasiswa` */

insert  into `mahasiswa`(`id_mahasiswa`,`nim`,`nama_lengkap`,`alamat`,`nohp`,`jk`,`tempat`,`tgl_lahir`,`id_prodi`,`foto_mahasiswa`,`password`,`dosen_pa`) values 
(2,'1402126','Boy Kurniawan','jambi','545345467','Laki-laki','Simbur Naik','2017-12-31',4,'buku_hara.jpg','1','NID11111'),
(3,'1402145','Yuda Alamsyah','Jambi','7867564534','Laki-laki','Jambi','2017-04-13',3,'Harga-Mobil-Murah-Honda.jpg','1','NID2222'),
(5,'1402456','Joni','sgg','7867565','Laki-laki','Jamni','2016-12-31',4,'codeigniter.jpg','1','NID2222'),
(9,'2209389010','oddo','','0922082071','Laki-laki','oddo','1991-02-08',1,'','oddo','NID2222');

/*Table structure for table `matakuliah` */

DROP TABLE IF EXISTS `matakuliah`;

CREATE TABLE `matakuliah` (
  `kd_matkul` varchar(10) NOT NULL,
  `nm_matkul` varchar(50) DEFAULT NULL,
  `sks` int(5) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  `tipe_semester` enum('1','2') DEFAULT NULL,
  `semester` int(2) DEFAULT NULL,
  PRIMARY KEY (`kd_matkul`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `matakuliah` */

insert  into `matakuliah`(`kd_matkul`,`nm_matkul`,`sks`,`id_prodi`,`tipe_semester`,`semester`) values 
('C2KB1316','Pengantar Teknologi Informasi',3,4,'1',1),
('KD64573','Pemrograman Web 1',4,4,'2',4),
('MK055463','Jaringan Komputer',4,4,'1',5),
('mk12031','Kalkulus',2,4,'1',3),
('MK65364','Matakuliah aaa',3,4,'1',1);

/*Table structure for table `nilai_mahasiswa` */

DROP TABLE IF EXISTS `nilai_mahasiswa`;

CREATE TABLE `nilai_mahasiswa` (
  `id_nilai` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `kd_matkul` varchar(20) DEFAULT NULL,
  `absen` float DEFAULT '0',
  `kuis` float DEFAULT '0',
  `mid` float DEFAULT '0',
  `uas` float DEFAULT '0',
  `total` float DEFAULT '0',
  `thn_akademik` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_nilai`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `nilai_mahasiswa` */

insert  into `nilai_mahasiswa`(`id_nilai`,`nim`,`kd_matkul`,`absen`,`kuis`,`mid`,`uas`,`total`,`thn_akademik`) values 
(12,'1402126','C2KB1316',80.45,95.5,80.9,45,69.415,'20171'),
(13,'1402126','MK65364',80,90,80.5,80,82.15,'20171'),
(14,'1402126','MK055463',90,80,95,80,85.5,'20171'),
(16,'1402126','KD64573',0,0,0,0,0,'20172');

/*Table structure for table `pengajuan_cuti` */

DROP TABLE IF EXISTS `pengajuan_cuti`;

CREATE TABLE `pengajuan_cuti` (
  `id_pengajuan` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `lama` varchar(30) DEFAULT NULL,
  `alasan` text,
  `id_prodi` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_pengajuan`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `pengajuan_cuti` */

insert  into `pengajuan_cuti`(`id_pengajuan`,`nim`,`lama`,`alasan`,`id_prodi`) values 
(1,'1254634','','1',3);

/*Table structure for table `pengajuan_transfer` */

DROP TABLE IF EXISTS `pengajuan_transfer`;

CREATE TABLE `pengajuan_transfer` (
  `id_transfer` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `transfer_ke` varchar(100) DEFAULT NULL,
  `jurusan` varchar(30) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_transfer`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `pengajuan_transfer` */

insert  into `pengajuan_transfer`(`id_transfer`,`nim`,`transfer_ke`,`jurusan`,`id_prodi`) values 
(1,'1402126','Unja','Ilmu komputer',4);

/*Table structure for table `prodi` */

DROP TABLE IF EXISTS `prodi`;

CREATE TABLE `prodi` (
  `id_prodi` int(5) NOT NULL AUTO_INCREMENT,
  `nm_prodi` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_prodi`),
  KEY `id_prodi` (`id_prodi`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `prodi` */

insert  into `prodi`(`id_prodi`,`nm_prodi`) values 
(1,'Ilmu Komputer'),
(3,'Sistem Informasi'),
(4,'Tehnik Informatika');

/*Table structure for table `ruang` */

DROP TABLE IF EXISTS `ruang`;

CREATE TABLE `ruang` (
  `id_ruang` int(5) NOT NULL AUTO_INCREMENT,
  `ruang` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_ruang`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `ruang` */

insert  into `ruang`(`id_ruang`,`ruang`) values 
(1,'Ruang 3.1'),
(2,'Ruang 3.2');

/*Table structure for table `semester` */

DROP TABLE IF EXISTS `semester`;

CREATE TABLE `semester` (
  `id_semester` int(5) NOT NULL AUTO_INCREMENT,
  `semester` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_semester`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `semester` */

insert  into `semester`(`id_semester`,`semester`) values 
(2,'Semester 1');

/*Table structure for table `tahun_akademik` */

DROP TABLE IF EXISTS `tahun_akademik`;

CREATE TABLE `tahun_akademik` (
  `id_tahun` int(5) NOT NULL AUTO_INCREMENT,
  `tahun` varchar(6) DEFAULT NULL,
  `ket` text,
  `status` enum('Tutup','Buka') DEFAULT 'Tutup',
  PRIMARY KEY (`id_tahun`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

/*Data for the table `tahun_akademik` */

insert  into `tahun_akademik`(`id_tahun`,`tahun`,`ket`,`status`) values 
(27,'20171','2017 ganjil','Buka'),
(28,'20172','2017 Genap','Tutup');

/*Table structure for table `upload_kp` */

DROP TABLE IF EXISTS `upload_kp`;

CREATE TABLE `upload_kp` (
  `id_upload` int(5) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `tempat` varchar(100) DEFAULT NULL,
  `nm_file` varchar(100) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_upload`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

/*Data for the table `upload_kp` */

insert  into `upload_kp`(`id_upload`,`nim`,`tempat`,`nm_file`,`id_prodi`) values 
(18,'1402126','PT. SKL','lap.docx',4);

/*Table structure for table `upload_pratikum` */

DROP TABLE IF EXISTS `upload_pratikum`;

CREATE TABLE `upload_pratikum` (
  `id_pratikum` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `file` varchar(100) DEFAULT NULL,
  `id_prodi` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_pratikum`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `upload_pratikum` */

insert  into `upload_pratikum`(`id_pratikum`,`nim`,`nama`,`file`,`id_prodi`) values 
(1,'1402126','Boy Kurniawan','USULAN PENELITIAN KERJA PRAKTEK.docx','4');

/*Table structure for table `upload_quiz` */

DROP TABLE IF EXISTS `upload_quiz`;

CREATE TABLE `upload_quiz` (
  `id_quiz` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `file` varchar(100) DEFAULT NULL,
  `id_prodi` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_quiz`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `upload_quiz` */

insert  into `upload_quiz`(`id_quiz`,`nim`,`nama`,`file`,`id_prodi`) values 
(1,'1402126','Boy Kurniawan','USULAN_PENELITIAN_KERJA_PRAKTEK.docx','4');

/*Table structure for table `upload_tugas` */

DROP TABLE IF EXISTS `upload_tugas`;

CREATE TABLE `upload_tugas` (
  `id_tugas` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `file` varchar(100) DEFAULT NULL,
  `id_prodi` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_tugas`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `upload_tugas` */

insert  into `upload_tugas`(`id_tugas`,`nim`,`nama`,`file`,`id_prodi`) values 
(1,'1402126','Boy Kurniawan','USULAN_PENELITIAN_KERJA_PRAKTEK.docx','4');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id_user` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `nama_lengkap` varchar(50) DEFAULT NULL,
  `foto_user` varchar(50) DEFAULT NULL,
  `level` enum('admin','prodi','dosen') DEFAULT 'prodi',
  `id_prodi` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`id_user`,`username`,`password`,`nama_lengkap`,`foto_user`,`level`,`id_prodi`) values 
(1,'admin','21232f297a57a5a743894a0e4a801fc3','Administrator',NULL,'admin',NULL),
(2,'ti','e00fba6fedfb8a49e13346f7099a23fc','Prodi Tehnik Informatika','-','prodi',4);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
