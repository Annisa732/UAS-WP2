<?php 
switch ($jenis) {
	case 'home':
		include 'home.php';
		break;
	case 'krs':
		include 'v_krs.php';
		break;
	case 'jadwal':
		include 'v_jadwal.php';
		break;
	case 'daftar_kp':
		include 'v_daftar_kp.php';
		break;
	case 'upload_kp':
		include 'v_upload_kp.php';
		break;
	case 'peserta_kp':
		include 'v_peserta_kp.php';
		break;
	case 'pengajuan_cuti':
		include 'v_pengajuan_cuti.php';
		break;
	case 'pengajuan_transfer':
		include 'v_pengajuan_transfer.php';
		break;
	case 'semua_krs':
		include 'v_rekap_krs.php';
		break;
	case 'daftar_ulang':
		include 'daftar_ulang.php';
		break;
	case 'materi':
		include 'materi.php';
		break;
	case 'aktifitas_terstruktur':
		include 'aktifitas_terstruktur.php';
		break;
	case 'aktifitas_mandiri':
		include 'aktifitas_mandiri.php';
		break;
	case 'pratikum':
		include 'pratikum.php';
		break;

	}

 ?>