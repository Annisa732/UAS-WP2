
<div class="row">
	<div class="col-md-12">
		<div class="block">
            <div class="head blue">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2>Jadwal Semester 1</h2>                             
            </div>                
            <div class="data-fluid">
                <table cellpadding="0" cellspacing="0" width="100%" class="table">
                    <thead>
                        <tr>
                            <th width="20%">
                                Matakuliah
                            </th>
                            <th width="20%">
                                Hari
                            </th>
                            <th width="20%">
                                Ruang
                            </th>
                            <th width="20%">
                                Jam
                            </th>
                            <th width="20%">
                                Dosen
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $semester = "semester 1";
                    $mk = $this->db->query("SELECT * from jadwal_kuliah, semester, matakuliah, dosen where jadwal_kuliah.id_dosen=dosen.id_dosen and jadwal_kuliah.kd_matkul=matakuliah.kd_matkul and jadwal_kuliah.id_semester=semester.id_semester and jadwal_kuliah.id_prodi='$idprodi' and semester.semester='$semester'");
                    foreach ($mk->result() as $row) {
                     ?>
                        <tr>
                            <td><?php echo $row->nm_matkul; ?></td>
                            <td><?php echo $row->hari; ?></td>
                            <td><?php 
                            $sql = $this->db->query("SELECT ruang FROM ruang WHERE id_ruang='$row->id_ruang'")->row();
                            echo $sql->ruang;
                             ?></td>
                            <td><?php echo $row->jam_mulai." - ".$row->jam_selesai; ?></td>
                            <td><?php echo $row->nm_dosen; ?></td>

                        </tr>
                    <?php } ?>                  
                    </tbody>
                </table>
            </div>              
        </div>
	</div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="block">
            <div class="head blue">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2>Jadwal Semester 2</h2>                             
            </div>                
            <div class="data-fluid">
                <table cellpadding="0" cellspacing="0" width="100%" class="table">
                    <thead>
                        <tr>
                            <th width="20%">
                                Matakuliah
                            </th>
                            <th width="20%">
                                Hari
                            </th>
                            <th width="20%">
                                Ruang
                            </th>
                            <th width="20%">
                                Jam
                            </th>
                            <th width="20%">
                                Dosen
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $semester = "semester 2";
                    $mk = $this->db->query("SELECT * from jadwal_kuliah, semester, matakuliah, dosen where jadwal_kuliah.id_dosen=dosen.id_dosen and jadwal_kuliah.kd_matkul=matakuliah.kd_matkul and jadwal_kuliah.id_semester=semester.id_semester and jadwal_kuliah.id_prodi='$idprodi' and semester.semester='$semester'");
                    foreach ($mk->result() as $row) {
                     ?>
                        <tr>
                            <td><?php echo $row->nm_matkul; ?></td>
                            <td><?php echo $row->hari; ?></td>
                            <td><?php 
                            $sql = $this->db->query("SELECT ruang FROM ruang WHERE id_ruang='$row->id_ruang'")->row();
                            echo $sql->ruang;
                             ?></td>
                            <td><?php echo $row->jam_mulai." - ".$row->jam_selesai; ?></td>
                            <td><?php echo $row->nm_dosen; ?></td>

                        </tr>
                    <?php } ?>                  
                    </tbody>
                </table>
            </div>              
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="block">
            <div class="head blue">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2>Jadwal Semester 3</h2>                             
            </div>                
            <div class="data-fluid">
                <table cellpadding="0" cellspacing="0" width="100%" class="table">
                    <thead>
                        <tr>
                            <th width="20%">
                                Matakuliah
                            </th>
                            <th width="20%">
                                Hari
                            </th>
                            <th width="20%">
                                Ruang
                            </th>
                            <th width="20%">
                                Jam
                            </th>
                            <th width="20%">
                                Dosen
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $semester = "semester 3";
                    $mk = $this->db->query("SELECT * from jadwal_kuliah, semester, matakuliah, dosen where jadwal_kuliah.id_dosen=dosen.id_dosen and jadwal_kuliah.kd_matkul=matakuliah.kd_matkul and jadwal_kuliah.id_semester=semester.id_semester and jadwal_kuliah.id_prodi='$idprodi' and semester.semester='$semester'");
                    foreach ($mk->result() as $row) {
                     ?>
                        <tr>
                            <td><?php echo $row->nm_matkul; ?></td>
                            <td><?php echo $row->hari; ?></td>
                            <td><?php 
                            $sql = $this->db->query("SELECT ruang FROM ruang WHERE id_ruang='$row->id_ruang'")->row();
                            echo $sql->ruang;
                             ?></td>
                            <td><?php echo $row->jam_mulai." - ".$row->jam_selesai; ?></td>
                            <td><?php echo $row->nm_dosen; ?></td>

                        </tr>
                    <?php } ?>                  
                    </tbody>
                </table>
            </div>              
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="block">
            <div class="head blue">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2>Jadwal Semester 4</h2>                             
            </div>                
            <div class="data-fluid">
                <table cellpadding="0" cellspacing="0" width="100%" class="table">
                    <thead>
                        <tr>
                            <th width="20%">
                                Matakuliah
                            </th>
                            <th width="20%">
                                Hari
                            </th>
                            <th width="20%">
                                Ruang
                            </th>
                            <th width="20%">
                                Jam
                            </th>
                            <th width="20%">
                                Dosen
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $semester = "semester 4";
                    $mk = $this->db->query("SELECT * from jadwal_kuliah, semester, matakuliah, dosen where jadwal_kuliah.id_dosen=dosen.id_dosen and jadwal_kuliah.kd_matkul=matakuliah.kd_matkul and jadwal_kuliah.id_semester=semester.id_semester and jadwal_kuliah.id_prodi='$idprodi' and semester.semester='$semester'");
                    foreach ($mk->result() as $row) {
                     ?>
                        <tr>
                            <td><?php echo $row->nm_matkul; ?></td>
                            <td><?php echo $row->hari; ?></td>
                            <td><?php 
                            $sql = $this->db->query("SELECT ruang FROM ruang WHERE id_ruang='$row->id_ruang'")->row();
                            echo $sql->ruang;
                             ?></td>
                            <td><?php echo $row->jam_mulai." - ".$row->jam_selesai; ?></td>
                            <td><?php echo $row->nm_dosen; ?></td>

                        </tr>
                    <?php } ?>                  
                    </tbody>
                </table>
            </div>              
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="block">
            <div class="head blue">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2>Jadwal Semester 5</h2>                             
            </div>                
            <div class="data-fluid">
                <table cellpadding="0" cellspacing="0" width="100%" class="table">
                    <thead>
                        <tr>
                            <th width="20%">
                                Matakuliah
                            </th>
                            <th width="20%">
                                Hari
                            </th>
                            <th width="20%">
                                Ruang
                            </th>
                            <th width="20%">
                                Jam
                            </th>
                            <th width="20%">
                                Dosen
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $semester = "semester 5";
                    $mk = $this->db->query("SELECT * from jadwal_kuliah, semester, matakuliah, dosen where jadwal_kuliah.id_dosen=dosen.id_dosen and jadwal_kuliah.kd_matkul=matakuliah.kd_matkul and jadwal_kuliah.id_semester=semester.id_semester and jadwal_kuliah.id_prodi='$idprodi' and semester.semester='$semester'");
                    foreach ($mk->result() as $row) {
                     ?>
                        <tr>
                            <td><?php echo $row->nm_matkul; ?></td>
                            <td><?php echo $row->hari; ?></td>
                            <td><?php 
                            $sql = $this->db->query("SELECT ruang FROM ruang WHERE id_ruang='$row->id_ruang'")->row();
                            echo $sql->ruang;
                             ?></td>
                            <td><?php echo $row->jam_mulai." - ".$row->jam_selesai; ?></td>
                            <td><?php echo $row->nm_dosen; ?></td>

                        </tr>
                    <?php } ?>                  
                    </tbody>
                </table>
            </div>              
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="block">
            <div class="head blue">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2>Jadwal Semester 6</h2>                             
            </div>                
            <div class="data-fluid">
                <table cellpadding="0" cellspacing="0" width="100%" class="table">
                    <thead>
                        <tr>
                            <th width="20%">
                                Matakuliah
                            </th>
                            <th width="20%">
                                Hari
                            </th>
                            <th width="20%">
                                Ruang
                            </th>
                            <th width="20%">
                                Jam
                            </th>
                            <th width="20%">
                                Dosen
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $semester = "semester 6";
                    $mk = $this->db->query("SELECT * from jadwal_kuliah, semester, matakuliah, dosen where jadwal_kuliah.id_dosen=dosen.id_dosen and jadwal_kuliah.kd_matkul=matakuliah.kd_matkul and jadwal_kuliah.id_semester=semester.id_semester and jadwal_kuliah.id_prodi='$idprodi' and semester.semester='$semester'");
                    foreach ($mk->result() as $row) {
                     ?>
                        <tr>
                            <td><?php echo $row->nm_matkul; ?></td>
                            <td><?php echo $row->hari; ?></td>
                            <td><?php 
                            $sql = $this->db->query("SELECT ruang FROM ruang WHERE id_ruang='$row->id_ruang'")->row();
                            echo $sql->ruang;
                             ?></td>
                            <td><?php echo $row->jam_mulai." - ".$row->jam_selesai; ?></td>
                            <td><?php echo $row->nm_dosen; ?></td>

                        </tr>
                    <?php } ?>                  
                    </tbody>
                </table>
            </div>              
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="block">
            <div class="head blue">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2>Jadwal Semester 7</h2>                             
            </div>                
            <div class="data-fluid">
                <table cellpadding="0" cellspacing="0" width="100%" class="table">
                    <thead>
                        <tr>
                            <th width="20%">
                                Matakuliah
                            </th>
                            <th width="20%">
                                Hari
                            </th>
                            <th width="20%">
                                Ruang
                            </th>
                            <th width="20%">
                                Jam
                            </th>
                            <th width="20%">
                                Dosen
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $semester = "semester 7";
                    $mk = $this->db->query("SELECT * from jadwal_kuliah, semester, matakuliah, dosen where jadwal_kuliah.id_dosen=dosen.id_dosen and jadwal_kuliah.kd_matkul=matakuliah.kd_matkul and jadwal_kuliah.id_semester=semester.id_semester and jadwal_kuliah.id_prodi='$idprodi' and semester.semester='$semester'");
                    foreach ($mk->result() as $row) {
                     ?>
                        <tr>
                            <td><?php echo $row->nm_matkul; ?></td>
                            <td><?php echo $row->hari; ?></td>
                            <td><?php 
                            $sql = $this->db->query("SELECT ruang FROM ruang WHERE id_ruang='$row->id_ruang'")->row();
                            echo $sql->ruang;
                             ?></td>
                            <td><?php echo $row->jam_mulai." - ".$row->jam_selesai; ?></td>
                            <td><?php echo $row->nm_dosen; ?></td>

                        </tr>
                    <?php } ?>                  
                    </tbody>
                </table>
            </div>              
        </div>
    </div>
</div>