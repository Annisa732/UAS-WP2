<div class="sidebar">

                
                <div class="nContainer">
                    <ul class="navigation">         
                        <li><a href="mahasiswa" class="blblue">Dashboard</a></li>
                        <li>
                            <a href="#" class="blyellow">Pengajuan KRS</a>
                            <div class="open"></div>
                            <ul>
                                <li><a href="mahasiswa/krs">Pilih KRS</a></li>
                                <li><a href="mahasiswa/rekap_krs">Semua KRS</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="blgreen">Kerja Praktek</a>
                            <div class="open"></div>
                            <ul>
                                <li><a href="mahasiswa/daftar_kp">Pendaftaran Kerja Praktek</a></li>
                                <li><a href="mahasiswa/upload_kp">Upload Laporan Kerja Praktek</a></li>
                            </ul>
                        </li>                
                        <li>
                            <a href="#" class="bldblue">Pengajuan</a>
                            <div class="open"></div>
                            <ul>
                                <li><a href="mahasiswa/pengajuan_cuti">Pengajuan Cuti</a></li>
                                <li><a href="mahasiswa/pengajuan_transfer">Pengajuan Transfer</a></li>                  
                            </ul>
                        </li>
                        <li>
                            <a href="mahasiswa/jadwal_kuliah" class="blred">Jadwal Kuliah</a>
                        </li>
                        
                    </ul>
                    <a class="close">
                        <span class="ico-remove"></span>
                    </a>
                </div>
                <div class="widget">
                    <div class="datepicker"></div>
                </div>

            </div>