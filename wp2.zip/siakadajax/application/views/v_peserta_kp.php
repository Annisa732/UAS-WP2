<div class="row">
	<h3>Daftar Peserta Kerja Praktek</h3>
	<div class="col-md-12">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>No.</th>
					<th>Nim</th>
					<th>Nama</th>
					<th>Tempat Kerja Praktek</th>
					<th>Prodi</th>
				</tr>
			</thead>
			<tbody>
			<?php 
			$no=1;
			$sql = $this->db->query("SELECT * FROM daftar_kp WHERE id_prodi='$idprodi'");
			foreach ($sql->result() as $row) {
			 ?>
				<tr>
					<td><?php echo $no; ?></td>
					<td><?php echo $row->nim ?></td>
					<td><?php 
					$sql = $this->db->query("SELECT nama_lengkap FROM mahasiswa WHERE nim='$row->nim'")->row();
					echo $sql->nama_lengkap;
					 ?></td>
					<td><?php echo $row->tempat ?></td>
					<td><?php 
					$sql = $this->db->query("SELECT * FROM prodi WHERE id_prodi='$idprodi'")->row();
					echo $sql->nm_prodi;
					 ?></td>
				</tr>
			<?php $no++;} ?>
			</tbody>
		</table>
	</div>
</div>