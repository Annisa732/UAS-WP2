<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from aqvatarius.com/themes/aries/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Apr 2017 15:34:49 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>        
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />    
        <base href="<?php echo base_url(); ?>">
        <!--[if gt IE 8]>
            <meta http-equiv="X-UA-Compatible" content="IE=edge" />        
        <![endif]-->                
        <title>Login - SIAKAD</title>
        <link rel="icon" type="image/ico" href="template/web/favicon.ico"/>

        <link href="template/web/css/stylesheets.css" rel="stylesheet" type="text/css" />
      <link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="sd/css/vendor/normalize.css">
  <link rel="stylesheet" href="sd/dist/gallery.css">
  <link rel="stylesheet" href="sd/dist/gallery.theme.css">
  <script src="sd/js/prefixfree.min.js"></script>

        <script type='text/javascript' src='template/web/js/plugins/jquery/jquery-1.10.2.min.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/jquery/jquery-ui-1.10.3.custom.min.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/jquery/jquery-migrate-1.2.1.min.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/jquery/globalize.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/other/excanvas.js'></script>

        <script type='text/javascript' src='template/web/js/plugins/other/jquery.mousewheel.min.js'></script>

        <script type='text/javascript' src='template/web/js/plugins/bootstrap/bootstrap.min.js'></script>

        <script type='text/javascript' src='template/web/js/plugins/cookies/jquery.cookies.2.2.0.min.js'></script>  

        <script type='text/javascript' src="template/web/js/plugins/uniform/jquery.uniform.min.js"></script>

        <script type='text/javascript' src='template/web/js/plugins/shbrush/XRegExp.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/shbrush/shCore.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/shbrush/shBrushXml.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/shbrush/shBrushJScript.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/shbrush/shBrushCss.js'></script>        

        <script type='text/javascript' src='template/web/js/plugins.js'></script>
        <script type='text/javascript' src='template/web/js/charts.js'></script>
        <script type='text/javascript' src='template/web/js/actions.js'></script>

    </head>
   <body style="background: url(image/bg.jpg);">


        <!-- Top content -->
        <div class="top-content">
            
            <div class="inner-bg">
                <div class="container">
                    
                    <div class="row">
                        <div class="btn btn-success">
                            <h1> <center>&nbsp; &nbsp;SISETM AKADEMIK UNIVERSITAS NURDIN HAMZAH KOTA JAMBI</center></h1>
                            <hr>
                            <div class="description">
                               
                            </div>
                        </div>
                    </div>
                    
<div class="jquery-script-center">
<ul>
</div>
<div class="jquery-script-clear"></div>
  <div class="gallery autoplay items-3">
    <div id="item-1" class="control-operator"></div>
    <div id="item-2" class="control-operator"></div>
    <div id="item-3" class="control-operator"></div>

    <figure class="item">
     <img src="image/image3.jpg" width="100%" height="100%">
    </figure>

    <figure class="item">
     <img src="image/side2.jpg" width="100%">
      
    </figure>

    <figure class="item">
     <img src="image/side1.jpg" width="100%">
      
    </figure>

    <div class="controls">
      <a href="#item-1" class="control-button">•</a>
      <a href="#item-2" class="control-button">•</a>
      <a href="#item-3" class="control-button">•</a>
    </div>
  </div>
                    <div class="row">
                  
                        <div class="col-sm-4">
                            
                            <div class="form-box">
                                <div class="form-top">
                                    <div class="form-top-left">
                                        <h3><li class="glyphicon glyphicon-log-in"></li> Login Sistem Akademik</h3>
                                        <hr>
                                    </div>
                                    <div class="form-top-right">
                                        <i class="fa fa-key"></i>
                                    </div>
                                </div>
                                <div class="form-bottom">
                                    <form role="form" action="login/cek_login" method="post" class="login-form">
                                        <div class="form-group">
                                            <label class="sr-only" for="form-username">Username</label>
                                            <input type="text" name="username" placeholder="Username..." class="form-username form-control" id="form-username">
                                        </div>
                                        <div class="form-group">
                                            <label class="sr-only" for="form-password">Password</label>
                                            <input type="password" name="password" placeholder="Password..." class="form-password form-control" id="form-password">
                                        </div>
                    <div class="form-group">
                        <select class="form-control" name="tipe">
                            <option value="">--Pilih Tipe User--</option>
                            <option value="mahasiswa">Mahasiswa</option>
                            <option value="dosen">Dosen</option>
                            <option value="prodi">Prodi</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>            
                                          <div class="row-form">
                </div>
                                        <input type="submit" name="login" class="btn" value="Login"> <span class="icon-arrow-next icon-white"></span>

                                        <input type="reset" name="" class="btn btn-danger" value="Login"> <span class="icon-arrow-next icon-white"></span>
                                    </form>
                                </div>
                            </div>
                        
                           
                        </div>
                        
                        <div class="col-sm-1 middle-border"></div>
                        <div class="col-sm-1"></div>
                            
                        <div class="col-sm-5">
                            
                            <div class="form-box">
                                <div class="form-top">
                                    <div class="form-top-left">
                                    <h3>
                                       <li class="glyphicon glyphicon-send"></li> Informasi akademik</h3>
                                        <hr>
                                    </div>
                                    <div class="form-top-right">
                                        <i class="fa fa-pencil"></i>
                                    </div>
                                </div>
                                <div class="ist-group">
                                     <?php foreach ($data->result() as $key => $value) {
        
                                            echo $value->informasi;
        }

        ?>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </div>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>

  <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<center style="background: green;color: white">    &copy; 2017 SISTEM AKADEMIK </center>

<!-- Mirrored from aqvatarius.com/themes/aries/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Apr 2017 15:34:49 GMT -->
</html>
