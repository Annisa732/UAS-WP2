<div class="row">
	<div class="col-md-12">                
        <div class="block">
            <div class="head">                                
                <h2>Form Daftar Ulang</h2>
                                                 
            </div>                                        
            <div class="data-fluid">
            <form action="mahasiswa/simpan_daftar_ulang" method="post">
                <div class="row-form">
                    <div class="col-md-3">Nim</div>
                    <div class="col-md-9"><input class="form-control" name="nim" type="text" value="<?php echo $nim; ?>" readonly/></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Nama Lengkap</div>
                    <div class="col-md-9"><input class="form-control" name="nama" type="text" value="<?php echo $nama_lengkap; ?>" readonly/></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Semester</div>
                    <div class="col-md-9"><input class="form-control" name="semester" type="text" placeholder="" /></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Tahun Akademik</div>
                    <div class="col-md-9">
                        <?php 
                        $a = $this->db->query("SELECT * FROM tahun_akademik WHERE status='Buka'")->row();
                         ?>
                    	<input type="text" name="thn_akademik" class="form-control" value="<?php echo $a->tahun; ?>">
                    	<input type="hidden" name="idprodi" value="<?php echo $idprodi; ?>">
                    </div>
                </div>
                <div class="row-form">
                	<div class="col-md-3"></div>
                	<div class="col-md-9">
                		<input type="submit" name="simpan" value="Kirim" class="btn btn-primary">
                	</div>
                </div>
            </form>
            </div>
        </div>

    </div>
</div>

