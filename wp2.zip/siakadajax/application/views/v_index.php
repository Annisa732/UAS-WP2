<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from aqvatarius.com/themes/aries/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Apr 2017 15:26:21 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>        
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />   
        <base href="<?php echo base_url(); ?>"> 
        <!--[if gt IE 8]>
            <meta http-equiv="X-UA-Compatible" content="IE=edge" />        
        <![endif]-->                
        <title>Sistem Informasi Akademik</title>
        <link rel="icon" type="image/ico" href="template/web/favicon.ico"/>

        <link href="template/web/css/stylesheets.css" rel="stylesheet" type="text/css" />
        <!--[if lte IE 7]>
            <link href="css/ie.css" rel="stylesheet" type="text/css" />
            <script type='text/javascript' src='js/plugins/other/lte-ie7.js'></script>
        <![endif]-->    
        <script type='text/javascript' src='template/web/js/plugins/jquery/jquery-1.10.2.min.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/jquery/jquery-ui-1.10.3.custom.min.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/jquery/jquery-migrate-1.2.1.min.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/jquery/globalize.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/other/excanvas.js'></script>

        <script type='text/javascript' src='template/web/js/plugins/other/jquery.mousewheel.min.js'></script>

        <script type='text/javascript' src='template/web/js/plugins/bootstrap/bootstrap.min.js'></script>

        <script type='text/javascript' src='template/web/js/plugins/cookies/jquery.cookies.2.2.0.min.js'></script>    

        <script type='text/javascript' src='template/web/js/plugins/jflot/jquery.flot.js'></script>    
        <script type='text/javascript' src='template/web/js/plugins/jflot/jquery.flot.stack.js'></script>    
        <script type='text/javascript' src='template/web/js/plugins/jflot/jquery.flot.pie.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/jflot/jquery.flot.resize.js'></script>

        <script type='text/javascript' src='template/web/js/plugins/epiechart/jquery.easy-pie-chart.js'></script>    
        <script type='text/javascript' src='template/web/js/plugins/sparklines/jquery.sparkline.min.js'></script>        

        <script type='text/javascript' src='template/web/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js'></script>

        <script type='text/javascript' src="template/web/js/plugins/uniform/jquery.uniform.min.js"></script>

        <script type='text/javascript' src="template/web/js/plugins/fullcalendar/fullcalendar.min.js"></script>

        <script type='text/javascript' src='template/web/js/plugins/shbrush/XRegExp.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/shbrush/shCore.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/shbrush/shBrushXml.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/shbrush/shBrushJScript.js'></script>
        <script type='text/javascript' src='template/web/js/plugins/shbrush/shBrushCss.js'></script>    

        <script type='text/javascript' src='template/web/js/plugins.js'></script>
        <script type='text/javascript' src='template/web/js/charts.js'></script>

        <script type='text/javascript' src='template/web/js/actions.js'></script>
    </head>
    <body>    
        <div id="loader"><img src="template/web/img/loader.gif"/></div>
        <div class="wrapper">

        <!-- menu side -->
            <?php include 'menu_side.php'; ?>
        <!-- menu side -->
            <div class="body">

                <!-- menu top -->
                <?php include 'menu_top.php'; ?>
                <!-- menu top -->

                <div class="container">

                    <div class="page-header">
                        <div class="wrap-title">
                            <div class="icon">
                                <span class="ico-arrow-right"></span>
                            </div>
                            <h1>SIAKAD <small>Universitas Teknologi</small></h1>
                        </div>
                        <ul class="breadcrumb">
                            <li>
                                <a href="mahasiswa">Home</a>
                            </li>
                            <li class="active"><?php echo $lokasi; ?></li>
                        </ul>
                        <div class="clear"></div>
                    </div>
                    <!-- Content -->
                    <?php include 'main_content.php'; ?>
                    <!-- Content -->
                </div>

            </div>

        </div>

        <div class="dialog" id="source" style="display: none;" title="Source"></div>

        <div id="fcAddEvent" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="fcAddEventLabel" aria-hidden="true">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="fcAddEventLabel">Add new event</h3>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-3">Title:</div>
                    <div class="col-md-9"><input class="form-control" type="text" id="fcAddEventTitle"/></div>
                </div>
            </div>
            <div class="modal-footer">            
                <button class="btn btn-primary" id="fcAddEventButton">Add</button>            
            </div>
        </div>    

    </body>

<!-- Mirrored from aqvatarius.com/themes/aries/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Apr 2017 15:26:21 GMT -->
</html>
