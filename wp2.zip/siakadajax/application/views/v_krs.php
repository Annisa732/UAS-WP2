<?php 
	//cek tahun akademik yang aktif
	$a = $this->db->query("SELECT * FROM tahun_akademik WHERE status='Buka'");
if ($a->num_rows() == 1) {
    $cek = $a->row();
	$d = substr($cek->tahun, 4, 5);
	//cek prodi mahasiswa
	$cekprodi = $this->db->query("SELECT * FROM prodi WHERE id_prodi='$idprodi'")->row();


	 ?>
<div id="status"></div>
<div class="row">
	<div class="col-md-12">
		<div class="block">
			<div class="head yellow">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2>KARTU RENCANA STUDI <b><?php echo $cek->ket; ?></b></h2>                             
            </div> 
            <div class="data-fluid">
            	<table class="table">
            		<tr>
            			<td width="20%">Nim</td>
            			<td width="2%">:</td>
            			<td><?php echo $nim; ?></td>
            		</tr>
            		<tr>
            			<td width="20%">Nama</td>
            			<td width="2%">:</td>
            			<td><?php echo $nama_lengkap; ?></td>
            		</tr>
            		<tr>
            			<td width="20%">Ip terakhir</td>
            			<td width="2%">:</td>
            			<td>
            				<?php 
            				$cekip = $this->db->query("SELECT * FROM ipk_mhs where nim='$nim' order by id_ipk desc");
            				if ($cekip->num_rows() == 0) {
            				    echo "0";
            				    }else {
            				    	$c = $cekip->row();
            				    	echo $c->ipk;
            				    }            				
            				 ?>
            			</td>
            		</tr>
            	</table>
            	<table cellpadding="0" cellspacing="0" width="100%" class="table table-bordered">
            		<thead>
            			<tr>
            				<th width="20%">Kode MK</th>
            				<th width="70%">Matakuliah</th>
            				<th width="10%">SKS</th>
            			</tr>
            		</thead>
            		<tbody>
            		<?php 
            		$z = $this->db->query("select * from krs,matakuliah where krs.nim = '$nim' and krs.kd_matkul=matakuliah.kd_matkul and krs.thn_akademik='$cek->tahun'");
            		if ($z->num_rows() == 0) {
            		 ?>
            			<tr>
            				<td colspan="3">KRS KOSONG</td>
            			</tr>
            		<?php } else { 
            			$total=0;
            			foreach ($z->result() as $n) {
            			?>
            			<tr>
            				<td><?php echo $n->kd_matkul; ?></td>
            				<td><?php echo $n->nm_matkul; ?></td>
            				<td><?php echo $n->sks; ?></td>
            			</tr>
            		<?php $total +=$n->sks; } ?>
            			<tr>
            				<td colspan="2">Total sks</td>
            				<td><?php 
            				echo "<b>".$total."</b>";
            				 ?></td>
            			</tr>
            		<?php } ?>
            		</tbody>
            	</table>
            </div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
	
	<p>Tahun Akademik yang aktif saat ini <b><?php echo $cek->ket; ?></b>.</p>
		<div class="block">
		<?php 
		//ambil mk berdasarkan prodi
		$mk = $this->db->query("SELECT DISTINCT(semester) FROM matakuliah WHERE id_prodi='$idprodi' and tipe_semester='$d' ORDER BY semester ASC");
		foreach ($mk->result() as $matkul) {
			$semester = $matkul->semester;
		 ?>
            <div class="head blue">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2><?php echo "Semester ".$matkul->semester; ?></h2>                             
            </div>                
            <div class="data-fluid">
                <table cellpadding="0" cellspacing="0" width="100%" class="table">
                    <thead>
                        <tr>
                            <th width="25%">
                                Kode MK
                            </th>
                            <th width="25%">
                                Matakuliah
                            </th>
                            <th width="25%">
                                Sks
                            </th>
                            <th width="25%">
                                Pilihan
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
					//ambil mk berdasarkan prodi
					$mk1 = $this->db->query("SELECT * FROM matakuliah WHERE id_prodi='$idprodi' and tipe_semester='$d' and semester='$semester'");
					foreach ($mk1->result() as $matkul1) {
					 ?>
                        <tr>
                            <td>
                                <?php echo $matkul1->kd_matkul; ?>
                            </td>
                            <td>
                                <?php echo $matkul1->nm_matkul; ?>
                            </td>
                            <td>
                                <?php echo $matkul1->sks; ?>
                            </td>
                            <td>
                                <a class="ambil" data-id="<?php echo $matkul1->kd_matkul; ?>" nim="<?php echo $nim; ?>" thn="<?php echo $cek->tahun; ?>" style="cursor: pointer;"><div>
                                <?php 
                                $s = $this->db->query("select * from krs where kd_matkul='$matkul1->kd_matkul' and nim='$nim'");
                                if ($s->num_rows() == 1) {
                                	echo "<span class='label label-success'>sudah diambil</span>";
                                } else {
                                 	echo "<span class='label label-warning'>ambil</span>";
                                }
                                ?>
                                </div></a>
                            </td>
                        </tr>    
                    <?php } ?>                       
                    </tbody>
                </table>
            </div>   
        <?php } ?>             
        </div>
	</div>
</div>

<script type="text/javascript">
	$(".ambil").click(function() {
      var id = $(this).attr('data-id');
      var nim = $(this).attr('nim');
      var thn = $(this).attr('thn');
      $.ajax({
        type: "POST",
        url: "<?php echo base_url();?>mahasiswa/ambil_krs",
        data: "id="+id+"&nim="+nim+"&thn="+thn,
        success: function(html){
          $("#status").html(html);
          window.location="mahasiswa/krs";
        }
      }); 
    });
</script>
<?php } else {
	//kosong
	echo "tahun akademik tidak ada yang buka";

	} ?>