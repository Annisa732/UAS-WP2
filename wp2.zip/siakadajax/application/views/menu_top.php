<ul class="navigation">
                    <li>
                        <a href="mahasiswa/" class="button">
                            <div class="icon">
                                <span class="ico-monitor"></span>
                            </div>                    
                            <div class="name">Dashboard</div>
                        </a>                
                    </li> 
                    <li>
                        <a href="mahasiswa/daftar_ulang" class="button">
                            <div class="icon">
                                <span class="ico-clipboard-2"></span>
                            </div>                    
                            <div class="name">Daftar Ulang</div>
                        </a>                
                    </li>           
                    <li>
                        <a href="#" class="button green">
                            <div class="arrow"></div>
                            <div class="icon">
                                <span class="ico-pen-2"></span>
                            </div>                    
                            <div class="name">Pengajuan KRS</div>
                        </a>
                        <ul class="sub">
                            <li><a href="mahasiswa/krs">Pilih KRS</a></li>
                            <li><a href="mahasiswa/rekap_krs">Semua KRS</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="button green">
                            <div class="arrow"></div>
                            <div class="icon">
                                <span class="ico-repeat"></span>
                            </div>                    
                            <div class="name">Perkuliahan</div>
                        </a>
                        <ul class="sub">
                            <li><a href="mahasiswa/rps">RPS & SAP</a></li>
                            <li><a href="mahasiswa/materi">Materi Ajar</a></li>
                        </ul>
                    </li> 
                    <li>
                        <a href="#" class="button green">
                            <div class="arrow"></div>
                            <div class="icon">
                                <span class="ico-move"></span>
                            </div>                    
                            <div class="name">Metode Belajar</div>
                        </a>
                        <ul class="sub">
                            <li><a href="mahasiswa/aktifitas_terstruktur">Aktifitas Terstruktur</a></li>
                            <li><a href="mahasiswa/aktifitas_mandiri">Aktifitas Mandiri</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="mahasiswa/Pratikum" class="button green">
                            <div class="arrow"></div>
                            <div class="icon">
                                <span class="ico-tags-2"></span>
                            </div>                    
                            <div class="name">Pratikum</div>
                        </a>
                    </li>                         
                                    
                    <li>
                        <a href="#" class="button dblue">
                            <div class="arrow"></div>
                            <div class="icon">
                                <span class="ico-layout-7"></span>
                            </div>                    
                            <div class="name">Kerja Praktek</div>
                        </a>
                        <ul class="sub">
                            <li><a href="mahasiswa/daftar_kp">Pendaftaran Kerja Praktek</a></li>
                            <li><a href="mahasiswa/upload_kp">Upload Laporan Kerja Praktek</a></li>
                        </ul> 
                    </li>
                    <li>
                        <a href="#" class="button purple">
                            <div class="arrow"></div>
                            <div class="icon">
                                <span class="ico-box"></span>
                            </div>                    
                            <div class="name">Pengajuan</div>
                        </a>
                        <ul class="sub">
                            <li><a href="mahasiswa/pengajuan_cuti">Pengajuan Cuti</a></li>
                            <li><a href="mahasiswa/pengajuan_transfer">Pengajuan Transfer</a></li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="mahasiswa/jadwal_kuliah" class="button red">
                            <div class="icon">
                                <span class="ico-chart-4"></span>
                            </div>                    
                            <div class="name">Jadwal MK</div>
                        </a>                
                    </li>

                    <li>
                        <a href="#" class="button purple">
                            <div class="arrow"></div>
                            <div class="icon">
                                <span class="ico-box"></span>
                            </div>                    
                            <div class="name">Bimbingan</div>
                        </a>
                        <ul class="sub">
                            <li><a href="mahasiswa/bim_akademik">Bimbingan Akademik</a></li>
                            <li><a href="mahasiswa/bim_kp">Bimbingan KP</a></li>
                            <li><a href="mahasiswa/bim_skripsi">Bimbingan Skripsi</a></li>
                            <li><a href="mahasiswa/bim_pkm">Bimbingan PKM</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="mahasiswa/logout" class="button">
                            <div class="icon">
                                <span class="ico-switch"></span>
                            </div>                    
                            <div class="name">Keluar</div>
                        </a>                
                    </li>
                                   
                    <li>
                        <div class="user">
                            <img src="image/mhs/thumbnails/<?php echo $foto; ?>" style="width: 50px; height: 50px;" align="left"/>
                            <a href="#" class="name">
                                <span><?php echo $nama_lengkap; ?></span>
                                <span class="sm">Mahasiswa</span>
                            </a>

                        </div>
                        <div class="buttons">
                            <div class="sbutton green navButton">
                                <a href="#"><span class="ico-align-justify"></span></a>
                            </div>
                            <div class="sbutton blue">
                                <a href="#"><span class="ico-cogs"></span></a>
                                <div class="popup">
                                    <div class="arrow"></div>
                                    <div class="row">
                                        <div class="row-form">
                                            <div class="col-md-12"><strong>SETTINGS</strong></div>
                                        </div>                                    
                                        <div class="row-form">
                                            <div class="col-md-4">Navigation:</div>
                                            <div class="col-md-8">
                                                <label><input type="radio" class="cNav" name="cNavButton" value="default"/> Default</label>
                                                <label><input type="radio" class="cNav" name="cNavButton" value="bordered"/> Bordered</label>
                                            </div>
                                        </div>
                                        <div class="row-form">
                                            <div class="col-md-4">Nav color:</div>
                                            <div class="col-md-8">
                                                <div class="cNavC">
                                                    <span class="color_1" name="cNavButColor"></span>
                                                    <span class="color_2" name="cNavButColor"></span>
                                                    <span class="color_3" name="cNavButColor"></span>
                                                    <span class="color_4" name="cNavButColor"></span>
                                                    <span class="color_5" name="cNavButColor"></span>
                                                    <span class="color_6" name="cNavButColor"></span>
                                                    <span class="color_7" name="cNavButColor"></span>
                                                    <span class="color_8" name="cNavButColor"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row-form">
                                            <div class="col-md-4">Top navigation:</div>
                                            <div class="col-md-8">
                                                <label><input type="radio" class="cTopNavH" name="cTopNavHide" value="show"/> Show</label>
                                                <label><input type="radio" class="cTopNavH" name="cTopNavHide" value="hide"/> Hide</label>
                                            </div>
                                        </div> 
                                        <div class="row-form">
                                            <div class="col-md-4">Content:</div>
                                            <div class="col-md-8">
                                                <label><input type="radio" class="cCont" name="cContent" value=""/> Responsive</label>
                                                <label><input type="radio" class="cCont" name="cContent" value="fixed"/> Fixed</label>
                                            </div>
                                        </div>                                    
                                    </div>
                                </div>
                            </div>                        
                        </div>
                    </li> 



                </ul>