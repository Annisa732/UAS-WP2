<div class="row">
	<div class="col-md-12">                
        <div class="block">
            <div class="head">                                
                <h2>Form Pendaftaran KP</h2>
                <ul class="buttons">             
                    <li><a href="#" onClick="source('form_default');
                        return false;"><div class="icon"><span class="ico-info"></span></div></a></li>
                </ul>                                  
            </div>                                        
            <div class="data-fluid">
            <form action="mahasiswa/simpan_daftar_kp" method="post">
                <div class="row-form">
                    <div class="col-md-3">Nim</div>
                    <div class="col-md-9"><input class="form-control" name="nim" type="text" value="<?php echo $nim; ?>" readonly/></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Nama Lengkap</div>
                    <div class="col-md-9"><input class="form-control" name="nama" type="text" value="<?php echo $nama_lengkap; ?>" readonly/></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Pengajuan tempat kerja praktek</div>
                    <div class="col-md-9">
                    	<textarea class="form-control" name="tempat" rows="2" required></textarea>
                    	<input type="hidden" name="idprodi" value="<?php echo $idprodi; ?>">
                    </div>
                </div>
                <div class="row-form">
                	<div class="col-md-3"></div>
                	<div class="col-md-9">
                		<input type="submit" name="simpan" value="Kirim" class="btn btn-primary">
                	</div>
                </div>
            </form>
            </div>
        </div>

    </div>
</div>

