<div class="row">
	<div class="col-md-12">                
        <div class="block">
            <div class="head">                                
                <h2>Form Pengajuan Transfer</h2>                                 
            </div>                                        
            <div class="data-fluid">
            <form action="mahasiswa/simpan_transfer" method="post">
                <div class="row-form">
                    <div class="col-md-3">Nim</div>
                    <div class="col-md-9"><input class="form-control" name="nim" type="text" value="<?php echo $nim; ?>" readonly/></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Nama Lengkap</div>
                    <div class="col-md-9"><input class="form-control" name="nama" type="text" value="<?php echo $nama_lengkap; ?>" readonly/></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Tranfer KE</div>
                    <div class="col-md-9"><input class="form-control" name="tranfer" type="text" placeholder="STMIK Nurdin Hamzah" /></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Jurusan di pilih</div>
                    <div class="col-md-9">
                    	<input type="text" class="form-control" name="jurusan" placeholder="Ilmu Komputer">
                    	<input type="hidden" name="idprodi" value="<?php echo $idprodi; ?>">
                    </div>
                </div>
                <div class="row-form">
                	<div class="col-md-3"></div>
                	<div class="col-md-9">
                		<input type="submit" name="simpan" value="Kirim" class="btn btn-primary">
                	</div>
                </div>
            </form>
            </div>
        </div>

    </div>
</div>

