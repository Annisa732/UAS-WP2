<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from upct.siakad.org/pmb/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 10 Apr 2017 14:09:43 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <!--[if gt IE 8]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <![endif]-->
    <title>Sistem Informasi Akademik</title>
    <base href="<?php echo base_url(); ?>">
   <link rel="icon" type="image/gif"  href='template/web/uploads/images/logo-siakad-fa-pct.png'>

    <link href="template/web/css-js-siakad/css/stylesheets.css" rel="stylesheet" type="text/css" />
    <!--[if lte IE 7]>
        <link href="css/ie.css" rel="stylesheet" type="text/css" />
        <script type='text/javascript' src='js_digilib/plugins/other/lte-ie7.js'></script>
    <![endif]-->
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/jquery/jquery-1.9.1.min.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/jquery/jquery-ui-1.10.1.custom.min.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/jquery/jquery-migrate-1.1.1.min.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/jquery/globalize.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/other/excanvas.js"></script>

    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/other/jquery.mousewheel.min.js"></script>

    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/bootstrap/bootstrap.min.js"></script>

    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/cookies/jquery.cookies.2.2.0.min.js"></script>

    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/jflot/jquery.flot.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/jflot/jquery.flot.stack.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/jflot/jquery.flot.pie.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/jflot/jquery.flot.resize.js"></script>

    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/sparklines/jquery.sparkline.min.js"></script>

    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>

    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/uniform/jquery.uniform.min.js"></script>
	
	<script type='text/javascript' src="template/web/css-js-siakad/js/plugins/select/select2.min.js"></script>
	<script type='text/javascript' src="template/web/css-js-siakad/js/plugins/tagsinput/jquery.tagsinput.min.js"></script>
	<script type='text/javascript' src="template/web/css-js-siakad/js/plugins/maskedinput/jquery.maskedinput-1.3.min.js"></script>
	<script type='text/javascript' src="template/web/css-js-siakad/js/plugins/multiselect/jquery.multi-select.min.js"></script>
	<script type='text/javascript' src="template/web/css-js-siakad/js/plugins/validationEngine/languages/jquery.validationEngine-en.js"></script>
	<script type='text/javascript' src="template/web/css-js-siakad/js/plugins/validationEngine/jquery.validationEngine.js"></script>
	<!--<script type="text/javascript" src="http://upct.siakad.org/css-js-siakad/js/plugins/datatables/jquery.dataTables.min.js"></script>-->

    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/shbrush/XRegExp.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/shbrush/shCore.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/shbrush/shBrushXml.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/shbrush/shBrushJScript.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/shbrush/shBrushCss.js"></script>
	
    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins/fancybox/jquery.fancybox.pack.js"></script>
	

    <script type='text/javascript' src="template/web/css-js-siakad/js/plugins.js"></script>
    <script type='text/javascript' src="template/web/css-js-siakad/js/charts.js"></script>

    <script type='text/javascript' src="template/web/css-js-siakad/js/actions.js"></script>
    <script src="template/web/css-js-siakad/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="template/web/css-js-siakad/js/modernizr.custom.min.js"></script>
      <script type="text/javascript" src="template/web/css-js-siakad/js/commonFunction.js"></script>
      <script src="template/web/css-js-siakad/js/common.js"></script>
	  
	<script src="template/web/css-js-siakad/pmb/js-image-slider.js"></script>
	<script src="template/web/css-js-siakad/pmb/mcVideoPlugin.js"></script>
	 <link href="template/web/css-js-siakad/pmb/js-image-slider.css" rel="stylesheet" type="text/css" />
	 <link href="template/web/css-js-siakad/css/generic.css" rel="stylesheet" type="text/css" />
	<!-- /sliderman.js -->
	<script src="template/web/css-js-siakad/js/jquery.easy-ticker.js"></script>
	

    <style>
.wp-caption {
  color: #C9C9C9;
    border-radius: 3px 3px 3px 3px;
    max-width: 100%;
    padding: 8px 8px 0;
    text-align: center;
    font-size: 12px;
}
.wp-top {
    color: #C9C9C9;

}
.dataTables_processing {
        background-color: white;
        border: 1px solid #DDDDDD;
        color: #999999;
        font-size: 14px;
        height: 30px;
        left: 50%;
        margin-left: -125px;
        margin-top: -15px;
        padding: 14px 0 2px;
        position: absolute;
        text-align: center;
        top: 50%;
        width: 250px;
}
    </style>
</head>
<body>
    <div id="loader"><img src="template/web/css-js-siakad/img/loader.gif"/></div>
    <div class="wrapper container-non-responsive">
        <div class="leftpanel"> 
        <div class="sidebar">

            <div class="top wp-top">
                <h3>PMB</h3>

            </div>
            <div class="widget">
			 <script type="text/javascript">
		        var currenttime = 'April 10, 2017 21:09:41' //PHP method of getting server date
		        var montharray=new Array("Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember")
		        var dayarray=new Array("Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu")
		        var serverdate=new Date(currenttime)
		        function padlength(what){
		              var output=(what.toString().length==1)? "0"+what : what
		              return output
		        }
		        function displaytime(){
		             serverdate.setSeconds(serverdate.getSeconds()+1)

                      var datestring=padlength(serverdate.getDate())+" "+montharray[serverdate.getMonth()]+" "+serverdate.getFullYear()

                      var monthstring=montharray[serverdate.getMonth()]

                      var daystring=dayarray[serverdate.getDay()]


                      document.getElementById("hari").innerHTML=daystring

                      document.getElementById("tanggal").innerHTML=datestring
		        }
		        window.onload=function(){
		        setInterval("displaytime()", 1000)
		        }
                
		    </script>
			<div class="kotak">
		        	<p style="font-size: 20px; margin: 0px; text-align: right; color: #ffffff;font-weight: bold" id="hari"></p>
		        	<p style="font-size: 18px; margin: 0px; text-align: right; color: #ffffff;font-weight: bold" id="tanggal"></p>
			</div>
            </div>
			<div class="body1">
			<div class="content">
			<section class="span2a">
		<div class="block" id="sWidget_2">
		<script>
		$(document).ready(function()
		{
		 $('.mod-ticker').easyTicker({
    			direction: 'up',
                speed: 'slow',
            	interval: 4000,
            	height: 'auto',
            	visible: 1,
                mousePause: 0
		    });
	 });
		 
		</script>
                            <div class="head orange">
                                <h2>Info</h2>
                            </div>
                            <div class="data dark" style="height: 171px;">
                                                                               <div class="mod-ticker">
                            <div style="position: absolute; margin: 0px; top: 0px;">
                                                                <div>
                                                                        <a href="#" style="font-size: 7pt">25 November 2015</a>
                                    <p style="font-size: 8pt">
                                         PELATIHAN SIAKAD                                    </p>
                                </div>
                                                                <div>
                                                                        <a href="#" style="font-size: 7pt">17 Agustus 2016</a>
                                    <p style="font-size: 8pt">
                                         Merdeka                                    </p>
                                </div>
                                                            </div>
                        </div>
                                                    </div>
                        </div>
                <div class="clear"></div>
                </section>
				</div>
</div>
            <center>
            <div class="widget">
            <div class="wp-caption">
                   <div id="pages-kont"><a href="http://demo.siakad.org/" target="_blank"><img src="template/web/uploads/images/logo-siakad-pct.png" width="125" height="125" border="0" /></a>
           <tr>
                         <td></td><br />
                         <td>Jalan Raya Malang</td><br />
                         <td>Telp : 0341-809031</td><br />
                         <td>Fax : 0341-809031</td><br />
                         <td>demo.siakad.org</td><br />
                         <td>Kodepos : 60900</td>
                       </tr>		  </div>
          </div>
            </div>
            </center>

        </div>
        </div>
        <div class="body">
            <div class="rightpanel"> 
        <button href="#" class="showmenu" onclick="kiri()"></button>
          <ul class="navigation">
                <li >
                    <a href="http://upct.siakad.org/pmb" class='button orange'>
                        <div class="icon">
                            <span class="ico-monitor"></span>
                        </div>
                        <div class="name" align="center">Home</div>
                    </a>
                </li>
                 <li >
                    <a href="http://demo.siakad.org/"  target="_blank" class="button purple" style="width: 92px">
                        <div class="icon">
                            <span class="ico-bookmark-3"></span>
                        </div>
                        <div class="name" style="font-size:9.4px;" align="center">UPCT<!--UNIVERSITAS PRIMA CIPTA TEKNOLOGI--></div>
                    </a>
                </li>
				<li >
                    <a href="formulir-pendaftaran.html" class='button red'>
                        <div class="icon">
                            <span class="ico-group "></span>
                        </div>
                        <div class="name" align="center">Daftar PMB</div>
                    </a>
                </li>  
				<!--
				<li >
                    <a href="http://upct.siakad.org/pmb/formulir-pendaftaran-pmdk.html" class='button abu'>
                        <div class="icon">
                            <span class="ico-group "></span>
                        </div>
                        <div class="name" align="center">Daftar PMDK</div>
                    </a>
                </li>  -->
				<li >
                    <a href="daftar-calon.html" class="button green">
                        <div class="icon">
                            <span class="ico-folder-open "></span>
                        </div>
                        <div class="name" align="center">Data Pendaftar</div>
                    </a>
                </li> 
				<li >
                    <a href="#" class='button dbblue'>
                        <div class="icon">
                            <span class="ico-trophy"></span>
                        </div>
                        <div class="name" align="center">Kelulusan</div>
                    </a>
                     <ul class="sub">
                       <li ><a href="kelulusan.html" title="Hasil Tes">Hasil Tes</a></li>
                       <!--<li ><a href="http://upct.siakad.org/pmb/kelulusan-pmdk.html" title="Hasil PMDK">Hasil PMDK</a></li>
                     --></ul>
                </li>
                
				<li >
                    <a href="statistik.html" class="button orange">
                        <div class="icon">
                            <span class="ico-chart-4 "></span>
                        </div>
                        <div class="name" align="center">Statistik</div>
                    </a>
                </li>
				<!--<li >
                    <a href="" class='button yellow'>
                        <div class="icon">
                            <span class="ico-user "></span>
                        </div>
                        <div class="name" align="center">Login Admin</div>
                    </a>
                </li>-->
				
				
				 
				
				
				
				
				
				
				             
                <li>
				    <div class="user">
                        <img src="template/web/uploads/images/logo-siakad-pct.png" width='30px' height='30px'  align="left"/>
                        <a href="#" class="name">
                            <span>SIAKAD</span>
                            <span class="sm">STIKes</span>
                        </a>
						
                    </div>
					<div class="buttons">
                        <div class="sbutton green navButton">
                            <a href="#"><span class="ico-align-justify"></span></a>
                        </div>
						<div class="btn-group">
						<a href="template/web/uploads/images/peta-pct.png"  class="fb" rel="group" title="Peta Lokasi"><button class="btn tip" data-original-title="Peta Lokasi"><span class="icon-map-marker icon-white"></span></button></a>
						
						</div>
						<div class="btn-group">
						<a href="template/web/uploads/images/alur-A-pct.png"  class="fb" rel="group" title="Alur PMB"><button class="btn tip green" data-original-title="Alur PMB"><span class="icon-road icon-white"></span></button></a>
						</div>
						<div class="btn-group">
						<a href="template/web/uploads/images/prosedurA-pct.png"  class="fb" rel="group" title="Panduan PMB"><button class="btn tip yellow" data-original-title="Panduan PMB"><span class="icon-question-sign icon-white"></span></button></a>
						</div>
						
						<br/>
						
						
						<div class="sbuttonup purple">
                            <a href="#" class="btn tip purple" data-original-title="Informasi Prodi"><span class="ico-info icon-white"></span></a>
                            <div class="popup">
                                <div class="row-fluid">
                                    <div class="row-form">
                                        <div class="span12"><center><span class="label label-info">9<i>Prodi</i></span></center></div>
                                    </div>
									<div class="right">
                                    <table cellpadding="0" cellspacing="0" width="100%">
																				<tr>
									    <td><center><strong id="strong-sirak" >AKUNTANSI (S1)<br /></strong></center></td>
										</tr>
									    										<tr>
									    <td><center><strong id="strong-sirak" >ILMU ADMINISTRASI (S2)<br /></strong></center></td>
										</tr>
									    										<tr>
									    <td><center><strong id="strong-sirak" >ILMU ADMINISTRASI NEGARA (S1)<br /></strong></center></td>
										</tr>
									    										<tr>
									    <td><center><strong id="strong-sirak" >ILMU ADMINISTRASI NIAGA (S1)<br /></strong></center></td>
										</tr>
									    										<tr>
									    <td><center><strong id="strong-sirak" >MANAJEMEN (S1)<br /></strong></center></td>
										</tr>
									    										<tr>
									    <td><center><strong id="strong-sirak" >MANAJEMEN (S2)<br /></strong></center></td>
										</tr>
									    										<tr>
									    <td><center><strong id="strong-sirak" >PENDIDIKAN GURU SEKOLAH DASAR (S1)<br /></strong></center></td>
										</tr>
									    										<tr>
									    <td><center><strong id="strong-sirak" >TEKNIK INDUSTRI (S1)<br /></strong></center></td>
										</tr>
									    										<tr>
									    <td><center><strong id="strong-sirak" >TEKNIK KIMIA (S1)<br /></strong></center></td>
										</tr>
									     
                                    </table>
									<br />
                                </div>
                                </div>
                            </div>
                        </div>
												
						
						
						<!--<div class="btn-group">
						<a href="http://upct.siakad.org/uploads/images/prosedurA-pct.png"  class="fb" rel="group"><button class="btn tip purple" data-original-title="Panduan PMB"><span class="ico-info icon-white "></span></button></a>
						</div>-->
						
						
					</div>
					
					
					
						
                </li>
            </ul>


            <div class="content">

                <div class="page-header">
                    <div class="icon">
                        <span class="ico-arrow-right"></span>
                    </div>
                    <h1>SIAKAD <small>UNIVERSITAS TEKNOLOGI</small></h1>
                </div>

         
                <div class="row-fluid">
                    <div class="span12">
                        <div class="block">
                            <article class="container_12">
                            <div id="sliderFrame">
        <div id="slider">
            <a href="#">
                <img src="template/web/uploads/images/1-upct.png" alt="UNIVERSITAS PRIMA CIPTA TEKNOLOGI" />
            </a>
			<a href="#">
                <img src="template/web/uploads/images/2-upct.png" alt="UNIVERSITAS PRIMA CIPTA TEKNOLOGI" />
            </a>
			<a href="#">
                <img src="template/web/uploads/images/3-upct.png" alt="UNIVERSITAS PRIMA CIPTA TEKNOLOGI" />
            </a>
            
        </div>
    </div>




  <br/>
  <br/>
  <br/>
 <div style='position:center'>
<div class="span12">
<h2 align=center>SISTEM INFORMASI AKADEMIK<br /> UNIVERSITAS TEKNOLOGI </h2>
<div class="home-galleries no-margin-left">
    <div class="header">
       <div class="base">
	   
	   <div class="head red">
	   <div class="icon">
<span class="ico-pen-2"></span>
</div>
            <h2>Info</h2>
		</div>
            <div class="nav-control">
                <span class="previous"></span><span class="next"></span>
            </div>
       </div>
       <div class="arrow arrow-left"></div>
       <div class="arrow arrow-right"></div>
       </div>
            <div class="text">
                <table width=700 border=0 class='table table-bordered'>
                                    <tr>
                      <td colspan=3 bgcolor='#FFFFCC'> <b>A. Syarat Pendaftaran</b> </td>
                    </tr>
                                            <tr>
                          <td width=17>1</td><td width=653>Program S.1 (reguler) : Lulusan SMU/SMK/MA atau yang sederajat.</td>
                        </tr>
                                        <tr>
                          <td width=17>2</td><td width=653>Program S.1 (transfer) : Lulusan D.2 atau D.3 yang sederajat.</td>
                        </tr>
                                        <tr>
                          <td width=17>3</td><td width=653><p>Membayar biaya pendaftaran Rp. 200.000,-</p>
</td>
                        </tr>
                                        <tr>
                          <td width=17>4</td><td width=653>Mengisi Formulir Pendaftaran yang dilengkapi dengan :
<br>a. Fotokopi Ijazah dan Danum SMTA/Surat Keterangan Lulus dari Sekolah(SKL)yang telah dilegalisir(1 lembar).
<br>b. Pas Foto berwarna 3x3(2 lembar).
<br>c. Fotokopi Ijazah dan transkrip D.2/D.3 (1 lembar) (bagi program S.1 Transfer).
<br>d. Bagi calon pendaftar yang tidak lulus UAN, dapat mendaftar jika sudah mempunyai ijazah Paket C.</td>
                        </tr>
                                        <tr>
                          <td width=17>5</td><td width=653><p>Biaya pendaftaran untuk gelombang ke 2 Rp. 500.000,-</p>
</td>
                        </tr>
                                        <tr>
                          <td width=17>6</td><td width=653><p>Lulus seleksi tes potensi akademik (TPA) yang diadakan oleh panitia</p>
</td>
                        </tr>
                <td colspan=3>&nbsp;</td>                    <tr>
                      <td colspan=3 bgcolor='#FFFFCC'> <b>B. Biaya Perkuliahan</b> </td>
                    </tr>
                                            <tr>
                          <td width=17>7</td><td width=653><table>
	<tbody>
		<tr>
			<td>Jenis Pembayaran</td>
			<td>Jumlah</td>
			<td>Keterangan</td>
		</tr>
		<tr>
			<td>Uang partisipasi penyelenggaraan pendidikan (UP3)</td>
			<td>Rp. 4.000.000,-</td>
			<td>dapat diangsur selama 1 semester (angsuran pertama 500.000</td>
		</tr>
		<tr>
			<td>jas almamater, jaket, kaos, KTM, dan ospek</td>
			<td>Rp. 800.000</td>
			<td>-</td>
		</tr>
		<tr>
			<td>SPP/Bulan</td>
			<td>Rp. 600.000</td>
			<td>-</td>
		</tr>
		<tr>
			<td>Kemahasiswaan/Bulan</td>
			<td>Rp. 50.000</td>
			<td>-</td>
		</tr>
	</tbody>
</table>
</td>
                        </tr>
                <td colspan=3>&nbsp;</td>                    <tr>
                      <td colspan=3 bgcolor='#FFFFCC'> <b>makan</b> </td>
                    </tr>
                                      <tr align='center'>
                    <td colspan=3 bgcolor='#FFFFCC' ><b>JADWAL KEGIATAN</b></td>
                  </tr>
                  <td colspan=3>
                  <center><table width='100%' class='table table-bordered'>
                      <thead>
                      <tr>
                        <th>Hari, Tanggal</th>
                        <th>Waktu</th>
                        <th>Kegiatan</th>
                        <th>Tempat</th>
                      </tr>
                      </thead><tr><td rowspan='2' align='center' >2 maret 2015 s.d 30 april 2015</td>
                                      <td>08.00 - 12.00</td>
                                      <td>Pendaftaran Gel. 1</td>
                                      <td>Aula</td>
                                  
                                    <tr>
                                        <td>14.00-16.00</td>
                                        <td>Pendqaftaran Gel. 1</td>
                                        <td>Aula</td>
                                    </tr>
                                  </tr>					</td>
                  <tr><td rowspan='1' align='center' >2 mei - 5 mei 2017</td>
                                      <td>08.00 - 17.00</td>
                                      <td>daftar ulang</td>
                                      <td>aula kampus</td>
                                  </tr>					</td>
                  </table></center></td>                  </table>
            </div>
        </div>
    </div>
</div>                            </article>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>

    </div>

    <div class="dialog" id="source" style="display: none;" title="Source"></div>

<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs1.uzone.id/2fn7a2/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582CL4NjpNgssKcm6qU7Qegkuwkkcq3Bc6IGckjEAlhagb2hOjRkppGnItOhRLxWmUhKJG1UhLh2zYZyKwkV8v%2f3SyATGWcqn%2f0eKuYyd90hf0%2b%2fh2TwIT2iXA69JK5v7w03nan6ARIc53Op87Q9uDD0QbzJQmd8MLxmO3ANDOBOTHlIgplxQmJ8toAJ0gp%2fS%2flxAR5sr%2bO%2fRLBsCxBxlC5X0D4Ws1LYI8kqRtWALh8RTC3cUZ6RwowjMOA3P2wthrk%2bQPHkyXbXc%2bPmH3uhgyaoNybrxibuqAvj9yXEs9GfBXogHXq4p3dVsj4Xqjb3B62RROSwvHcdLN2tb%2bglzbIdvtuyGQ4J8lTO82jYQZeIwpm3NJ8xbJ1AS36JiOqZIufmUa6DZvbOCM5eo9PeD1WVpmvxJUYx84BtWl7UJ%2f2JK2WU2Dud5LbFcyvchLameqr6z6eJGzUktbNxcG14um6YixjhvAMtpiew%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>

<!-- Mirrored from upct.siakad.org/pmb/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 10 Apr 2017 14:12:34 GMT -->
</html>
<script>
                  updateTime();
                  function updateTime(){
                      var currentTime = new Date()
                      var hours = currentTime.getHours()
                      var minutes = currentTime.getMinutes()
                      var second = currentTime.getSeconds()
                      if (second < 10){
                        second = "0" + second
                      }
                      if (minutes < 10){
                          minutes = "0" + minutes
                      }
                      var t_str = hours + ":" + minutes + ":" + second + " ";
                      if(hours > 11){
                          t_str += "PM";
                      } else {
                          t_str += "AM";
                      }
                      document.getElementById('time_span').innerHTML = t_str;
                  }
                  setInterval(updateTime, 1000);
				
                  </script>
<script>
    
        function kiri(){
           $.ajax( {
                  type :"POST",
                  url :"http://upct.siakad.org/pmb/menuKiri",
                  cache :false,
                  success : function(msg) {
                     
                  },
                  error : function() {
                    
                  }
              });
        }
        
        // hide left panel
	function hideLeftPanelSirak() {
		jQuery('.leftpanel').css({marginLeft: '-260px'}).addClass('hide');
		jQuery('.rightpanel').css({marginLeft: 0});
		jQuery('.mainwrapper').css({backgroundPosition: '-260px 0'});
		jQuery('.footerleft').hide();
		jQuery('.footerright').css({marginLeft: 0});
        
	}
	
	// show left panel
	function showLeftPanelSirak() {
		jQuery('.leftpanel').css({marginLeft: '0px'}).removeClass('hide');
		jQuery('.rightpanel').css({marginLeft: '260px'});
		jQuery('.mainwrapper').css({backgroundPosition: '0 0'});
		jQuery('.footerleft').show();
		jQuery('.footerright').css({marginLeft: '260px'});
	}

		$(document).ready(function()
		{
         
          showLeftPanelSirak(); 
        });
    </script>