<div class="row">
	<div class="col-md-12">                
        <div class="block">
            <div class="head">                                
                <h2>Materi Pratikum</h2>                                
            </div>                                        
            <div class="data-fluid">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Semester</th>
                        <th>Download</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            </div>
        </div>

        <div class="block">
            <div class="head">                                
                <h2>Upload Hasil Pratikum</h2>                                
            </div>                                        
            <div class="data-fluid">
            <form action="mahasiswa/simpan_upload_pratikum"  enctype="multipart/form-data" method="post">
                <div class="row-form">
                    <div class="col-md-3">Nim</div>
                    <div class="col-md-9"><input class="form-control" name="nim" type="text" value="<?php echo $nim; ?>" readonly/></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Nama Lengkap</div>
                    <div class="col-md-9"><input class="form-control" name="nama" type="text" value="<?php echo $nama_lengkap; ?>" readonly/></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">File</div>
                    <div class="col-md-9">
                        <input type="file" class="form-control" name="userfile" rows="2" required>
                        <input type="hidden" name="idprodi" value="<?php echo $idprodi; ?>">
                    </div>
                </div>
                <div class="row-form">
                    <div class="col-md-3"></div>
                    <div class="col-md-9">
                        <input type="submit" name="simpan" value="Kirim" class="btn btn-primary">
                    </div>
                </div>
            </form>
            </div>
        </div>


    </div>
</div>

