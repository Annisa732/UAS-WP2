
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Nim</th>
            <th>Nama Mahasiswa</th>
            <th>Transfer Ke</th>
            <th>Jurusan yang dipilh</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    $sql = $this->db->query("SELECT * FROM pengajuan_transfer WHERE id_prodi='$idprodi'");
    foreach ($sql->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->nim; ?></td>
            <td><?php 
            $sql = $this->db->query("SELECT nama_lengkap from mahasiswa WHERE nim='$row->nim'")->row();
            echo $sql->nama_lengkap;
             ?></td>
            <td><?php echo $row->transfer_ke; ?></td>
            <td><?php echo $row->jurusan; ?></td>
            <td>
                <a href="prodi/hapus_pengajuan_transfer/<?php echo $row->id_transfer; ?>" onclick="return confirm('Anda yakin ingin menghapus <?php echo $row->nim; ?> ?')"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle"></i></button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>