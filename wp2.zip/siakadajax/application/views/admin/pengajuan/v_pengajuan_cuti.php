
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Nim</th>
            <th>Nama Mahasiswa</th>
            <th>Lama Cuti</th>
            <th>Alasan Cuti</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    $sql = $this->db->query("SELECT * FROM pengajuan_cuti WHERE id_prodi='$idprodi'");
    foreach ($sql->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->nim; ?></td>
            <td><?php 
            $sql = $this->db->query("SELECT nama_lengkap from mahasiswa WHERE nim='$row->nim'")->row();
            echo $sql->nama_lengkap;
             ?></td>
            <td><?php echo $row->lama; ?></td>
            <td><?php echo $row->alasan; ?></td>
            <td>
                <a href="prodi/hapus_pengajuan_cuti/<?php echo $row->id_pengajuan; ?>" onclick="return confirm('Anda yakin ingin menghapus <?php echo $row->nim; ?> ?')"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle"></i></button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>