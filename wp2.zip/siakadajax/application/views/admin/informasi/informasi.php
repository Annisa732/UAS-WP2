<form action="webmin/tambah_informasi" method="POST">
    <?php foreach ($data->result() as $key => $value) {
        ?>
	<div class="form-group">
        <label>Informasi</label>
        <textarea name="informasi" class="form-control"><?php echo $value->informasi ?></textarea>
    </div>
<input type="hidden" name="id_informasi" value="<?php echo $value->id_informasi ?>">

    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Simpan">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>
        <?php
    } ?>
