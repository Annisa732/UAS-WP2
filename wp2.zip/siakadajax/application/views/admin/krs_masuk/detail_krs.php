
<table width="100%" class="table table-striped table-bordered table-hover">
    <thead>
        <tr>
            <th>#</th>
            <th>Nim</th>
            <th>Kode Matkul</th>
            <th>Matkul</th>
            <th>SKS</th>
            <th>Tahun Akademik</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $nim = $this->uri->segment(3);
    $thn = $this->uri->segment(4);
    $sql = $this->db->query("SELECT * from krs,matakuliah where krs.nim = '$nim' and krs.kd_matkul=matakuliah.kd_matkul and krs.thn_akademik='$thn'");
    $no = 1;
    foreach ($sql->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->nim; ?></td>
            <td><?php echo $row->kd_matkul; ?></td>
            <td><?php echo $row->nm_matkul; ?></td>
            <td><?php echo $row->sks; ?></td>
            <td><?php echo $row->thn_akademik; ?></td>
            <td>
            <?php 
            if ($row->status == 0) {
             ?>
                <a href="dosen/rubah_krs/1/<?php echo $row->nim; ?>/<?php echo $row->kd_matkul; ?>/<?php echo $row->thn_akademik; ?>" onclick="return confirm('Anda yakin ingin merubah data ini ?')"><button class="btn btn-warning btn-xs">Belum</button></a>
            <?php } elseif ($row->status == 1) { ?>
                <a href="dosen/rubah_krs/0/<?php echo $row->nim; ?>/<?php echo $row->kd_matkul; ?>/<?php echo $row->thn_akademik; ?>" onclick="return confirm('Anda yakin ingin merubah data ini ?')"><button class="btn btn-success btn-xs">Disetujui</button></a>
            <?php } ?>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>