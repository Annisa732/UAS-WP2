
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Nim</th>
            <th>Nama</th>
            <th>Tahun Akademik</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    error_reporting(0);
    $cek = $this->db->query("SELECT tahun FROM tahun_akademik WHERE status='buka'")->row();
    $tahun = $cek->tahun;
    $nidn = $username;
    $sql = $this->db->query("SELECT DISTINCT(krs.nim),mahasiswa.nama_lengkap,krs.thn_akademik FROM krs,mahasiswa WHERE krs.nim=mahasiswa.nim AND mahasiswa.dosen_pa='$nidn' AND krs.thn_akademik='$tahun'");
    $no = 1;
    foreach ($sql->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->nim; ?></td>
            <td><?php echo $row->nama_lengkap; ?></td>
            <td><?php echo $row->thn_akademik; ?></td>
            <td>
                <a href="dosen/detail_krs/<?php echo $row->nim; ?>/<?php echo $row->thn_akademik; ?>"><button class="btn btn-primary btn-xs">Detail</button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>