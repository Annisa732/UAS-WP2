<form action="prodi/edit_pa/<?php echo $hasil->id_pa; ?>" method="POST">
	<div class="form-group">
        <label>NIDN</label>
        <select name="nidn" class="form-control">
            <option value="<?php echo $hasil->nidn ?>"><?php echo $hasil->nidn ?></option>
            <?php 
            $nidn = $this->db->query("SELECT * FROM dosen WHERE id_prodi='$idprodi'");
            foreach ($nidn->result() as $row) {
             ?>
            <option value="<?php echo $row->nidn; ?>"><?php echo $row->nidn; ?></option>
            <?php } ?>
        </select>
    </div>
    <div><?php echo form_error('nidn'); ?></div>
    <div class="form-group">
        <label>Nim Mahasiswa</label>
        <select name="nim" class="form-control">
            <option value="<?php echo $hasil->nim ?>"><?php echo $hasil->nim ?></option>
            <?php 
            $nim = $this->db->query("SELECT * FROM  mahasiswa WHERE id_prodi='$idprodi'");
            foreach ($nim->result() as $row) {
             ?>
            <option value="<?php echo $row->nim; ?>"><?php echo $row->nim; ?></option>
            <?php } ?>
        </select>
    </div>
    <div><?php echo form_error('nim'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Ubah">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>