<script type="text/javascript">
  $(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip();
  });
</script>
<table width="100%" class="table table-bordered table-hover" id="dataTables-example">
    <thead style="background-color: #bebac5">
        <tr>
            <th>#</th>
            <th>Nim</th>
            <th>Nama Mahasiswa</th>
            <th>Prodi</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($daf_mhs->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->nim; ?></td>
            <td><?php echo $row->nama_lengkap; ?></td>
            <td>
                <?php 
                $sql=$this->db->query("SELECT nm_prodi FROM prodi where id_prodi='$row->id_prodi'")->row();
                echo $sql->nm_prodi;
                 ?>
            </td>
            <td>
                <a href="prodi/mhs_nilai/<?php echo $row->nim; ?>" data-toggle="tooltip" title="Klik Tombol ini untuk input nilai!" style="cursor: pointer;" ><span>Input Nilai</span></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>
