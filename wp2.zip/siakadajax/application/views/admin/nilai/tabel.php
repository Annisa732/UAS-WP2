<script type="text/javascript">
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();
            $('.edit').click(function(){
                var id = $(this).attr('data-id');
                $.ajax({
                   url: "<?php echo base_url(); ?>webmin/edit_thn",
                   type: 'POST',
                   dataType: 'json',
                   data: "id="+id,
                })
                .done(function(data) {
                    if(data.status)
                    {
                        $('#id').val(data.id);
                        $('#thn').val(data.tahun);
                        $('#ket').val(data.ket);
                        $('#myModalLabel').html('Ubah Tahun Akademik');
                        $("#myModal").modal({backdrop: false});
                        $('.simpan').hide();
                        $('.btnUbah').show();
                    }
                })
                .fail(function() {
                    alert('gagal sistem');
                });
                return false
            });

            $('.hapus').click(function(){
                var id = $(this).attr('data-id');
                $("#mHapus").modal({backdrop: true});
                $('#batal').click(function() {
                    window.location='webmin/thn_akademik';
                });
                $('#delete').click(function(){
                    $.ajax({
                       url: "<?php echo base_url(); ?>webmin/hapus_thn",
                       type: 'POST',
                       dataType: 'json',
                       data: "id="+id,
                    })
                    .done(function(data) {
                        if(data.status)
                        {
                            //$("#mPesan").modal('show',{backdrop: 'true'});
                            //window.location="<?php echo base_url(); ?>";
                            $("#mHapus").modal("hide");
                            //mehilangkan backdrop
                            setTimeout(function(){
                                $("[data-dismiss=modal]").trigger({type: click});
                            },100)
                            $("#flash").fadeIn().html("<div class='alert alert-danger' role='alert'><b>Data berhasil dihapus</b></div>");
                            load();
                            setTimeout(function() {
                                $("#flash").fadeOut('slow');
                            }, 900);
                        }
                    })
                    .fail(function() {
                        alert('gagal sistem');
                    });
                    return false
                });
            });

            function load()
            {
                $.ajax({
                url: "<?php echo base_url(); ?>webmin/tabel_thn",
                success: function(html)
                    {
                        $("#tabel").html(html);
                    }
                });
            }

            //fungsi aktifkan status
            $(".tampilkan").click(function() {
              var nilai = $(this).val();
              var id = $(this).attr('data-id');
              //alert(nilai+" "+id);
              $.ajax({
                type: "POST",
                url: "<?php echo base_url();?>webmin/ubah_status_thn",
                data: "id="+id+"&status="+nilai,
                success: function(html){
                  $("#flash").fadeIn().html("<div class='alert alert-danger' role='alert'><b>Status berhasil dirubah</b></div>");
                  load();
                  setTimeout(function() {
                    $("#flash").fadeOut('slow');
                  }, 500);
                }
              }); 
            });
           
            $(".tidaktampilkan").click(function() {
              var nilai = $(this).val();
              var id = $(this).attr('data-id');
              $.ajax({
                type: "POST",
                url: "<?php echo base_url();?>webmin/ubah_status_thn",
                data: "id="+id+"&status="+nilai,
                success: function(html){
                  $("#flash").fadeIn().html("<div class='alert alert-danger' role='alert'><b>Status berhasil dirubah</b></div>");
                  load();
                  setTimeout(function() {
                    $("#flash").fadeOut('slow');
                  }, 500);
                }
              }); 
            }); 

        });
    </script>
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
<table width="100%" class="table table-bordered table-hover" id="dataTables-example">
    <thead style="background-color: #bebac5">
        <tr>
            <th>#</th>
            <th>Tahun</th>
            <th>Keterangan</th>
            <th>Status</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($d_thn->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->tahun; ?></td>
            <td><?php echo $row->ket; ?></td>
            <td>
              <?php if ($row->status == 'Buka') { ?>
              <form>
                <input type="radio" data-id="<?php echo $row->id_tahun; ?>" name="status" class="tampilkan" value="Buka" checked>Buka |
                <input type="radio" data-id="<?php echo $row->id_tahun; ?>" name="status" class="tidaktampilkan" value="Tutup" >Tutup
              </form>
              <?php } else { ?>
              <form>
                <input type="radio" data-id="<?php echo $row->id_tahun; ?>" name="status" class="tampilkan" value="Buka" >Buka |
                <input type="radio" data-id="<?php echo $row->id_tahun; ?>" name="status" class="tidaktampilkan" value="Tutup" checked>Tutup
              </form>
              <?php } ?>
            </td>
            <td>
                <a class="edit" data-toggle="tooltip" title="Klik Tombol ini untuk merubah data!" style="cursor: pointer;" data-id="<?php echo $row->id_tahun; ?>"><i class="glyphicon glyphicon-edit"></i></a>
                <a class="hapus" data-toggle="tooltip" title="Klik Tombol ini untuk hapus data!" style="cursor: pointer;" data-id="<?php echo $row->id_tahun; ?>"><i class="glyphicon glyphicon-trash"></i></a>

            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>