<table class="table">
    <tr>
        <td width="20%">Nim</td>
        <td>:</td>
        <td><?php echo $this->uri->segment(4); ?></td>
    </tr>
    <tr>
        <td width="20%">Nama Lengkap</td>
        <td>:</td>
        <td><?php 
        $nim = $this->uri->segment(4);
        $sql = $this->db->query("SELECT nama_lengkap FROM mahasiswa WHERE nim='$nim'")->row();
        echo $sql->nama_lengkap;
             ?></td>
    </tr>
    <tr>
        <td>Semester</td>
        <td>:</td>
        <td>
            <?php 
            echo $this->uri->segment(3);
             ?>
        </td>
    </tr>
</table>
<div class="table-responsive">
<table width="100%" class="table table-bordered table-hover" >
    <thead style="background-color: #bebac5">
        <tr>
            <th>No</th>
            <th>Kode Matkul</th>
            <th>Matkul</th>
            <th>Absen</th>
            <th>Kuis</th>
            <th>Mid</th>
            <th>Uas</th>
            <th>Total</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($daf_krs->result() as $row) {
     ?>
     <form action="prodi/simpan_nilai" method="POST">
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->kd_matkul; ?></td>
            <td>
                <?php 
                $sql = $this->db->query("SELECT * FROM matakuliah WHERE kd_matkul='$row->kd_matkul'")->row();
                echo $sql->nm_matkul;
                 ?>
            </td>
            <td>
                <input type="text" name="absen" value="<?php echo $row->absen; ?>">
                <input type="hidden" name="nim" value="<?php echo $this->uri->segment(4);?>"> 
                <input type="hidden" name="thn" value="<?php echo $this->uri->segment(3);?>"> 
                <input type="hidden" name="kdmk" value="<?php echo $row->kd_matkul;?>"> 
            </td>
            <td>
                <input type="text" name="kuis" value="<?php echo $row->kuis; ?>">
            </td>
            <td>
                <input type="text" name="mid" value="<?php echo $row->mid; ?>">
            </td>
            <td>
                <input type="text" name="uas" value="<?php echo $row->uas; ?>">
            </td>
            <td>
                <b><?php echo $row->total; ?></b>
            </td>
            <td>
                <button type="submit" class="btn btn-success">Simpan</button>
            </td>
        </tr>
    </form>
    <?php $no++; } ?>
    </tbody>
</table>
</div>