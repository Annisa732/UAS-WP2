<script type="text/javascript">
  $(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip();
  });
</script>
<table width="100%" class="table table-bordered table-hover" id="dataTables-example">
    <thead style="background-color: #bebac5">
        <tr>
            <th>#</th>
            <th>Tahun Ajaran</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($d_thn->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->tahun; ?></td>
            <td>
                <a href="prodi/daftar_nilai/<?php echo $row->tahun; ?>/<?php echo $this->uri->segment(3); ?>" data-toggle="tooltip" title="Klik Tombol ini melihat data!" style="cursor: pointer;" ><span>Lihat</span></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>
