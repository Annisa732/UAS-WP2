
<button class="btn btn-primary tambah" data-toggle="modal" data-target="#myModal" data-backdrop="false">Tambah</button><br><br>

<div id="flash"></div>
<!-- data tabel -->
<div id="tabel">
</div>

<!-- Modal -->
    <div class="modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header" style="background-color: #a06feb;">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <h4 class="modal-title" id="myModalLabel">Tambah Tahun Akademik</h4>
          </div>
          <div class="modal-body">
            <form action="" method="POST" id="myData">
                <div class="form-group">
                    <label>Tahun</label>
                    <input type="hidden" name="id" id="id">
                    <input class="form-control" id="thn" name="thn" placeholder="20171">
                </div>
                <div class="form-group">
                    <label>Keterangan</label>
                    <textarea rows="2" class="form-control" id="ket" name="ket" placeholder="2017 Ganjil"></textarea>
                </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary simpan">Simpan</button>
            <button type="button" class="btn btn-info btnUbah">Edit</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="mHapus" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-sm">
        <div class="modal-content">
          <div class="modal-body">
            yakin akan hapus data ini ?<br>
          </div>
          <div class="modal-footer">
            <button type="button" id="batal" class="btn btn-default" data-dismiss="modal">Close</button>
            <button id="delete" class="btn btn-danger">Hapus</button>
          </div>
        </div>
      </div>
    </div>

<script type="text/javascript">
        $(document).ready(function() {
            
            load();

            function load()
            {
                $.ajax({
                url: "<?php echo base_url(); ?>webmin/tabel_thn",
                success: function(html)
                    {
                        $("#tabel").html(html);
                    }
                });
            }

            $('.tambah').click(function(){
                $('#thn').val('');
                $('#ket').val('');
                $('.btnUbah').hide();
                $('.simpan').show();
            });

            $('.simpan').click(function(){
                $.ajax({
                    url: '<?php echo base_url(); ?>webmin/simpan_thn',
                    type: 'POST',
                    dataType: 'json',
                    data: $('#myData').serialize(),
                })
                .done(function(data) {
                    if(data.status)
                    {
                        //alert("Sukses");
                        //window.location="<?php echo base_url(); ?>";
                        $("#myModal").modal("hide");
                        $("#flash").fadeIn().html("<div class='alert alert-success' role='alert'><b>Data berhasil ditambahkan</b></div>");
                        setTimeout(function() {
                            $("#flash").fadeOut('slow');
                            load();
                        }, 500);
                    }
                })
                .fail(function() {
                    alert('gagal sistem');
                });
                return false
            });

            $('.btnUbah').click(function(){
                $.ajax({
                    url: '<?php echo base_url(); ?>webmin/ubah_thn',
                    type: 'POST',
                    dataType: 'json',
                    data: $('#myData').serialize(),
                })
                .done(function(data) {
                    if(data.status)
                    {
                        //alert(data.pesan);
                        //window.location="<?php echo base_url(); ?>";
                        $("#myModal").modal("hide");
                        $("#flash").fadeIn().html("<div class='alert alert-info' role='alert'><b>Data berhasil diubah</b></div>");
                        setTimeout(function() {
                            $("#flash").fadeOut('slow');
                            load();
                        }, 500);
                    }
                })
                .fail(function() {
                    alert('gagal sistem');
                });
                return false
            });


        });
    </script>