
<button class="btn btn-primary tambah" data-toggle="modal" data-target="#myModal" data-backdrop="false">Tambah</button><br><br>

<div id="flash"></div>
<!-- data tabel -->
<div id="tabel">
</div>

<!-- Modal -->
    <div class="modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header" style="background-color: #a06feb;">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <h4 class="modal-title" id="myModalLabel">Tambah Mahasiswa</h4>
          </div>
          <div class="modal-body">
            <form action="" method="POST" id="myData" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Nim</label>
                    <input type="hidden" name="id" id="id">
                    <input class="form-control" id="nim" name="nim" >
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input class="form-control" id="pass" name="pass" >
                </div>
                <div class="form-group">
                    <label>Nama</label>
                    <input class="form-control" id="nama" name="nama" >
                </div>
                <div class="form-group">
                    <label>Tempat Lahir</label>
                    <input class="form-control" id="tempat" name="tempat" >
                </div>
                <div class="form-group">
                    <label>Tanggal Lahir</label>
                    <input type="date" class="form-control" id="tgl" name="tgl" >
                </div>
                <div class="form-group">
                    <label>No Hp</label>
                    <input type="number" class="form-control" id="nohp" name="nohp" >
                </div>
                <div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select class="form-control" name="jk" id="jk" required>
                        <option value="">Pilih Jenis Kelamin</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Prodi</label>
                    <select class="form-control" name="idprodi" id="idprodi" required>
                        <option value="">Pilih Prodi</option>
                    <?php 
                    foreach ($d_prodi->result() as $prodi) {
                     ?>
                        <option value="<?php echo $prodi->id_prodi; ?>"><?php echo $prodi->nm_prodi; ?></option>
                    <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <textarea rows="2" class="form-control" id="alamat" name="alamat" ></textarea>
                </div>
                <div class="form-group">
                    <label>Dosen PA</label>
                    <select name="dosen" id="dosen" class="form-control">
                    <?php 
                    $r = $this->db->get('dosen');
                    foreach ($r->result() as $d) {
                     ?>
                        <option value="<?php echo $d->nidn; ?>"><?php echo $d->nm_dosen; ?></option>
                    <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Foto Mahasiswa</label>
                    <input type="file" name="userfile" id="f-file" class="form-control">
                </div>
                <div id="foto-sebelumnya" style="display: none;">
                    ss
                </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary simpan">Simpan</button>
            <button type="button" class="btn btn-info btnUbah">Edit</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal -->
    <div class="modal" id="myDetail" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header" style="background-color: #a06feb;">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <h4 class="modal-title" id="myModalLabel">Detail Mahasiswa</h4>
          </div>
          <div class="modal-body">
            <div class="row">
                <div class="col-md-12">
                    <table class="table">
                        <tr>
                            <td>Nim</td>
                            <td>:</td>
                            <td><div id="vnim"></div></td>
                            <td><div id="vfoto"></div></td>
                        </tr>
                        <tr>
                            <td>Password</td>
                            <td>:</td>
                            <td><div id="vpass"></div></td>
                        </tr>
                        <tr>
                            <td>Nama Lengkap</td>
                            <td>:</td>
                            <td><div id="vnama"></div></td>
                        </tr>
                        <tr>
                            <td>Tempat Lahir</td>
                            <td>:</td>
                            <td><div id="vtempat"></div></td>
                        </tr>
                        <tr>
                            <td>Tanggal Lahir</td>
                            <td>:</td>
                            <td><div id="vtgl"></div></td>
                        </tr>
                        <tr>
                            <td>Jenis Kelamin</td>
                            <td>:</td>
                            <td><div id="vjk"></div></td>
                        </tr>
                        <tr>
                            <td>No Hp</td>
                            <td>:</td>
                            <td><div id="vnohp"></div></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><div id="valamat"></div></td>
                        </tr>
                        <tr>
                            <td>Prodi</td>
                            <td>:</td>
                            <td><div id="vidprodi"></div></td>
                        </tr>
                        <tr>
                            <td>Dosen PA</td>
                            <td>:</td>
                            <td><div id="vdosen"></div></td>
                        </tr>
                    </table>
                </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="mHapus" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-sm">
        <div class="modal-content">
          <div class="modal-body">
            yakin akan hapus data ini ?<br>
          </div>
          <div class="modal-footer">
            <button type="button" id="batal" class="btn btn-default" data-dismiss="modal">Close</button>
            <button id="delete" class="btn btn-danger">Hapus</button>
          </div>
        </div>
      </div>
    </div>

<script type="text/javascript">
        $(document).ready(function() {
            
            load();

            function load()
            {
                $.ajax({
                url: "<?php echo base_url(); ?>webmin/tabel_mhs",
                success: function(html)
                    {
                        $("#tabel").html(html);
                    }
                });
            }

            $('.tambah').click(function(){
                $('#nim').val('');
                $('#pass').val('');
                $('#nama').val('');
                $('#alamat').val('');
                $('#nohp').val('');
                $('#tempat').val('');
                $('#tgl').val('');
                $('#idprodi').val('');
                $('#jk').val('');
                $('#dosen').val('');
                $('#f-file').val('');
                $('.btnUbah').hide();
                $('.simpan').show();
            });

            $('.simpan').click(function(){
                var formdata = new FormData();      
                 var file = $('#f-file')[0].files[0];
                  formdata.append('userfile', file);
                  $.each($('#myData').serializeArray(), function(a, b){
                    formdata.append(b.name, b.value);
                  });
                $.ajax({
                    url: '<?php echo base_url(); ?>webmin/simpan_mhs',
                    type: 'POST',
                    dataType: 'json',
                    data: formdata,
                    processData: false,
                    contentType: false,
                })
                .done(function(data) {
                    if(data.status)
                    {
                        //alert("Sukses");
                        //window.location="<?php echo base_url(); ?>";
                        $("#myModal").modal("hide");
                        $("#flash").fadeIn().html("<div class='alert alert-success' role='alert'><b>Data berhasil ditambahkan</b></div>");
                        setTimeout(function() {
                            $("#flash").fadeOut('slow');
                            load();
                        }, 500);
                    }
                })
                .fail(function() {
                    alert('gagal sistem');
                });
                return false
            });

            $('.btnUbah').click(function(){
                var formdata = new FormData();      
                 var file = $('#f-file')[0].files[0];
                  formdata.append('userfile', file);
                  $.each($('#myData').serializeArray(), function(a, b){
                    formdata.append(b.name, b.value);
                  });
                $.ajax({
                    url: '<?php echo base_url(); ?>webmin/ubah_mhs',
                    type: 'POST',
                    dataType: 'json',
                    data: formdata,
                    processData: false,
                    contentType: false,
                })
                .done(function(data) {
                    if(data.status)
                    {
                        //alert(data.pesan);
                        //window.location="<?php echo base_url(); ?>";
                        $("#myModal").modal("hide");
                        $("#flash").fadeIn().html("<div class='alert alert-info' role='alert'><b>Data berhasil diubah</b></div>");
                        setTimeout(function() {
                            $("#flash").fadeOut('slow');
                            load();
                        }, 500);
                    }
                })
                .fail(function() {
                    $("#myModal").modal("hide");
                        $("#flash").fadeIn().html("<div class='alert alert-info' role='alert'><b>Data berhasil diubah</b></div>");
                        setTimeout(function() {
                            $("#flash").fadeOut('slow');
                            load();
                        }, 500);
                });
                return false
            });


        });
    </script>