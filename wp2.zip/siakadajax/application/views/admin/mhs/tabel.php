<script type="text/javascript">
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();
            $('.edit').click(function(){
                var id = $(this).attr('data-id');
                $.ajax({
                   url: "<?php echo base_url(); ?>webmin/edit_mhs",
                   type: 'POST',
                   dataType: 'json',
                   data: "id="+id,
                })
                .done(function(data) {
                    if(data.status)
                    {
                        $('#id').val(data.id);
                        $('#nim').val(data.nim);
                        $('#pass').val(data.pass);
                        $('#nama').val(data.nama);
                        $('#alamat').val(data.alamat);
                        $('#nohp').val(data.nohp);
                        $('#tempat').val(data.tempat);
                        $('#tgl').val(data.tgl);
                        $('#idprodi').val(data.idprodi);
                        $('#jk').val(data.jk);
                        $('#dosen').val(data.dosen);
                        $('#foto-sebelumnya').show().html(" *) Foto Sebelumnya <br><img src='image/mhs/thumbnails/"+data.foto+"'>");
                        $('#myModalLabel').html('Ubah Mahasiswa');
                        $("#myModal").modal({backdrop: false});
                        $('.simpan').hide();
                        $('.btnUbah').show();
                    }
                })
                .fail(function() {
                    alert('gagal sistem');
                });
                return false
            });

            $('.detail-mhs').click(function(){
                var id = $(this).attr('data-id');
                $.ajax({
                   url: "<?php echo base_url(); ?>webmin/detail_mhs",
                   type: 'POST',
                   dataType: 'json',
                   data: "id="+id,
                })
                .done(function(data) {
                    if(data.status)
                    {
                        $('#vid').html(data.id);
                        $('#vnim').html(data.nim);
                        $('#vpass').html(data.pass);
                        $('#vnama').html(data.nama);
                        $('#valamat').html(data.alamat);
                        $('#vnohp').html(data.nohp);
                        $('#vtempat').html(data.tempat);
                        $('#vtgl').html(data.tgl);
                        $('#vidprodi').html(data.idprodi);
                        $('#vdosen').html(data.dosen);
                        $('#vjk').html(data.jk);
                        $('#vfoto').show().html("<img src='image/mhs/thumbnails/"+data.foto+"'>");
                        $("#myDetail").modal({backdrop: false});
                    }
                })
                .fail(function() {
                    alert('gagal sistem');
                });
                return false
            });

            $('.hapus').click(function(){
                var foto = $(this).attr('foto');
                var id = $(this).attr('data-id');
                $("#mHapus").modal({backdrop: true});
                $('#batal').click(function() {
                    window.location='webmin/mahasiswa';
                });
                $('#delete').click(function(){
                    $.ajax({
                       url: "<?php echo base_url(); ?>webmin/hapus_mhs",
                       type: 'POST',
                       dataType: 'json',
                       data: "id="+id+"&foto="+foto,
                    })
                    .done(function(data) {
                        if(data.status)
                        {
                            //$("#mPesan").modal('show',{backdrop: 'true'});
                            //window.location="<?php echo base_url(); ?>";
                            $("#mHapus").modal("hide");
                            //mehilangkan backdrop
                            setTimeout(function(){
                                $("[data-dismiss=modal]").trigger({type: click});
                            },100)
                            $("#flash").fadeIn().html("<div class='alert alert-danger' role='alert'><b>Data berhasil dihapus</b></div>");
                            load();
                            setTimeout(function() {
                                $("#flash").fadeOut('slow');
                            }, 900);
                        }
                    })
                    .fail(function() {
                        alert('gagal sistem');
                    });
                    return false
                });
            });

            function load()
            {
                $.ajax({
                url: "<?php echo base_url(); ?>webmin/tabel_mhs",
                success: function(html)
                    {
                        $("#tabel").html(html);
                    }
                });
            }

        });
    </script>
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
<table width="100%" class="table table-bordered table-hover" id="dataTables-example">
    <thead style="background-color: #bebac5">
        <tr>
            <th>Nim</th>
            <th>Nama Lengkap</th>
            <th>Alamat</th>
            <th>Prodi</th>
            <th>Foto</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($d_mhs->result() as $row) {
     ?>
        <tr>
            <td><?php echo $row->nim; ?></td>
            <td><?php echo $row->nama_lengkap; ?></td>
            <td><?php echo $row->alamat; ?></td>
            <td><?php echo $row->nm_prodi; ?></td>
            <td><img src="image/mhs/thumbnails/<?php echo $row->foto_mahasiswa; ?>"></td>
            <td>
                <a class="detail-mhs" data-toggle="tooltip" title="Detail Mahasiswa!" style="cursor: pointer;" data-id="<?php echo $row->id_mahasiswa; ?>"><i class="glyphicon glyphicon-search"></i></a>
                <a class="edit" data-toggle="tooltip" title="Klik Tombol ini untuk merubah data!" style="cursor: pointer;" data-id="<?php echo $row->id_mahasiswa; ?>"><i class="glyphicon glyphicon-edit"></i></a>
                <a class="hapus" data-toggle="tooltip" title="Klik Tombol ini untuk hapus data!" style="cursor: pointer;" foto="<?php echo $row->foto_mahasiswa; ?>" data-id="<?php echo $row->id_mahasiswa; ?>"><i class="glyphicon glyphicon-trash"></i></a>

            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>