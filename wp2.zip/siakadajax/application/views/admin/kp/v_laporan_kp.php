
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Nim</th>
            <th>Nama Mahasiswa</th>
            <th>File Laporan</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    $sql = $this->db->query("SELECT * FROM upload_kp WHERE id_prodi='$idprodi'");
    foreach ($sql->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->nim; ?></td>
            <td><?php 
            $sql = $this->db->query("SELECT nama_lengkap from mahasiswa WHERE nim='$row->nim'")->row();
            echo $sql->nama_lengkap;
             ?></td>
            <td><a href="files/<?php echo $row->nm_file; ?>">Download Laporan</a></td>
            <td>
                <a href="prodi/hapus_laporan_kp/<?php echo $row->id_upload; ?>" onclick="return confirm('Anda yakin ingin menghapus <?php echo $row->nim; ?> ?')"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle"></i></button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>