<form action="webmin/tambah_kelas" method="POST">
	<div class="form-group">
        <label>Nama Kelas</label>
        <input class="form-control" name="kelas" placeholder="Nama kelas">
    </div>
    <div><?php echo form_error('kelas'); ?></div>
    <div class="form-group">
        <label>Prodi</label>
        <select name="idprodi" class="form-control">
        	<option value="">Pilih Prodi</option>
        <?php 
        foreach ($d_prodi->result() as $prodi) {
         ?>
        	<option value="<?php echo $prodi->id_prodi; ?>"><?php echo $prodi->nm_prodi; ?></option>
        <?php } ?>
        </select>
    </div>
    <div><?php echo form_error('idprodi'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Simpan">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>