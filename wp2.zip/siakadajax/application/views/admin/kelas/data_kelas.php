<a href="webmin/tambah_kelas" class="btn btn-primary">Tambah Kelas</a><br><br>
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Nama Kelas</th>
            <th>Prodi</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($d_kelas->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->kelas; ?></td>
            <td><?php echo $row->nm_prodi; ?></td>
            <td>
                <a href="webmin/edit_kelas/<?php echo $row->id_kelas; ?>"><button class="btn btn-info btn-xs"><i class="fa fa-pencil-square"></i></button></a>
                <a href="webmin/hapus_kelas/<?php echo $row->id_kelas; ?>" onclick="return confirm('Anda yakin ingin menghapus <?php echo $row->kelas; ?> ?')"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle"></i></button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>