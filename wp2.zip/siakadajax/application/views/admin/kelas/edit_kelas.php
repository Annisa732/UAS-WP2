<form action="webmin/edit_kelas/<?php echo $hasil->id_kelas; ?>" method="POST">
	<div class="form-group">
        <label>Nama Kelas</label>
        <input class="form-control" name="kelas" value="<?php echo $hasil->kelas; ?>">
    </div>
    <div><?php echo form_error('kelas'); ?></div>
    <div class="form-group">
        <label>Prodi</label>
        <select name="idprodi" class="form-control">
        <?php 
        $id = $hasil->id_prodi;
        $b = $this->db->query("SELECT * FROM prodi WHERE id_prodi='$id'")->row();
         ?>
        	<option value="<?php echo $b->id_prodi ?>"><?php echo $b->nm_prodi; ?></option>
        <?php 
        foreach ($d_prodi->result() as $prodi) {
         ?>
        	<option value="<?php echo $prodi->id_prodi; ?>"><?php echo $prodi->nm_prodi; ?></option>
        <?php } ?>
        </select>
    </div>
    <div><?php echo form_error('idprodi'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Ubah">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>