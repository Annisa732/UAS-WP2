<style type="text/css">
    #outtable{
      padding: 20px;
      border:1px solid #e3e3e3;
      width:600px;
      border-radius: 5px;
    }
 
    .short{
      width: 50px;
    }
 
    .normal{
      width: 150px;
    }
 
    table{
      border-collapse: collapse;
      font-family: arial;
      color:#5E5B5C;
    }
 
    thead th{
      text-align: left;
      padding: 10px;
    }
 
    tbody td{
      border-top: 1px solid #e3e3e3;
      padding: 10px;
    }
 
    tbody tr:nth-child(even){
      background: #F6F5FA;
    }
 
    tbody tr:hover{
      background: #EAE9F5
    }
  </style>
<h2 align="center">Transkrip Nilai</h2>
<table class="table">
    <tr>
        <td width="20%">Nim</td>
        <td>:</td>
        <td><?php echo $this->uri->segment(4); ?></td>
    </tr>
    <tr>
        <td width="20%">Nama Lengkap</td>
        <td>:</td>
        <td><?php 
        $nim = $this->uri->segment(4);
        $sql = $this->db->query("SELECT nama_lengkap FROM mahasiswa WHERE nim='$nim'")->row();
        echo $sql->nama_lengkap;
             ?></td>
    </tr>
</table>
<div class="table-responsive">
<table width="100%" class="table table-bordered table-hover" border="1">
    <thead style="background-color: #bebac5">
        <tr>
            <th>NO</th>
            <th>KODE MK</th>
            <th>MATA KULIAH</th>
            <th>SKS</th>
            <th>NILAI</th>
            <th>INDEK</th>
            <th>BOBOT</th>
            <th>HASIL</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    if ($daf_khs->num_rows() == 0) {
    ?>
        <tr>
            <td colspan="8">Transkrip nilai masih Kosong</td>
        </tr>
    <?php
    } else {
    $jumsks = 0;
    $jumhasil = 0;
    $no = 1;
    foreach ($daf_khs->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->kd_matkul; ?></td>
            <td>
                <?php 
                $sql = $this->db->query("SELECT * FROM matakuliah WHERE kd_matkul='$row->kd_matkul'")->row();
                echo $sql->nm_matkul;
                 ?>
            </td>
            <td><?php echo $sql->sks ?></td>
            <td><?php echo number_format($row->total, 2); ?></td>
            <td><?php 
            $nilai = $row->total;
            if ($nilai >=80.00 && $nilai <=100.00) {
                $huruf = "A";
            } elseif ($nilai >=68.00 && $nilai <=79.99) {
                $huruf = "B";
            } elseif ($nilai >=56.00 && $nilai <=67.99) {
                $huruf = "C";
            } elseif ($nilai >=45.00 && $nilai <=55.99) {
                $huruf = "D";
            } elseif ($nilai >=00.00 && $nilai <=44.99) {
                $huruf = "E";
            } 
            echo $huruf;
            ?></td>
            <td>
                <?php 
                if ($huruf == "A") {
                    $bobot =4.0;
                } elseif ($huruf == "B") {
                    $bobot = 3.0;
                } elseif ($huruf == "C") {
                    $bobot = 2.0;
                } elseif ($huruf == "D") {
                    $bobot = 1.0;
                } elseif ($huruf == "E") {
                    $bobot = 0.0;
                } 
                echo number_format($bobot,1);
                 ?>
            </td>
            <td>
                <?php $hasil = $sql->sks * $bobot; echo $hasil; ?>
            </td>
            
        </tr>
    <?php $jumsks +=$sql->sks; $jumhasil +=$hasil; $no++; } ?>
        <tr>
            <td colspan="3" align="right">Jumlah</td>
            <td><?php echo $jumsks; ?></td>
            <td colspan="3"></td>
            <td><?php echo $jumhasil; ?></td>
        </tr>
        <tr>
           <td colspan="3" align="right">Indeks Prestasi</td>
           <td colspan="5" align="center"><b>
           <?php
            $ip = number_format($jumhasil/$jumsks, 2); 
            //cek ip sudah ada apa belum
            $nim = $this->uri->segment(4);
            $thn = $this->uri->segment(3);
            $cek = $this->db->query("SELECT * FROM ipk_mhs WHERE nim='$nim' and thn_akademik='$thn'");
            if ($cek->num_rows() == 0) {
                $data = array('nim' => $nim,
                              'ipk' => $ip,
                              'thn_akademik' => $thn);
                $this->db->insert('ipk_mhs', $data);
            } else {
                $data = array('ipk' => $ip);
                $this->db->where('nim', $nim);
                $this->db->where('thn_akademik', $thn);
                $this->db->update('ipk_mhs', $data);

            } 
            echo $ip; 

            ?></b></td> 
        </tr>
        <?php } ?>
    </tbody>
</table>
</div>