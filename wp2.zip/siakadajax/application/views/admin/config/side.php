<div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <?php 
                        if ($this->session->userdata('level') == 'admin') {
                         ?>
                        <!-- menu admin -->
                        <li>
                            <a href="webmin/"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                         <li>
                            <a href="webmin/informasi"><i class="fa fa-dashboard fa-fw"></i> Informasi</a>
                        </li>
                        <li>
                            <a href="webmin/semester"><i class="fa fa-th-list"></i> Data Semester</a>
                        </li>
                        <li>
                            <a href="webmin/mahasiswa"><i class="fa fa-male"></i> Data Mahasiswa</a>
                        </li>
                        <li>
                            <a href="webmin/thn_akademik"><i class="fa fa-sun-o"></i> Tahun Ajaran</a>
                        </li>
                        <li>
                            <a href="webmin/kelas"><i class="fa fa-institution"></i> Data Kelas</a>
                        </li>
                        <li>
                            <a href="webmin/user"><i class="fa fa-user"></i> Data User</a>
                        </li>
                        <li>
                            <a href="webmin/logout"><i class="fa fa-sign-in"></i> Logout</a>
                        </li>
                        <?php } elseif ($this->session->userdata('level') == 'prodi') { ?>
                        <!-- menu prodi -->
                        <li>
                            <a href="prodi/"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="prodi/matkul"><i class="fa fa-th-list"></i> Matakuliah</a>
                        </li>
                        <li>
                            <a href="prodi/dosen"><i class="fa fa-male"></i> Data Dosen</a>
                        </li>
                        <li>
                            <a href="prodi/jadwal_matkul"><i class="fa fa-cubes"></i> Jadwal Matakuliah</a>
                        </li>
                        <li>
                            <a href="prodi/nilai"><i class="fa fa-institution"></i> Data Nilai</a>
                        </li>
                        <li>
                            <a href="prodi/khs"><i class="fa fa-institution"></i> Data KHS</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Kerja Praktek<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="prodi/daftar_kp">Daftar Mahasiswa Kerja Praktek</a>
                                </li>
                                <li>
                                    <a href="prodi/laporan_kp">Laporan Kerja Praktek</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-book fa-fw"></i> Pengajuan<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="prodi/pengajuan_cuti">Pengajuan Cuti</a>
                                </li>
                                <li>
                                    <a href="prodi/pengajuan_transfer">Pengajuan Transfer</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="prodi/logout"><i class="fa fa-sign-in"></i> Logout</a>
                        </li>
                        <?php } elseif ($this->session->userdata('level') == 'dosen') { ?>
                        <li>
                            <a href="dosen/krs_masuk"><i class="fa fa-th-list"></i> KRS Mahasiswa <span class="label label-danger">
                                <?php 
                                $nidn = $this->session->userdata('username');
                                $jml = $this->db->query("SELECT DISTINCT(krs.nim),mahasiswa.nama_lengkap,krs.thn_akademik FROM krs,mahasiswa WHERE krs.nim=mahasiswa.nim AND mahasiswa.dosen_pa='$nidn'");
                                $j = $jml->num_rows();
                                echo $j;
                                 ?>
                            </span></a>
                        </li>
                        <li>
                            <a href="dosen/logout"><i class="fa fa-sign-in"></i> Logout</a>
                        </li>
                        <?php } ?>
                    </ul>
                </div>