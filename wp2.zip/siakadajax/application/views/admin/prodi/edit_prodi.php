<form action="webmin/edit_prodi/<?php echo $hasil->id_prodi; ?>" method="POST">
	<div class="form-group">
        <label>Nama Prodi</label>
        <input class="form-control" name="prodi" value="<?php echo $hasil->nm_prodi; ?>">
    </div>
    <div><?php echo form_error('prodi'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Ubah">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>