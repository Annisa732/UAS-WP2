<form action="webmin/tambah_prodi" method="POST">
	<div class="form-group">
        <label>Nama Prodi</label>
        <input class="form-control" name="prodi" placeholder="Nama Prodi">
    </div>
    <div><?php echo form_error('prodi'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Simpan">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>