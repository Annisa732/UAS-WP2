<form action="webmin/tambah_user" method="POST">
    <div class="form-group">
        <label>Username</label>
        <input class="form-control" name="username">
    </div>
    <div><?php echo form_error('username'); ?></div>
    <div class="form-group">
        <label>Nama lengkap</label>
        <input class="form-control" name="nama">
    </div>
    <div><?php echo form_error('nama'); ?></div>
    <div class="form-group">
        <label>Password</label>
        <input class="form-control" name="password">
    </div>
    <div><?php echo form_error('password'); ?></div>
    <div class="form-group">
        <label>Prodi</label>
        <select class="form-control" name="idprodi">
            <?php 
            $sql = $this->db->query("SELECT * FROM prodi");
            foreach ($sql->result() as $prodi) {
             ?>
            <option value="<?php echo $prodi->id_prodi; ?>"><?php echo $prodi->nm_prodi; ?></option>
            <?php } ?>
        </select>
    </div>
     <div class="form-group">
        <label>Level</label>
        <select class="form-control" name="level">
            
            <option value="admin">Admin</option>
             <option value="prodi">Prodi</option>
             <option value="dosen">Dosen</option>
           
        </select>
    </div>
    <div><?php echo form_error('prodi'); ?></div>
    <div class="form-group">
        <input type="submit" class="btn btn-primary" name="simpan" value="Simpan">
        <input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>