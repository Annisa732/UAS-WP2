<form action="webmin/data_user/<?php echo $hasil->id_user; ?>" method="POST">
	<div class="form-group">
        <label>Username</label>
        <input class="form-control" name="username" value="<?php echo $hasil->username; ?>">
    </div>
    <div><?php echo form_error('username'); ?></div>
	<div class="form-group">
        <label>Nama Lengkap</label>
        <input class="form-control" name="nama" value="<?php echo $hasil->nama; ?>">
    </div>
    <div><?php echo form_error('nama'); ?></div>
    <div class="form-group">
<label>Password</label>
        <input class="form-control" name="password" value="<?php echo $hasil->password; ?>">
    </div>
    <div><?php echo form_error('password'); ?></div>
    <div class="form-group">
<label>Prodi</label>
        <input class="form-control" name="idprodi" value="<?php echo $hasil->idprodi; ?>">
    </div>
    <div><?php echo form_error('idprodi'); ?></div>
    <div class="form-group">

    	<input type="submit" class="btn btn-primary" name="simpan" value="Ubah">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>
