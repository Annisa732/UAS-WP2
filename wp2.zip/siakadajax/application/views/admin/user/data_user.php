<a href="webmin/tambah_user" class="btn btn-primary">Tambah PUser</a><br><br>
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Username</th>
            <th>Nama Lengkap</th>
            <th>Level</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($d_user->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->username; ?></td>
            <td><?php echo $row->nama_lengkap; ?></td>
            <td><?php echo $row->level; ?></td>
            <td>
                <a href="webmin/hapus_user/<?php echo $row->id_user; ?>" onclick="return confirm('Anda yakin ingin menghapus user <?php echo $row->nama_lengkap; ?> ?')"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle"></i></button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>