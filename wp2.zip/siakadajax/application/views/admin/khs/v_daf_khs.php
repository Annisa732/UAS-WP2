<table class="table">
    <tr>
        <td width="20%">Nim</td>
        <td>:</td>
        <td><?php echo $this->uri->segment(4); ?></td>
    </tr>
    <tr>
        <td width="20%">Nama Lengkap</td>
        <td>:</td>
        <td><?php 
        $nim = $this->uri->segment(4);
        $sql = $this->db->query("SELECT nama_lengkap FROM mahasiswa WHERE nim='$nim'")->row();
        echo $sql->nama_lengkap;
             ?></td>
    </tr>
    <tr>
        <td>Semester</td>
        <td>:</td>
        <td>
            <?php 
            $t = $this->uri->segment(3);
            $d = substr($t, 4, 1);
            $y = substr($t, 0, 4);
            if ($d == 1) {
                $x = "Ganjil";
            } elseif ($d == 2) {
                $x = "Genap";
            }
            echo $y." ".$x;
             ?>
        </td>
    </tr>
</table>
<div class="table-responsive">
<table width="100%" class="table table-bordered table-hover" >
    <thead style="background-color: #bebac5">
        <tr>
            <th>No</th>
            <th>Kode Matkul</th>
            <th>Matkul</th>
            <th>SKS</th>
            <th>NILAI</th>
            <th>INDEK</th>
            <th>BOBOT</th>
            <th>HASIL</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    if ($daf_khs->num_rows() == 0) {
    ?>
        <tr>
            <td colspan="8">KHS masih Kosong</td>
        </tr>
    <?php
    } else {
    $jumsks = 0;
    $jumhasil = 0;
    $no = 1;
    foreach ($daf_khs->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->kd_matkul; ?></td>
            <td>
                <?php 
                $sql = $this->db->query("SELECT * FROM matakuliah WHERE kd_matkul='$row->kd_matkul'")->row();
                echo $sql->nm_matkul;
                 ?>
            </td>
            <td><?php echo $sql->sks ?></td>
            <td><?php echo number_format($row->total, 2); ?></td>
            <td><?php 
            $nilai = $row->total;
            if ($nilai >=80.00 && $nilai <=100.00) {
                $huruf = "A";
            } elseif ($nilai >=68.00 && $nilai <=79.99) {
                $huruf = "B";
            } elseif ($nilai >=56.00 && $nilai <=67.99) {
                $huruf = "C";
            } elseif ($nilai >=45.00 && $nilai <=55.99) {
                $huruf = "D";
            } elseif ($nilai >=00.00 && $nilai <=44.99) {
                $huruf = "E";
            } 
            echo $huruf;
            ?></td>
            <td>
                <?php 
                if ($huruf == "A") {
                    $bobot =4.0;
                } elseif ($huruf == "B") {
                    $bobot = 3.0;
                } elseif ($huruf == "C") {
                    $bobot = 2.0;
                } elseif ($huruf == "D") {
                    $bobot = 1.0;
                } elseif ($huruf == "E") {
                    $bobot = 0.0;
                } 
                echo number_format($bobot,1);
                 ?>
            </td>
            <td>
                <?php $hasil = $sql->sks * $bobot; echo $hasil; ?>
            </td>
            
        </tr>
    <?php $jumsks +=$sql->sks; $jumhasil +=$hasil; $no++; } ?>
        <tr>
            <td colspan="3" align="right">Jumlah</td>
            <td><?php echo $jumsks; ?></td>
            <td colspan="3"></td>
            <td><?php echo $jumhasil; ?></td>
        </tr>
        <tr>
           <td colspan="3" align="right">Indeks Prestasi</td>
           <td colspan="5" align="center"><b>
           <?php
            $ip = number_format($jumhasil/$jumsks, 2); 
            //cek ip sudah ada apa belum
            $nim = $this->uri->segment(4);
            $thn = $this->uri->segment(3);
            $cek = $this->db->query("SELECT * FROM ipk_mhs WHERE nim='$nim' and thn_akademik='$thn'");
            if ($cek->num_rows() == 0) {
                $data = array('nim' => $nim,
                              'ipk' => $ip,
                              'thn_akademik' => $thn);
                $this->db->insert('ipk_mhs', $data);
            } else {
                $data = array('ipk' => $ip);
                $this->db->where('nim', $nim);
                $this->db->where('thn_akademik', $thn);
                $this->db->update('ipk_mhs', $data);

            } 
            echo $ip; 

            ?></b></td> 
        </tr>
        <?php } ?>
    </tbody>
</table>
<div>
    <a href="prodi/cetak_khs/<?php echo $this->uri->segment(3); ?>/<?php echo $this->uri->segment(4); ?>" class="btn btn-primary">Print KHS</a> | 
    <a href="prodi/cetak_transkrip/<?php echo $this->uri->segment(3); ?>/<?php echo $this->uri->segment(4); ?>" class="btn btn-primary">Print Transkrip</a>
</div>
</div>