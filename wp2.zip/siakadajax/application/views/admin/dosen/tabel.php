<table width="100%" class="table table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Nama Dosen</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($d_dosen->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->nm_dosen; ?></td>
            <td>
                <a href="webmin/edit_dosen/<?php echo $row->id_dosen; ?>"><button class="btn btn-info btn-xs"><i class="fa fa-pencil-square"></i></button></a>
                <a href="webmin/hapus_dosen/<?php echo $row->id_dosen; ?>" onclick="return confirm('Anda yakin ingin menghapus <?php echo $row->nm_dosen; ?> ?')"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle"></i></button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>