<form action="prodi/edit_dosen/<?php echo $hasil->id_dosen; ?>" method="POST">
	<div class="form-group">
        <label>NIDN</label>
        <input class="form-control" name="nidn" value="<?php echo $hasil->nidn; ?>">
    </div>
    <div><?php echo form_error('nidn'); ?></div>
	<div class="form-group">
        <label>Nama Dosen</label>
        <input class="form-control" name="dosen" value="<?php echo $hasil->nm_dosen; ?>">
    </div>
    <div><?php echo form_error('dosen'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Ubah">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>