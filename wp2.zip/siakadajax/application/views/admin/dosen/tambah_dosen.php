<form action="prodi/tambah_dosen" method="POST">
	<div class="form-group">
        <label>NIDN </label>
        <input class="form-control" name="nidn" placeholder="NIDN">
    </div>
    <div><?php echo form_error('nidn'); ?></div>
	<div class="form-group">
        <label>Nama Dosen</label>
        <input class="form-control" name="dosen" placeholder="Dosen">
    </div>
    <div><?php echo form_error('dosen'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Simpan">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>