<?php 
switch ($jenis) {
	case 'informasi':
		include 'informasi/informasi.php';
		break;
	case 'home':
		include 'home/home.php';
		break;
	case 'prodi':
		include 'prodi/data_prodi.php';
		break;
	case 'tambah prodi':
		include 'prodi/tambah_prodi.php';
		break;
	case 'edit prodi':
		include 'prodi/edit_prodi.php';
		break;
	case 'ruang':
		include 'ruang/data_ruang.php';
		break;
	case 'tambah ruang':
		include 'ruang/tambah_ruang.php';
		break;
	case 'edit ruang':
		include 'ruang/edit_ruang.php';
		break;
	case 'kelas':
		include 'kelas/data_kelas.php';
		break;
	case 'tambah kelas':
		include 'kelas/tambah_kelas.php';
		break;
	case 'edit kelas':
		include 'kelas/edit_kelas.php';
		break;
	case 'semester':
		include 'semester/data_semester.php';
		break;
	case 'tambah semester':
		include 'semester/tambah_semester.php';
		break;
	case 'edit semester':
		include 'semester/edit_semester.php';
		break;
	case 'dosen':
		include 'dosen/data_dosen.php';
		break;
	case 'tambah dosen':
		include 'dosen/tambah_dosen.php';
		break;
	case 'edit dosen':
		include 'dosen/edit_dosen.php';
		break;
	case 'matkul':
		include 'matkul/data_matkul.php';
		break;
	case 'tambah matkul':
		include 'matkul/tambah_matkul.php';
		break;
	case 'edit matkul':
		include 'matkul/edit_matkul.php';
		break;
	case 'jadwal matkul':
		include 'jadwal matkul/data_jadwal_matkul.php';
		break;
	case 'tambah jadwal matkul':
		include 'jadwal matkul/tambah_jadwal_matkul.php';
		break;
	case 'edit jadwal matkul':
		include 'jadwal matkul/edit_jadwal_matkul.php';
		break;
	case 'thn akademik':
		include 'thn/data_thn.php';
		break;
	case 'mahasiswa':
		include 'mhs/data_mhs.php';
		break;
	case 'thn':
		include 'nilai/v_thn.php';
		break;
	case 'home_prodi':
		include 'home_prodi/home.php';
		break;
	case 'mhs_nilai':
		include 'nilai/v_daf_mhs.php';
		break;
	case 'daftar_nilai':
		include 'nilai/v_daf_krs.php';
		break;
	case 'khs_nilai':
		include 'khs/v_daf_khs.php';
		break;
	case 'khs':
		include 'khs/v_daf_mhs.php';
		break;
	case 'thn_mhs':
		include 'khs/v_thn.php';
		break;
	case 'daftar_kp':
		include 'kp/v_daftar_kp.php';
		break;
	case 'laporan_kp':
		include 'kp/v_laporan_kp.php';
		break;
	case 'pengajuan_cuti':
		include 'pengajuan/v_pengajuan_cuti.php';
		break;
	case 'pengajuan_transfer':
		include 'pengajuan/v_pengajuan_transfer.php';
		break;
	case 'user':
		include 'user/data_user.php';
		break;
	case 'tambah_user':
		include 'user/tambah_user.php';
		break;

	case 'pa':
		include 'pa/data_pa.php';
		break;
	case 'tambah pa':
		include 'pa/tambah_pa.php';
		break;
	case 'edit pa':
		include 'pa/edit_pa.php';
		break;

	case 'home_dosen':
		include 'home_dosen/home.php';
		break;

	case 'data_krs':
		include 'krs_masuk/data_krs.php';
		break;
	case 'detail_krs':
		include 'krs_masuk/detail_krs.php';
		break;


	}

 ?>