<form action="prodi/tambah_matkul" method="POST">
    <div class="form-group">
        <label>Kode MK</label>
        <input type="text" class="form-control" name="kdmk" placeholder="Kode Mk">
    </div>
    <div><?php echo form_error('kdmk'); ?></div>
	<div class="form-group">
        <label>Nama Matakuliah</label>
        <input type="text" class="form-control" name="matkul" placeholder="Matakuliah">
    </div>
    <div><?php echo form_error('matkul'); ?></div>
    <div class="form-group">
        <label>Jumlah Sks</label>
        <input type="number" class="form-control" name="sks" placeholder="Jumlah sks">
    </div>
    <div><?php echo form_error('sks'); ?></div>
    <div class="form-group">
        <label>Semester</label>
        <select name="semester" class="form-control" required>
            <option value="">Pilih Semester</option>
            <option value="1">Semester 1</option>
            <option value="2">Semester 2</option>
            <option value="3">Semester 3</option>
            <option value="4">Semester 4</option>
            <option value="5">Semester 5</option>
            <option value="6">Semester 6</option>
            <option value="7">Semester 7</option>
            <option value="8">Semester 8</option>
        </select>
    </div>
    <div class="form-group">
        <label>Tipe Semester</label>
        <select name="tipesemester" class="form-control" required>
            <option value="">Pilih Tipe Semester</option>
            <option value="1">Ganjil</option>
            <option value="2">Genap</option>
        </select>
    </div>
    <div class="form-group">
        <label>Prodi</label>
        <select name="idprodi" class="form-control">
        	<option value="">Pilih Prodi</option>
        <?php 
        $sql = $this->db->query("SELECT nm_prodi FROM prodi WHERE id_prodi='$idprodi'")->row();
         ?>
        	<option value="<?php echo $idprodi; ?>"><?php echo $sql->nm_prodi; ?></option>
        </select>
    </div>
    <div><?php echo form_error('idprodi'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Simpan">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>