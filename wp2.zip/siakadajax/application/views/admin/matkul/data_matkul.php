<a href="prodi/tambah_matkul" class="btn btn-primary">Tambah Matakuliah</a><br><br>
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Kode MK</th>
            <th>Matakuliah</th>
            <th>Sks</th>
            <th>Semester</th>
            <th>Tipe Semester</th>
            <th>Prodi</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($d_matkul->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->kd_matkul; ?></td>
            <td><?php echo $row->nm_matkul; ?></td>
            <td><?php echo $row->sks; ?></td>
            <td><?php echo $row->semester; ?></td>
            <td><?php 
            $a = $row->tipe_semester;
            if ($a == 1) {
                echo "Ganjil";
            } elseif ($a == 2) {
                echo "Genap";
             
            }
            ?>
            </td>
            <td><?php echo $row->nm_prodi; ?></td>
            <td>
                <a href="prodi/edit_matkul/<?php echo $row->kd_matkul; ?>"><button class="btn btn-info btn-xs"><i class="fa fa-pencil-square"></i></button></a>
                <a href="prodi/hapus_matkul/<?php echo $row->kd_matkul; ?>" onclick="return confirm('Anda yakin ingin menghapus <?php echo $row->nm_matkul; ?> ?')"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle"></i></button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>