<form action="prodi/edit_matkul/<?php echo $hasil->kd_matkul; ?>" method="POST">
	<div class="form-group">
        <label>Nama Matakuliah</label>
        <input type="text" class="form-control" name="matkul" value="<?php echo $hasil->nm_matkul ?>">
    </div>
    <div><?php echo form_error('matkul'); ?></div>
    <div class="form-group">
        <label>Jumlah Sks</label>
        <input type="number" class="form-control" name="sks" value="<?php echo $hasil->sks ?>">
    </div>
    <div><?php echo form_error('sks'); ?></div>
    <div class="form-group">
        <label>Semester</label>
        <select name="semester" class="form-control" required>
            <option value="<?php echo $hasil->semester; ?>"><?php echo "Semester ".$hasil->semester; ?></option>
            <option value="1">Semester 1</option>
            <option value="2">Semester 2</option>
            <option value="3">Semester 3</option>
            <option value="4">Semester 4</option>
            <option value="5">Semester 5</option>
            <option value="6">Semester 6</option>
            <option value="7">Semester 7</option>
            <option value="8">Semester 8</option>
        </select>
    </div>
    <div class="form-group">
        <label>Tipe Semester</label>
        <select name="tipesemester" class="form-control" required>
            <option value="<?php echo $hasil->tipe_semester; ?>">
                <?php 
                $a = $hasil->tipe_semester;
                if ($a == 1) {
                    echo "Ganjil";
                } elseif ($a == 2) {
                    echo "Genap";
                }
                 ?>
            </option>
            <option value="1">Ganjil</option>
            <option value="2">Genap</option>
        </select>
    </div>
    <div class="form-group">
        <label>Prodi</label>
        <select name="idprodi" class="form-control">
        <?php 
        $id = $hasil->id_prodi;
        $b = $this->db->query("SELECT * FROM prodi WHERE id_prodi='$id'")->row();
         ?>
        	<option value="<?php echo $b->id_prodi ?>"><?php echo $b->nm_prodi; ?></option>
        <?php 
        $sql = $this->db->query("SELECT nm_prodi FROM prodi WHERE id_prodi='$idprodi'")->row();
         ?>
            <option value="<?php echo $idprodi; ?>"><?php echo $sql->nm_prodi; ?></option>
        </select>
        </select>
    </div>
    <div><?php echo form_error('idprodi'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Ubah">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>