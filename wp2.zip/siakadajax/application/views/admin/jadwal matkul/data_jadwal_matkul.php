<a href="prodi/tambah_jadwal_matkul" class="btn btn-primary">Tambah Jadwal</a><br><br>
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Kode MK</th>
            <th>Nama MK</th>
            <th>Hari</th>
            <th>Ruang</th>
            <th>Jam Mulai</th>
            <th>Jam Selesai</th>
            <th>Semester</th>
            <th>Prodi</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($d_jadwal->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->kd_matkul; ?></td>
            <td><?php echo $row->nm_matkul; ?></td>
            <td><?php echo $row->hari; ?></td>
            <td><?php echo $row->ruang; ?></td>
            <td><?php echo $row->jam_mulai; ?></td>
            <td><?php echo $row->jam_selesai; ?></td>
            <td><?php echo $row->semester; ?></td>
            <td><?php echo $row->nm_prodi; ?></td>
            <td>
                <a href="prodi/edit_jadwal_matkul/<?php echo $row->id_jadwal; ?>"><button class="btn btn-info btn-xs"><i class="fa fa-pencil-square"></i></button></a>
                <a href="prodi/hapus_jadwal_matkul/<?php echo $row->id_jadwal; ?>" onclick="return confirm('Anda yakin ingin menghapus <?php echo $row->id_jadwal; ?> ?')"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle"></i></button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>