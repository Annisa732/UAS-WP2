<form action="prodi/tambah_jadwal_matkul" method="POST">
	<div class="form-group">
        <label>Hari</label>
        <select class="form-control" name="hari">
            <option value="">Pilih Hari</option>
            <option value="Senin">Senin</option>
            <option value="Selasa">Selasa</option>
            <option value="Rabu">Rabu</option>
            <option value="Kamis">Kamis</option>
            <option value="Jum'at">Jum'at</option>
            <option value="Sabtu">Sabtu</option>
        </select>
    </div>
    <div class="form-group">
        <label>Matakuliah</label>
        <select name="mk" class="form-control">
            <option value="">Pilih Matakuliah</option>
        <?php 
        $mk = $this->db->query("SELECT * FROM matakuliah WHERE id_prodi='$idprodi'");
        foreach ($mk->result() as $row) {
         ?>
            <option value="<?php echo $row->kd_matkul; ?>"><?php echo $row->nm_matkul; ?></option>
        <?php } ?>
        </select>
    </div>
    <div><?php echo form_error('mk'); ?></div>
    <div class="form-group">
        <label>Ruang</label>
        <select name="ruang" class="form-control">
            <option value="">Pilih Ruang</option>
        <?php 
        $ruang = $this->db->query("SELECT * FROM ruang ");
        foreach ($ruang->result() as $row) {
         ?>
            <option value="<?php echo $row->id_ruang; ?>"><?php echo $row->ruang; ?></option>
        <?php } ?>
        </select>
    </div>
    <div><?php echo form_error('ruang'); ?></div>
    <div class="form-group">
        <label>Jam Mulai</label>
        <div>
            <input type="text" name="jam_mulai" class="form-control"  placeholder="07:00">
        </div>
    </div>
    <div><?php echo form_error('jam_mulai'); ?></div>
    <div class="form-group">
        <label>Jam Selesai</label>
        <div>
            <input type="text" name="jam_selesai" class="form-control" placeholder="10:30">
        </div>
    </div>
    <div><?php echo form_error('jam_selesai'); ?></div>
    <div class="form-group">
        <label>Dosen</label>
        <select name="dosen" class="form-control">
            <option value="">Pilih Dosen</option>
        <?php 
        $dosen = $this->db->query("SELECT * FROM dosen WHERE id_prodi='$idprodi'");
        foreach ($dosen->result() as $row) {
         ?>
            <option value="<?php echo $row->id_dosen; ?>"><?php echo $row->nm_dosen; ?></option>
        <?php } ?>
        </select>
    </div>
    <div><?php echo form_error('dosen'); ?></div>
    <div class="form-group">
        <label>Semester</label>
        <select name="semester" class="form-control">
            <option value="">Pilih Semester</option>
        <?php 
        $semester = $this->db->query("SELECT * FROM semester");
        foreach ($semester->result() as $row) {
         ?>
            <option value="<?php echo $row->id_semester; ?>"><?php echo $row->semester; ?></option>
        <?php } ?>
        </select>
        <input type="hidden" name="idprodi" value="<?php echo $idprodi; ?>">
    </div>
    <div><?php echo form_error('semester'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Simpan">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>