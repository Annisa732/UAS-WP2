<form action="webmin/tambah_semester" method="POST">
	<div class="form-group">
        <label>Semester</label>
        <input class="form-control" name="semester" placeholder="Semester">
    </div>
    <div><?php echo form_error('semester'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Simpan">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>