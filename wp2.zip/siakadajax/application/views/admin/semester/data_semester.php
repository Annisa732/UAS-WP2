<a href="webmin/tambah_semester" class="btn btn-primary">Tambah semester</a><br><br>
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Semester</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($d_semester->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->semester; ?></td>
            <td>
                <a href="webmin/edit_semester/<?php echo $row->id_semester; ?>"><button class="btn btn-info btn-xs"><i class="fa fa-pencil-square"></i></button></a>
                <a href="webmin/hapus_semester/<?php echo $row->id_semester; ?>" onclick="return confirm('Anda yakin ingin menghapus <?php echo $row->semester; ?> ?')"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle"></i></button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>