<form action="webmin/edit_semester/<?php echo $hasil->id_semester; ?>" method="POST">
	<div class="form-group">
        <label>Semester</label>
        <input class="form-control" name="semester" value="<?php echo $hasil->semester; ?>">
    </div>
    <div><?php echo form_error('semester'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Ubah">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>