<form action="webmin/tambah_ruang" method="POST">
	<div class="form-group">
        <label>Nama Ruang</label>
        <input class="form-control" name="ruang" placeholder="Nama ruang">
    </div>
    <div><?php echo form_error('ruang'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Simpan">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>