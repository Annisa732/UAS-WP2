<form action="webmin/edit_ruang/<?php echo $hasil->id_ruang; ?>" method="POST">
	<div class="form-group">
        <label>Nama Ruang</label>
        <input class="form-control" name="ruang" value="<?php echo $hasil->ruang; ?>">
    </div>
    <div><?php echo form_error('ruang'); ?></div>
    <div class="form-group">
    	<input type="submit" class="btn btn-primary" name="simpan" value="Ubah">
    	<input type="reset" class="btn btn-danger" value="Batal">
    </div>
</form>