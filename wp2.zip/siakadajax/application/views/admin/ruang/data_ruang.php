<a href="webmin/tambah_ruang" class="btn btn-primary">Tambah Ruang</a><br><br>
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Ruang Kelas</th>
            <th>Pilihan</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $no = 1;
    foreach ($d_ruang->result() as $row) {
     ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $row->ruang; ?></td>
            <td>
                <a href="webmin/edit_ruang/<?php echo $row->id_ruang; ?>"><button class="btn btn-info btn-xs"><i class="fa fa-pencil-square"></i></button></a>
                <a href="webmin/hapus_ruang/<?php echo $row->id_ruang; ?>" onclick="return confirm('Anda yakin ingin menghapus <?php echo $row->ruang; ?> ?')"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle"></i></button></a>
            </td>
        </tr>
    <?php $no++; } ?>
    </tbody>
</table>