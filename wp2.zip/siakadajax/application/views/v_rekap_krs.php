<div class="row">
	<div class="col-md-12">
		<div class="block">
			<div class="head yellow">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2>KARTU RENCANA STUDI</b></h2>                             
            </div> 
            <div class="data-fluid">
            	<table class="table">
            		<tr>
            			<td width="20%">Nim</td>
            			<td width="2%">:</td>
            			<td><?php echo $nim; ?></td>
            		</tr>
            		<tr>
            			<td width="20%">Nama</td>
            			<td width="2%">:</td>
            			<td><?php echo $nama_lengkap; ?></td>
            		</tr>
            	</table>
            </div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="block">
		<?php 
		//ambil mk berdasarkan prodi
		$mk = $this->db->query("SELECT DISTINCT(semester) FROM matakuliah WHERE id_prodi='$idprodi' ORDER BY semester ASC");
		foreach ($mk->result() as $matkul) {
			$semester = $matkul->semester;
		 ?>
			<div class="head blue">
                <div class="icon"><span class="ico-pen-2"></span></div>
                <h2><?php echo "Semester ".$matkul->semester; 
                // $l = $this->db->query("SELECT * FROM matakuliah, krs WHERE matakuliah.kd_matkul=krs.kd_matkul AND krs.nim='$nim' AND matakuliah.id_prodi='$idprodi' AND matakuliah.semester='$semester' AND krs.status='1'");
                // if ($l->num_rows() == 1) {
                ?> <a href="mahasiswa/cetak_krs_semester/<?php echo $matkul->semester; ?>">Cetak</a>
                <?php //} else {  } ?>
                </h2>                             
            </div>  
		               
            <div class="data-fluid">
                <table cellpadding="0" cellspacing="0" width="100%" class="table">
                    <thead>
                        <tr>
                            <th width="25%">
                                Kode MK
                            </th>
                            <th width="25%">
                                Matakuliah
                            </th>
                            <th width="25%">
                                Sks
                            </th>
                            <th width="25%">
                                Status
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
					//ambil mk berdasarkan prodi
					$mk1 = $this->db->query("SELECT * FROM matakuliah, krs WHERE matakuliah.kd_matkul=krs.kd_matkul AND krs.nim='$nim' AND matakuliah.id_prodi='$idprodi' AND matakuliah.semester='$semester'");
					foreach ($mk1->result() as $matkul1) {
					 ?>
                        <tr>
                            <td>
                                <?php echo $matkul1->kd_matkul; ?>
                            </td>
                            <td>
                                <?php echo $matkul1->nm_matkul; ?>
                            </td>
                            <td>
                                <?php echo $matkul1->sks; ?>
                            </td>
                            <td>
                                <?php 
                                if ($matkul1->status == '0') {
                                    echo "<span class='label label-warning'>belum</span>";
                                } elseif ($matkul1->status == '1') {
                                    echo "<span class='label label-success'>di setujui</span>";
                                }
                                 ?>
                            </td>
                        </tr>    
                    <?php } ?>                       
                    </tbody>
                </table>
            </div>   
        <?php } ?>             
        </div>
	</div>
</div>