<div class="row">
	<div class="col-md-12">                
        <div class="block">
            <div class="head">                                
                <h2>Upload Laporan KP</h2>
                <ul class="buttons">             
                    <li><a href="#" onClick="source('form_default');
                        return false;"><div class="icon"><span class="ico-info"></span></div></a></li>
                </ul>                                  
            </div>                                        
            <div class="data-fluid">
            <form action="mahasiswa/simpan_upload_kp" method="post" enctype="multipart/form-data">
                <div class="row-form">
                    <div class="col-md-3">Nim</div>
                    <div class="col-md-9"><input class="form-control" name="nim" type="text" value="<?php echo $nim; ?>" readonly/></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Nama Lengkap</div>
                    <div class="col-md-9"><input class="form-control" name="nama" type="text" value="<?php echo $nama_lengkap; ?>" readonly/></div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Tempat kerja praktek</div>
                    <div class="col-md-9">
                    	<textarea class="form-control" name="tempat" rows="2"></textarea>
                    	<input type="hidden" name="idprodi" value="<?php echo $idprodi; ?>">
                    </div>
                </div>
                <div class="row-form">
                    <div class="col-md-3">Upload File Laporan</div>
                    <div class="col-md-9">
                    	<input type="file" name="userfile">
                    </div>
                </div>
                <div class="row-form">
                	<div class="col-md-3"></div>
                	<div class="col-md-9">
                		<input type="submit" name="simpan" value="Kirim" class="btn btn-primary">
                	</div>
                </div>
            </form>
            </div>
        </div>

    </div>
</div>