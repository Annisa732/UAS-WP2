<div class="row">
	<div class="col-md-12">                
        <div class="block">
            <div class="head">                                
                <h2>Materi Ajar</h2>
                                                 
            </div>                                        
            <div class="data-fluid">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Semester</th>
                        <th>Download</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            </div>
        </div>

    </div>
</div>

