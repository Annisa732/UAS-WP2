<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
    #outtable{
      padding: 20px;
      border:1px solid #e3e3e3;
      width:600px;
      border-radius: 5px;
    }
 
    .short{
      width: 50px;
    }
 
    .normal{
      width: 150px;
    }
 
    table{
      border-collapse: collapse;
      font-family: arial;
      color:#5E5B5C;
    }
 
    thead th{
      text-align: left;
      padding: 10px;
    }
 
    tbody td{
      border-top: 1px solid #e3e3e3;
      padding: 10px;
    }
 
    tbody tr:nth-child(even){
      background: #F6F5FA;
    }
 
    tbody tr:hover{
      background: #EAE9F5
    }
  </style>
</head>
<body>
<h2 align="center">Kartu Rencana Studi</h2>
	<table>
		<tr>
			<td>Nim</td>
			<td>:</td>
			<td><?php echo $nim; ?></td>
		</tr>
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td><?php echo $nama_lengkap; ?></td>
		</tr>
		<tr>
			<td>Tahun Akademik</td>
			<td>:</td>
			<td>
				<?php 
				$id = $idprodi;
				$prodi = $this->db->query("SELECT nm_prodi from prodi where id_prodi='$id'")->row();
				echo $prodi->nm_prodi;
				 ?>
			</td>
		</tr>
	</table>
	<br><br>
	<table border="1">
		<thead>
			<tr>
				<th>No</th>
				<th>Kode Matkul</th>
				<th>Matkul</th>
				<th>SKS</th>
			</tr>
		</thead>
		<tbody>
		<?php 
		$no = 1;
		foreach ($mhs->result() as $row) {
		 ?>
			<tr>
				<td><?php echo $no; ?></td>
				<td><?php echo $row->kd_matkul; ?></td>
				<td><?php echo $row->nm_matkul; ?></td>
				<td><?php echo $row->sks; ?></td>
			</tr>
		<?php $no++; } ?>
		</tbody>
	</table>
</body>
</html>