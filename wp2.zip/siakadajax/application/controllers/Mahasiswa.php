<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {

	var $gallerypath;
	var $gallery_path_url;

	public function __construct() {
		parent::__construct();
		//session_start();
		if ($this->session->userdata('nama_lengkap')=="" ) {
			redirect('login');
		}

		$this->gallerypath = realpath(APPPATH . '../files/');
		$this->gallery_path_url = base_url().'files/';

		$this->load->helper('text');
		$this->load->model('m_prodi');
        $this->load->model('m_ruang');
        $this->load->model('m_kelas');
        $this->load->model('m_matkul');
        $this->load->model('m_semester');
        $this->load->model('m_thnakademik');
        $this->load->model('m_dosen');
        $this->load->model('m_jadwal');
        $this->load->model('m_mhs');
	}

	public function logout() {
		$this->session->unset_userdata('nama_lengkap');
		$this->session->unset_userdata('foto_user');
		session_destroy();
		redirect('login');
	}

	public function index()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['jenis'] = 'home';
		$data['lokasi'] = 'Dashboard';
		$this->load->view('v_index', $data);
	}

	public function krs()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');
		$data['jenis'] = 'krs';
		$data['lokasi'] = 'KRS';
		$this->load->view('v_index', $data);
	}

	function cetak_krs_semester($semester)
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');
		$idprodi = $this->session->userdata('id_prodi');
		$nim = $this->session->userdata('nim');
		ob_start();
		$data['mhs'] = $this->db->query("SELECT * FROM matakuliah, krs WHERE matakuliah.kd_matkul=krs.kd_matkul AND krs.nim='$nim' AND matakuliah.id_prodi='$idprodi' AND matakuliah.semester='$semester' and krs.status='1'");
		$this->load->view('print', $data);
		
		$tgl = date('d-m-Y');
		$html = ob_get_contents();
		ob_end_clean();

		require_once('./html2pdf/html2pdf.class.php');
	    $pdf = new HTML2PDF('P','A4','en');
	    $pdf->WriteHTML($html);
	    $pdf->Output($nim.'-'.$tgl.'.pdf', 'D'); 
	}

	public function rps()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');
		$data['jenis'] = 'rps';
		$data['lokasi'] = 'RPS & SAP';
		$this->load->view('v_index', $data);
	}

	public function bim_akademik()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');
		$data['jenis'] = 'bim_akademik';
		$data['lokasi'] = 'Bimbingan Akademik';
		$this->load->view('v_index', $data);
	}

	public function bim_kp()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');
		$data['jenis'] = 'bim_kp';
		$data['lokasi'] = 'Bimbingan KP';
		$this->load->view('v_index', $data);
	}

	public function bim_skripsi()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');
		$data['jenis'] = 'bim_skripsi';
		$data['lokasi'] = 'Bimbingan Skripsi';
		$this->load->view('v_index', $data);
	}

	public function bim_pkm()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');
		$data['jenis'] = 'bim_pkm';
		$data['lokasi'] = 'Bimbingan PKM';
		$this->load->view('v_index', $data);
	}

	function simpan_daftar_ulang()
	{
		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$semester = $this->input->post('semester');
		$idprodi = $this->input->post('idprodi');
		$tahun = $this->input->post('thn_akademik');

		$data = array(
			'nim' => $nim,
			'nama' => $nama,
			'semester' => $semester,
			'id_prodi' => $idprodi,
			'tahun_akademik' => $tahun
			);
		$this->db->insert('daftar_ulang', $data);
		?>
		<script type="text/javascript">
			alert('data berhasil disimpan');
			window.location='<?php echo base_url('mahasiswa/daftar_ulang'); ?>';
		</script>
		<?php
	}

	function simpan_upload_tugas()
	{

		$konfigurasi = array('allowed_types' =>'rar|ppt|pdf|zip|docx|xl',
			             'upload_path' => $this->gallerypath,
                         'overwrite' => FALSE,
                         'remove_spaces' => TRUE,
                         'max_size' => '60000');
		$this->load->library('upload', $konfigurasi);
		$this->upload->do_upload();
		$datafile = $this->upload->data();

		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$idprodi = $this->input->post('idprodi');
		$nama_file = $_FILES['userfile']['name'];
		$nama_file = preg_replace('/ /', '_', $nama_file);
			

		$data = array(
			'nim' => $nim,
			'nama' => $nama,
			'file' => $nama_file,
			'id_prodi' => $idprodi
			);
		$this->db->insert('upload_tugas', $data);
		?>
		<script type="text/javascript">
			alert('data berhasil disimpan');
			window.location='<?php echo base_url('mahasiswa/aktifitas_terstruktur'); ?>';
		</script>
		<?php
	}

	function simpan_upload_quiz()
	{

		$konfigurasi = array('allowed_types' =>'rar|ppt|pdf|zip|docx|xl',
			             'upload_path' => $this->gallerypath,
                         'overwrite' => FALSE,
                         'remove_spaces' => TRUE,
                         'max_size' => '60000');
		$this->load->library('upload', $konfigurasi);
		$this->upload->do_upload();
		$datafile = $this->upload->data();

		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$idprodi = $this->input->post('idprodi');
		$nama_file = $_FILES['userfile']['name'];
		$nama_file = preg_replace('/ /', '_', $nama_file);
			

		$data = array(
			'nim' => $nim,
			'nama' => $nama,
			'file' => $nama_file,
			'id_prodi' => $idprodi
			);
		$this->db->insert('upload_quiz', $data);
		?>
		<script type="text/javascript">
			alert('data berhasil disimpan');
			window.location='<?php echo base_url('mahasiswa/aktifitas_mandiri'); ?>';
		</script>
		<?php
	}

	function simpan_upload_pratikum()
	{

		$konfigurasi = array('allowed_types' =>'rar|ppt|pdf|zip|docx|xl',
			             'upload_path' => $this->gallerypath,
                         'overwrite' => FALSE,
                         'remove_spaces' => TRUE,
                         'max_size' => '60000');
		$this->load->library('upload', $konfigurasi);
		$this->upload->do_upload();
		$datafile = $this->upload->data();

		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$idprodi = $this->input->post('idprodi');
		$nama_file = $_FILES['userfile']['name'];
			

		$data = array(
			'nim' => $nim,
			'nama' => $nama,
			'file' => $nama_file,
			'id_prodi' => $idprodi
			);
		$this->db->insert('upload_pratikum',$data);
		?>
		<script type="text/javascript">
			alert('data berhasil disimpan');
			window.location='<?php echo base_url('mahasiswa/Pratikum'); ?>';
		</script>
		<?php
	}

	public function jadwal_kuliah()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'jadwal';
		$data['lokasi'] = 'Jadwal Kuliah';
		$this->load->view('v_index', $data);
	}

	public function daftar_kp()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'daftar_kp';
		$data['lokasi'] = 'Kerja Praktek';
		$this->load->view('v_index', $data);
	}

	public function materi()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'materi';
		$data['lokasi'] = 'Materi Ajar';
		$this->load->view('v_index', $data);
	}

	public function aktifitas_terstruktur()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'aktifitas_terstruktur';
		$data['lokasi'] = 'Aktifitas Terstruktur';
		$this->load->view('v_index', $data);
	}

	public function aktifitas_mandiri()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'aktifitas_mandiri';
		$data['lokasi'] = 'Aktifitas Mandiri';
		$this->load->view('v_index', $data);
	}

	public function pratikum()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'pratikum';
		$data['lokasi'] = 'Pratikum';
		$this->load->view('v_index', $data);
	}

	public function simpan_daftar_kp()
	{
		$nim = $this->input->post('nim');
		$tempat = $this->input->post('tempat');
		$idprodi = $this->input->post('idprodi');
		$data = array('nim' => $nim,
					  'tempat' => $tempat,
					  'id_prodi' => $idprodi);
		$this->db->insert('daftar_kp', $data);
		?>
		<script type="text/javascript">
			alert('Pendaftaran Kerja Praktek berhasil disimpan !');
			window.location='index';
		</script>
		<?php
	}

	public function upload_kp()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'upload_kp';
		$data['lokasi'] = 'Kerja Praktek';
		$this->load->view('v_index', $data);
	}

	public function simpan_upload_kp()
	{
		$konfigurasi = array('allowed_types' =>'rar|ppt|pdf|zip|docx|xl',
			             'upload_path' => $this->gallerypath,
                         'overwrite' => FALSE,
                         'remove_spaces' => TRUE,
                         'max_size' => '60000');
		$this->load->library('upload', $konfigurasi);
		$this->upload->do_upload();
		$datafile = $this->upload->data();

		$nim = $this->input->post('nim');
		$tempat = $this->input->post('tempat');
		$idprodi = $this->input->post('idprodi');
		$nama_file = $_FILES['userfile']['name'];
		$data = array('nim' => $nim,
					  'tempat' => $tempat,
					  'nm_file' => $nama_file,
					  'id_prodi' => $idprodi);
		$this->db->insert('upload_kp', $data);
		?>
		<script type="text/javascript">
			alert('Laporan Kerja Praktek berhasil diupload !');
			window.location='index';
		</script>
		<?php

	}

	public function daftar_ulang()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'daftar_ulang';
		$data['lokasi'] = 'Daftar Ulang';
		$this->load->view('v_index', $data);
	}

	public function pengajuan_cuti()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'pengajuan_cuti';
		$data['lokasi'] = 'Pengajuan Cuti';
		$this->load->view('v_index', $data);
	}

	public function simpan_cuti()
	{
		$nim = $this->input->post('nim');
		$lama = $this->input->post('lama');
		$alasan = $this->input->post('alasan');
		$idprodi = $this->input->post('idprodi');
		$data = array('nim' => $nim,
					  'lama' => $lama,
					  'alasan' => $alasan,
					  'id_prodi' => $idprodi);
		$this->db->insert('pengajuan_cuti', $data);
		?>
		<script type="text/javascript">
			alert('Pengajuan Cuti berhasil disimpan !');
			window.location='index';
		</script>
		<?php
	}

	public function pengajuan_transfer()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'pengajuan_transfer';
		$data['lokasi'] = 'Pengajuan Tranfer';
		$this->load->view('v_index', $data);
	}

	public function simpan_transfer()
	{
		$nim = $this->input->post('nim');
		$tranfer = $this->input->post('tranfer');
		$jurusan = $this->input->post('jurusan');
		$idprodi = $this->input->post('idprodi');
		$data = array('nim' => $nim,
					  'transfer_ke' => $tranfer,
					  'jurusan' => $jurusan,
					  'id_prodi' => $idprodi);
		$this->db->insert('pengajuan_transfer', $data);
		?>
		<script type="text/javascript">
			alert('Pengajuan Tranfer berhasil disimpan !');
			window.location='index';
		</script>
		<?php
	}

	public function peserta_kp()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'peserta_kp';
		$data['lokasi'] = 'Kerja Praktek';
		$this->load->view('v_index', $data);
	}

	public function rekap_krs()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('id_prodi');
		$data['nim'] = $this->session->userdata('nim');

		$data['jenis'] = 'semua_krs';
		$data['lokasi'] = 'Rekap KRS';
		$this->load->view('v_index', $data);
	}

	public function ambil_krs()
	{
		error_reporting(0);
		$id = $this->input->post('id');
      	$nim = $this->input->post('nim');
      	$thn = $this->input->post('thn');

      	//cek krs yang sudah di ambil
		$s = $this->db->query("select * from krs where kd_matkul='$id' and nim='$nim'");
		if ($s->num_rows() == 1) {
			$this->db->where('kd_matkul', $id);
			$this->db->where('thn_akademik', $thn);
	    	$this->db->delete('krs');
	    	$this->db->where('kd_matkul', $id);
	    	$this->db->where('thn_akademik', $thn);
	    	$this->db->delete('nilai_mahasiswa');
		} else {
			$cekip = $this->db->query("SELECT * FROM ipk_mhs where nim='$nim' order by id_ipk desc")->row();
			$ceksks = $this->db->query("SELECT SUM(matakuliah.sks) AS total FROM krs,matakuliah WHERE krs.nim = '$nim' AND krs.kd_matkul=matakuliah.kd_matkul AND krs.thn_akademik='$thn'")->row();
			$ipmhs = $cekip->ipk;
			$totsks = $ceksks->total;
			if ($ipmhs >= 3 || $ipmhs == 0) {
				$ambilsks = 22;
				if ($totsks < $ambilsks) {
					$d = array('nim' => $nim,
      			   'kd_matkul' => $id,
      			   'thn_akademik' => $thn
		      		);
		      		$this->db->insert('krs', $d);
		      		$e = array('nim' => $nim,
      			   'kd_matkul' => $id,
      			   'thn_akademik' => $thn
		      		);
		      		$this->db->insert('nilai_mahasiswa', $e);
				} elseif ($totsks >= $ambilsks) {
					echo '
						<script>
							alert("kamu tidak bisa menambah krs lagi !");
						</script>
					';
				}
			} elseif ($ipmhs < 3) {
				$ambilsks = 18;
				if ($totsks < $ambilsks) {
					$d = array('nim' => $nim,
      			   'kd_matkul' => $id,
      			   'thn_akademik' => $thn
		      		);
		      		$this->db->insert('krs', $d);
		      		$e = array('nim' => $nim,
      			   'kd_matkul' => $id,
      			   'thn_akademik' => $thn
		      		);
		      		$this->db->insert('nilai_mahasiswa', $e);
				} elseif ($totsks >= $ambilsks) {
					echo '
						<script>
							alert("kamu tidak bisa menambah krs lagi !");
						</script>
					';
				}
			}
		}

	}
}
