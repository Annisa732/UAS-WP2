<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$data['data'] = $this->db->get('informasi');
		$this->load->view('v_login',$data);
	}

	public function cek_login() {

		$tipe = $this->input->post('tipe');
		if ($tipe == 'mahasiswa') {
			$data = array('nim' => $this->input->post('username', TRUE),
						'password' => $this->input->post('password', TRUE)
			);
			$this->load->model('m_login'); // load model_user
			$hasil = $this->m_login->cek_mhs($data);
			if ($hasil->num_rows() == 1) {
				foreach ($hasil->result() as $sess) {
					$sess_data['nama_lengkap'] = $sess->nama_lengkap;
					$sess_data['foto_user'] = $sess->foto_mahasiswa;
					$sess_data['id_prodi'] = $sess->id_prodi;
					$sess_data['nim'] = $sess->nim;
					$this->session->set_userdata($sess_data);
				}
				redirect('mahasiswa/');		
			}
			else {
				echo "<script>alert('Gagal login: Cek username, password!');history.go(-1);</script>";
			}
		} elseif ($tipe == 'admin' || $tipe == 'prodi' || $tipe == 'dosen') {
			$data = array('username' => $this->input->post('username', TRUE),
						'password' => md5($this->input->post('password', TRUE))
			);
			$this->load->model('m_login'); // load model_user
			$hasil = $this->m_login->cek_user($data);
			if ($hasil->num_rows() == 1) {
				foreach ($hasil->result() as $sess) {
					$sess_data['username'] = $sess->username;
					$sess_data['nama_lengkap'] = $sess->nama_lengkap;
					$sess_data['level'] = $sess->level;
					$sess_data['idprodi'] = $sess->id_prodi;
					$this->session->set_userdata($sess_data);
				}
				if ($this->session->userdata('level')=='admin') {
					redirect('webmin/');
				}
				elseif ($this->session->userdata('level')=='prodi') {
					redirect('prodi/');
				}
				elseif ($this->session->userdata('level')=='dosen') {
					redirect('dosen/');
				}

			}
			else {
				echo "<script>alert('Gagal login: Cek username, password!');history.go(-1);</script>";
			}
		} else {
			redirect('login');
		}

		
	}

}
