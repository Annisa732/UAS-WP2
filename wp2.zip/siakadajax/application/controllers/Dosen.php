<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {

	public function __construct() {
		parent::__construct();
		//session_start();
		if ($this->session->userdata('level')=="" || $this->session->userdata('level') !=="dosen" ) {
			redirect('login');
		}

		$this->load->helper('text');
		$this->load->model('m_prodi');
        $this->load->model('m_ruang');
        $this->load->model('m_kelas');
        $this->load->model('m_matkul');
        $this->load->model('m_semester');
        $this->load->model('m_thnakademik');
        $this->load->model('m_dosen');
        $this->load->model('m_jadwal');
        $this->load->model('m_mhs');
        $this->load->model('m_nilai');
        $this->load->model('m_pa');
	}

	public function logout() {
		$this->session->unset_userdata('nama_lengkap');
		$this->session->unset_userdata('foto_user');
		$this->session->unset_userdata('level');
		session_destroy();
		redirect('login');
	}

	public function index()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'home_dosen';
		$data['lokasi'] = 'Dashboard Dosen';
		$data['d_thn'] = $this->m_nilai->tampil_thn();
		$this->load->view('admin/v_index', $data);
	}

	public function krs_masuk()
	{
		$data['username'] = $this->session->userdata('username');
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');

		$data['lokasi'] = 'KRS Mahasiswa';
		$data['jenis'] = 'data_krs';
		$this->load->view('admin/v_index', $data);
	}

	public function detail_krs()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');

		$data['lokasi'] = 'Detail KRS';
		$data['jenis'] = 'detail_krs';
		$this->load->view('admin/v_index', $data);
	}

	public function rubah_krs()
	{
		$nilai = $this->uri->segment(3);
		$nim = $this->uri->segment(4);
		$kdmatkul = $this->uri->segment(5);
		$thn = $this->uri->segment(6);

		$data = array('status' => $nilai);
		$this->db->where('nim', $nim);
		$this->db->where('kd_matkul', $kdmatkul);
		$this->db->where('thn_akademik', $thn);
		$this->db->update('krs', $data);
		redirect('dosen/detail_krs/'.$nim.'/'.$thn);
	}
	
	
}
