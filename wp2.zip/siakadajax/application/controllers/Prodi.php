<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Prodi extends CI_Controller {

	public function __construct() {
		parent::__construct();
		//session_start();
		if ($this->session->userdata('level')=="" || $this->session->userdata('level') !=="prodi" ) {
			redirect('login');
		}

		$this->load->helper('text');
		$this->load->model('m_prodi');
        $this->load->model('m_ruang');
        $this->load->model('m_kelas');
        $this->load->model('m_matkul');
        $this->load->model('m_semester');
        $this->load->model('m_thnakademik');
        $this->load->model('m_dosen');
        $this->load->model('m_jadwal');
        $this->load->model('m_mhs');
        $this->load->model('m_nilai');
        $this->load->model('m_pa');
	}

	public function logout() {
		$this->session->unset_userdata('nama_lengkap');
		$this->session->unset_userdata('foto_user');
		$this->session->unset_userdata('level');
		session_destroy();
		redirect('login');
	}

	public function index()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'home_prodi';
		$data['lokasi'] = 'Dashboard Prodi';
		$data['d_thn'] = $this->m_nilai->tampil_thn();
		$this->load->view('admin/v_index', $data);
	}

	public function dosen()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');

		$data['lokasi'] = 'Daftar Dosen';
		$data['jenis'] = 'dosen';
		$data['d_dosen'] = $this->m_dosen->tampil();
		$this->load->view('admin/v_index', $data);
	}

	function cetak_khs()
	{
		
		// ob_start();
		$data['daf_khs'] = $this->m_nilai->daf_khs();
		$this->load->view('admin/print_khs', $data);
		
		// $tgl = date('d-m-Y');
		// $html = ob_get_contents();
		// ob_end_clean();

		// require_once('./html2pdf/html2pdf.class.php');
	 //    $pdf = new HTML2PDF('P','A4','en');
	 //    $pdf->WriteHTML($html);
	 //    $pdf->Output('KHS-'.$tgl.'.pdf', 'D'); 
	}

	function cetak_transkrip()
	{
		
		ob_start();
		$data['daf_khs'] = $this->m_nilai->transkrip();
		$this->load->view('admin/print_transkrip', $data);
		
		$tgl = date('d-m-Y');
		$html = ob_get_contents();
		ob_end_clean();

		require_once('./html2pdf/html2pdf.class.php');
	    $pdf = new HTML2PDF('P','A4','en');
	    $pdf->WriteHTML($html);
	    $pdf->Output('Transkrip-'.$tgl.'.pdf', 'D'); 
	}

	public function tambah_dosen()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');

		$this->form_validation->set_rules('dosen', 'Dosen', 'required');
		$this->form_validation->set_rules('nidn', 'NIDN', 'required');
	  
	    if ($this->form_validation->run() == TRUE) {
	      if ($this->input->post('simpan')) {
	        $this->m_dosen->simpan();
	        redirect('prodi/dosen');
	      }
	    }
		$data['lokasi'] = 'Tambah dosen';
		$data['jenis'] = 'tambah dosen';
		$this->load->view('admin/v_index', $data);
	}

	public function edit_dosen($id)
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		
		if ($_POST==NULL) {
			$data['hasil'] = $this->m_dosen->tampil_edit($id);
			$data['jenis'] = 'edit dosen';
			$data['lokasi'] = 'Edit dosen';
			$this->load->view('admin/v_index',$data);
		} else {
			$this->m_dosen->ubah($id);
			redirect('prodi/dosen');
		}
	}

	public function hapus_dosen($id)
	{
		$this->m_dosen->hapus($id);
		redirect('prodi/dosen');
	}

	public function pa()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');

		$data['lokasi'] = 'Dosen PA';
		$data['jenis'] = 'pa';
		$data['d_dosen'] = $this->m_pa->tampil($this->session->userdata('idprodi'));
		$this->load->view('admin/v_index', $data);
	}

	public function tambah_pa()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');

		$this->form_validation->set_rules('nim', 'Nim', 'required');
		$this->form_validation->set_rules('nidn', 'NIDN', 'required');
	  
	    if ($this->form_validation->run() == TRUE) {
	      if ($this->input->post('simpan')) {
	        $this->m_pa->simpan();
	        redirect('prodi/pa');
	      }
	    }
		$data['lokasi'] = 'Tambah PA';
		$data['jenis'] = 'tambah pa';
		$this->load->view('admin/v_index', $data);
	}

	public function edit_pa($id)
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		
		if ($_POST==NULL) {
			$data['hasil'] = $this->m_pa->tampil_edit($id);
			$data['jenis'] = 'edit pa';
			$data['lokasi'] = 'Edit PA';
			$this->load->view('admin/v_index',$data);
		} else {
			$this->m_pa->ubah($id);
			redirect('prodi/pa');
		}
	}

	public function hapus_pa($id)
	{
		$this->m_pa->hapus($id);
		redirect('prodi/pa');
	}

	public function matkul()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$idprodi = $this->session->userdata('idprodi');
		
		$data['lokasi'] = 'Matakuliah';
		$data['jenis'] = 'matkul';
		$data['d_matkul'] = $this->m_matkul->tampil($idprodi);
		$this->load->view('admin/v_index', $data);
	}

	public function tambah_matkul()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		
		$this->form_validation->set_rules('kdmk', 'Kode MK', 'required');
		$this->form_validation->set_rules('matkul', 'Matakuliah', 'required');
		$this->form_validation->set_rules('sks', 'SKS', 'required');
	  
	    if ($this->form_validation->run() == TRUE) {
	      if ($this->input->post('simpan')) {
	        $this->m_matkul->simpan();
	        redirect('prodi/matkul');
	      }
	    }
		$data['lokasi'] = 'Tambah matkul';
		$data['jenis'] = 'tambah matkul';
		$data['d_prodi'] = $this->m_prodi->tampil();
		$this->load->view('admin/v_index', $data);
	}

	public function edit_matkul($id)
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		
		if ($_POST==NULL) {
			$data['hasil'] = $this->m_matkul->tampil_edit($id);
			$data['jenis'] = 'edit matkul';
			$data['lokasi'] = 'Edit matkul';
			$data['d_prodi'] = $this->m_prodi->tampil();
			$this->load->view('admin/v_index',$data);
		} else {
			$this->m_matkul->ubah($id);
			redirect('prodi/matkul');
		}
	}

	public function hapus_matkul($id)
	{
		$this->m_matkul->hapus($id);
		redirect('prodi/matkul');
	}

	public function jadwal_matkul()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		
		$data['lokasi'] = 'Jadwal Matakuliah';
		$data['jenis'] = 'jadwal matkul';
		$data['d_jadwal'] = $this->m_jadwal->tampil();
		$this->load->view('admin/v_index', $data);
	}

	public function tambah_jadwal_matkul()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		
		$this->form_validation->set_rules('hari', 'Hari', 'required');
		$this->form_validation->set_rules('mk', 'Matakuliah', 'required');
		$this->form_validation->set_rules('ruang', 'Ruang', 'required');
		$this->form_validation->set_rules('ruang', 'Ruang', 'required');
	  
	    if ($this->form_validation->run() == TRUE) {
	      if ($this->input->post('simpan')) {
	        $this->m_jadwal->simpan();
	        redirect('prodi/jadwal_matkul');
	      }
	    }
		$data['lokasi'] = 'Tambah jadwal';
		$data['jenis'] = 'tambah jadwal matkul';
		$this->load->view('admin/v_index', $data);
	}

	public function edit_jadwal_matkul($id)
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		
		if ($_POST==NULL) {
			$data['hasil'] = $this->m_jadwal->tampil_edit($id);
			$data['jenis'] = 'edit jadwal matkul';
			$data['lokasi'] = 'Edit Jadwal';
			$this->load->view('admin/v_index',$data);
		} else {
			$this->m_jadwal->ubah($id);
			redirect('prodi/jadwal_matkul');
		}
	}

	public function hapus_jadwal_matkul($id)
	{
		$this->m_jadwal->hapus($id);
		redirect('prodi/jadwal_matkul');
	}

	public function nilai()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'mhs_nilai';
		$data['lokasi'] = 'Daftar Mahasiswa';
		$data['daf_mhs'] = $this->m_nilai->mhs_nilai();
		$this->load->view('admin/v_index', $data);
		
	}

	public function mhs_nilai()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'thn';
		$data['lokasi'] = 'Nilai Mahasiswa';
		$data['d_thn'] = $this->m_nilai->tampil_thn();
		$this->load->view('admin/v_index', $data);
	}

	public function daftar_nilai()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'daftar_nilai';
		$data['lokasi'] = 'Nilai Mahasiswa';
		$data['daf_krs'] = $this->m_nilai->daf_krs();
		$this->load->view('admin/v_index', $data); 
	}

	public function simpan_nilai()
	{
		$nim = $this->input->post('nim');
		$thn = $this->input->post('thn');
		$this->m_nilai->simpan_nilai();
		redirect('prodi/daftar_nilai/'.$thn.'/'.$nim);
	}

	public function khs()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'khs';
		$data['lokasi'] = 'Daftar Mahasiswa';
		$data['daf_mhs'] = $this->m_nilai->mhs_nilai();
		$this->load->view('admin/v_index', $data);
		
	}

	public function thn_khs()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'thn_mhs';
		$data['lokasi'] = 'Tahun Akademik';
		$data['d_thn'] = $this->m_nilai->tampil_thn();
		$this->load->view('admin/v_index', $data);
	}

	public function detail_khs()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'khs_nilai';
		$data['lokasi'] = 'KHS Mahasiswa';
		$data['daf_khs'] = $this->m_nilai->daf_khs();
		$this->load->view('admin/v_index', $data); 
	}

	public function daftar_kp()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'daftar_kp';
		$data['lokasi'] = 'Daftar Mahasiswa Kerja Praktek';
		$this->load->view('admin/v_index', $data); 
	}

	public function hapus_daftar_kp($id)
	{
		$this->db->where('id_daftar', $id);
		$this->db->delete('daftar_kp');
		redirect('prodi/daftar_kp');
	}

	public function laporan_kp()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'laporan_kp';
		$data['lokasi'] = 'Laporan Kerja Praktek';
		$this->load->view('admin/v_index', $data); 
	}

	public function hapus_laporan_kp($id)
	{
		$this->db->where('id_upload', $id);
		$this->db->delete('upload_kp');
		redirect('prodi/laporan_kp');
	}

	public function pengajuan_cuti()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'pengajuan_cuti';
		$data['lokasi'] = 'Pengajuan Cuti Mahasiswa';
		$this->load->view('admin/v_index', $data); 
	}

	public function pengajuan_transfer()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['idprodi'] = $this->session->userdata('idprodi');
		$data['jenis'] = 'pengajuan_transfer';
		$data['lokasi'] = 'Pengajuan Transfer Mahasiswa';
		$this->load->view('admin/v_index', $data); 
	}
	
	public function hapus_pengajuan_cuti($id)
	{
		$this->db->where('id_pengajuan', $id);
		$this->db->delete('pengajuan_cuti');
		redirect('prodi/pengajuan_cuti');
	}

	public function hapus_pengajuan_transfer($id)
	{
		$this->db->where('id_transfer', $id);
		$this->db->delete('pengajuan_transfer');
		redirect('prodi/pengajuan_transfer');
	}

}
