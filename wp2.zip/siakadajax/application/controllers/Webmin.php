<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Webmin extends CI_Controller {

	function __construct(){
        parent::__construct();

        if ($this->session->userdata('level')=="" || $this->session->userdata('level') !=="admin" ) {
			redirect('login');
		}
        $this->load->model('m_prodi');
        $this->load->model('m_ruang');
        $this->load->model('m_kelas');
        $this->load->model('m_matkul');
        $this->load->model('m_semester');
        $this->load->model('m_thnakademik');
        $this->load->model('m_dosen');
        $this->load->model('m_jadwal');
        $this->load->model('m_mhs');
        $this->load->model('m_nilai');
        $this->load->model('m_user');
        $this->load->helper('tglindo_helper');
    }

    public function logout() {
		$this->session->unset_userdata('nama_lengkap');
		$this->session->unset_userdata('foto_user');
		$this->session->unset_userdata('level');
		session_destroy();
		redirect('login');
	}
	
	public function index()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['lokasi'] = 'Dashboard';
		$data['jenis'] = 'home';
		$this->load->view('admin/v_index', $data);
	}

	public function prodi()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['lokasi'] = 'Data Prodi';
		$data['jenis'] = 'prodi';
		$data['d_prodi'] = $this->m_prodi->tampil();
		$this->load->view('admin/v_index', $data);
	}

	public function tambah_prodi()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');

		$this->form_validation->set_rules('prodi', 'Nama Prodi', 'required');
	  
	    if ($this->form_validation->run() == TRUE) {
	      if ($this->input->post('simpan')) {
	        $this->m_prodi->simpan();
	        redirect('webmin/prodi');
	      }
	    }
		$data['lokasi'] = 'Tambah Prodi';
		$data['jenis'] = 'tambah prodi';
		$this->load->view('admin/v_index', $data);
	}

	public function edit_prodi($id)
	{
		if ($_POST==NULL) {
			$data['hasil'] = $this->m_prodi->tampil_edit($id);
			$data['jenis'] = 'edit prodi';
			$data['lokasi'] = 'Edit Prodi';
			$this->load->view('admin/v_index',$data);
		} else {
			$this->m_prodi->ubah($id);
			redirect('webmin/prodi');
		}
	}

	public function hapus_prodi($id)
	{
		$this->m_prodi->hapus($id);
		redirect('webmin/prodi');
	}

	public function user()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		$data['lokasi'] = 'Data User';
		$data['jenis'] = 'user';
		$data['d_user'] = $this->m_user->tampil();
		$this->load->view('admin/v_index', $data);
	}

	/*public function tambah_user()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');

		$this->form_validation->set_rules('prodi', 'Nama Prodi', 'required');
	  
	    if ($this->form_validation->run() == TRUE) {
	      if ($this->input->post('simpan')) {
	        $this->m_user->simpan();
	        redirect('webmin/prodi');
	      }
	    }
		$data['lokasi'] = 'Tambah User';
		$data['jenis'] = 'tambah_user';
		$this->load->view('admin/v_index', $data);
	}*/
	
	public function tambah_user()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');

	//	$this->form_validation->set_rules('prodi', 'Nama Prodi', 'required');
	  
	   
	      if ($this->input->post('simpan')) {
	       $username = $this->input->post('username');
		$id_prodi = $this->input->post('idprodi');
		$nama = $this->input->post('nama');
		$level = $this->input->post('level');
		$pass = md5($this->input->post('password'));
		//$gambar = $_FILES['userfile']['name'];
		
		$data = array('nama_lengkap' => $nama,
	                  'username' => $username, 
	                  'id_prodi' => $id_prodi,
	                  'level' => $level,
	                  'password' => $pass);
		$this->db->insert('users', $data);
		redirect('webmin/user');
	                	
	      }
	    
		$data['lokasi'] = 'Tambah User';
		$data['jenis'] = 'tambah_user';
		$this->load->view('admin/v_index', $data);
		
	}

	/*public function edit_user($id)
	{
		if ($_POST==NULL) {
			$data['hasil'] = $this->m_user->tampil_edit($id);
			$data['jenis'] = 'edit user';
			$data['lokasi'] = 'Edit User';
			$this->load->view('admin/v_index',$data);
		} else {
			$this->m_user->ubah($id);
			redirect('webmin/users');
		}
	}*/
	
	
	
	public function hapus_user($id)
	{
		/*$this->m_user->hapus($id);
		redirect('webmin/prodi');*/
		
		$this->db->where('id_user', $id);
	    $this->db->delete('users');
		redirect('webmin/user');
		
	}

	public function ruang()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		
		$data['lokasi'] = 'Ruang Kelas';
		$data['jenis'] = 'ruang';
		$data['d_ruang'] = $this->m_ruang->tampil();
		$this->load->view('admin/v_index', $data);
	}

	public function tambah_ruang()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		
		$this->form_validation->set_rules('ruang', 'Nama Ruang', 'required');
	  
	    if ($this->form_validation->run() == TRUE) {
	      if ($this->input->post('simpan')) {
	        $this->m_ruang->simpan();
	        redirect('webmin/ruang');
	      }
	    }
		$data['lokasi'] = 'Tambah Ruang';
		$data['jenis'] = 'tambah ruang';
		$this->load->view('admin/v_index', $data);
	}

	public function edit_ruang($id)
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		
		if ($_POST==NULL) {
			$data['hasil'] = $this->m_ruang->tampil_edit($id);
			$data['jenis'] = 'edit ruang';
			$data['lokasi'] = 'Edit Ruang';
			$this->load->view('admin/v_index',$data);
		} else {
			$this->m_ruang->ubah($id);
			redirect('webmin/ruang');
		}
	}

	public function hapus_ruang($id)
	{
		$this->m_ruang->hapus($id);
		redirect('webmin/ruang');
	}

	public function kelas()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		
		$data['lokasi'] = 'Daftar Kelas';
		$data['jenis'] = 'kelas';
		$data['d_kelas'] = $this->m_kelas->tampil();
		$this->load->view('admin/v_index', $data);
	}

	public function tambah_kelas()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		
		$this->form_validation->set_rules('kelas', 'Nama Kelas', 'required');
		$this->form_validation->set_rules('idprodi', 'Prodi', 'required');
	  
	    if ($this->form_validation->run() == TRUE) {
	      if ($this->input->post('simpan')) {
	        $this->m_kelas->simpan();
	        redirect('webmin/kelas');
	      }
	    }
		$data['lokasi'] = 'Tambah Kelas';
		$data['jenis'] = 'tambah kelas';
		$data['d_prodi'] = $this->m_prodi->tampil();
		$this->load->view('admin/v_index', $data);
	}

	public function edit_kelas($id)
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		
		if ($_POST==NULL) {
			$data['hasil'] = $this->m_kelas->tampil_edit($id);
			$data['jenis'] = 'edit kelas';
			$data['lokasi'] = 'Edit Kelas';
			$data['d_prodi'] = $this->m_prodi->tampil();
			$this->load->view('admin/v_index',$data);
		} else {
			$this->m_kelas->ubah($id);
			redirect('webmin/kelas');
		}
	}

	public function hapus_kelas($id)
	{
		$this->m_kelas->hapus($id);
		redirect('webmin/Kelas');
	}

	public function semester()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		
		$data['lokasi'] = 'Daftar Semester';
		$data['jenis'] = 'semester';
		$data['d_semester'] = $this->m_semester->tampil();
		$this->load->view('admin/v_index', $data);
	}

	public function tambah_semester()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		
		$this->form_validation->set_rules('semester', 'Semester', 'required');
	  
	    if ($this->form_validation->run() == TRUE) {
	      if ($this->input->post('simpan')) {
	        $this->m_semester->simpan();
	        redirect('webmin/semester');
	      }
	    }
		$data['lokasi'] = 'Tambah Semester';
		$data['jenis'] = 'tambah semester';
		$this->load->view('admin/v_index', $data);
	}

	public function edit_semester($id)
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		
		if ($_POST==NULL) {
			$data['hasil'] = $this->m_semester->tampil_edit($id);
			$data['jenis'] = 'edit semester';
			$data['lokasi'] = 'Edit Semester';
			$this->load->view('admin/v_index',$data);
		} else {
			$this->m_semester->ubah($id);
			redirect('webmin/semester');
		}
	}

	public function hapus_semester($id)
	{
		$this->m_semester->hapus($id);
		redirect('webmin/semester');
	}

	

	public function thn_akademik()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');
		
		$data['lokasi'] = 'Tahun Akademik';
		$data['jenis'] = 'thn akademik';
		$this->load->view('admin/v_index', $data);
	}
	public function tabel_thn()
	{
		$data['d_thn'] = $this->m_thnakademik->tampil_data();
		$this->load->view('admin/thn/tabel', $data);
	}
	public function simpan_thn()
	{
		$this->m_thnakademik->simpan();
		$pesan = array('pesan'=>'Sukses','status'=>true);
		echo json_encode($pesan);
	}
	public function edit_thn()
	{
		$hasil = $this->m_thnakademik->tampil_ubah();
		$idthn = $hasil->id_tahun;
		$thn = $hasil->tahun;
		$ket = $hasil->ket;
		$pesan = array('pesan'=>'Sukses','status'=>true,'id'=>$idthn,'tahun'=>$thn,'ket'=>$ket);
		echo json_encode($pesan);
	}

	public function ubah_thn()
	{
		$this->m_thnakademik->ubah();
		$pesan = array('pesan'=>'Sukses','status'=>true);
		echo json_encode($pesan);
	}

	public function hapus_thn()
	{
		$this->m_thnakademik->hapus();
		$pesan = array('pesan'=>'Sukses','status'=>true);
		echo json_encode($pesan);
	}

	public function ubah_status_thn()
	{
		//tutup semua status
		$c = array('status' => 'Tutup');
      	$this->db->update('tahun_akademik', $c);
      	//buat status baru
		$id = $this->input->post('id');
      	$status = $this->input->post('status');
      	$d = array('status' => $status);
      	$this->db->where('id_tahun', $id);
      	$this->db->update('tahun_akademik', $d);
      	echo "berhasil ubah status !";
	}

	public function mahasiswa()
	{
		$data['nama_lengkap'] = $this->session->userdata('nama_lengkap');
		$data['foto'] = $this->session->userdata('foto_user');

		$data['lokasi'] = 'Mahasiswa';
		$data['jenis'] = 'mahasiswa';
		$data['d_prodi'] = $this->m_prodi->tampil();
		$this->load->view('admin/v_index', $data);
	}
	public function tabel_mhs()
	{
		$data['d_mhs'] = $this->m_mhs->tampil_data();
		$this->load->view('admin/mhs/tabel', $data);
	}
	public function simpan_mhs()
	{
		$this->m_mhs->simpan();
		$pesan = array('pesan'=>'Sukses','status'=>true);
		echo json_encode($pesan);
	}
	public function edit_mhs()
	{
		$hasil = $this->m_mhs->tampil_ubah();
		$id = $hasil->id_mahasiswa;
		$pass = $hasil->password;
		$nim = $hasil->nim;
		$nama = $hasil->nama_lengkap;
		$alamat = $hasil->alamat;
		$nohp = $hasil->nohp;
		$jk = $hasil->jk;
		$tempat = $hasil->tempat;
		$tgl = $hasil->tgl_lahir;
		$idprodi = $hasil->id_prodi;
		$dosen = $hasil->dosen_pa;
		$foto = $hasil->foto_mahasiswa;
		$pesan = array('pesan'=>'Sukses',
					   'status'=>true,
					   'id'=>$id,
					   'nim'=>$nim,
					   'pass'=>$pass,
					   'nama'=>$nama,
					   'alamat'=>$alamat,
					   'nohp'=>$nohp,
					   'jk'=>$jk,
					   'tempat'=>$tempat,
					   'tgl'=>$tgl,
					   'idprodi'=>$idprodi,
					   'dosen'=>$dosen,
					   'foto'=>$foto);
		echo json_encode($pesan);
	}

	public function ubah_mhs()
	{
		$this->m_mhs->ubah();
		$pesan = array('pesan'=>'Sukses','status'=>true);
		echo json_encode($pesan);
	}

	public function hapus_mhs()
	{
		$img = $this->input->post('foto');
		$path1 = './image/mhs/'.$img;
        $path2 = './image/mhs/thumbnails/'.$img;
        unlink($path1);
        unlink($path2);
		$this->m_mhs->hapus();
		$pesan = array('pesan'=>'Sukses','status'=>true);
		echo json_encode($pesan);
	}

	public function detail_mhs()
	{
		$hasil = $this->m_mhs->tampil_ubah();
		$id = $hasil->id_mahasiswa;
		$pass = $hasil->password;
		$nim = $hasil->nim;
		$nama = $hasil->nama_lengkap;
		$alamat = $hasil->alamat;
		$nohp = $hasil->nohp;
		$jk = $hasil->jk;
		$tempat = $hasil->tempat;
		$tgl = $hasil->tgl_lahir;
		$dosen = $hasil->dosen_pa;

		$nmdosenpa = $this->db->query("SELECT nm_dosen from dosen where nidn='$dosen'")->row();

		$dosen = $nmdosenpa->nm_dosen;

		$idprodi = $hasil->id_prodi;
		$sql = $this->db->query("SELECT nm_prodi from prodi WHERE id_prodi='$idprodi'")->row();
		$idprodi = $sql->nm_prodi;
		$foto = $hasil->foto_mahasiswa;
		$pesan = array('pesan'=>'Sukses',
					   'status'=>true,
					   'id'=>$id,
					   'nim'=>$nim,
					   'pass'=>$pass,
					   'nama'=>$nama,
					   'alamat'=>$alamat,
					   'nohp'=>$nohp,
					   'jk'=>$jk,
					   'tempat'=>$tempat,
					   'tgl'=>$tgl,
					   'idprodi'=>$idprodi,
					   'dosen'=>$dosen,
					   'foto'=>$foto);
		echo json_encode($pesan);
	}
public function informasi(){
		$data['data'] = $this->db->get('informasi');
		$data['lokasi'] = 'informasi';
		$data['jenis'] = 'informasi';
		$this->load->view('admin/v_index', $data);
	}
	public function tambah_informasi(){
		$id_informasi = $this->input->post('id_informasi');
		$informasi = $this->input->post('informasi');
		$data = array('informasi' => $informasi );

		$this->db->where('id_informasi',$id_informasi);
		$this->db->update('informasi',$data);
		redirect('webmin/informasi');
	}

	
}
