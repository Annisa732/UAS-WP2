<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_nilai extends CI_Model {

	public function tampil_thn()
	{
		$this->db->select('*');
		$this->db->from('tahun_akademik');
		$this->db->order_by('id_tahun','desc');
		$query = $this->db->get();
		return $query;
	}

	public function mhs_nilai()
	{
		$idprodi = $this->session->userdata('idprodi');

		$sql = $this->db->query("SELECT * FROM mahasiswa WHERE mahasiswa.id_prodi='$idprodi'");
		return $sql;
	}

	public function daf_krs()
	{
		$thn = $this->uri->segment(3);
		$nim = $this->uri->segment(4);

		$sql = $this->db->query("SELECT * FROM nilai_mahasiswa WHERE 
			nilai_mahasiswa.nim='$nim' AND nilai_mahasiswa.thn_akademik='$thn'");
		return $sql;

	}

	public function daf_khs()
	{
		$thn = $this->uri->segment(3);
		$nim = $this->uri->segment(4);

		$sql = $this->db->query("SELECT * FROM nilai_mahasiswa WHERE 
			nilai_mahasiswa.nim='$nim' AND nilai_mahasiswa.thn_akademik='$thn'");
		return $sql;

	}

	public function transkrip()
	{
		$thn = $this->uri->segment(3);
		$nim = $this->uri->segment(4);

		$sql = $this->db->query("SELECT * FROM nilai_mahasiswa WHERE 
			nilai_mahasiswa.nim='$nim'");
		return $sql;

	}

	public function simpan_nilai()
	{
		$nim = $this->input->post('nim');
		$thn = $this->input->post('thn');
		$kdmk = $this->input->post('kdmk');
		$absen = $this->input->post('absen');
		$kuis = $this->input->post('kuis');
		$mid = $this->input->post('mid');
		$uas = $this->input->post('uas');

		$total = ($absen*0.1)+($kuis*0.2)+($mid*0.3)+($uas*0.4);

		$data = array('absen' => $absen,
					  'kuis' => $kuis,
					  'mid' => $mid,
					  'uas' => $uas,
					  'total' => $total);
		$this->db->where('nim', $nim);
		$this->db->where('kd_matkul', $kdmk);
		$this->db->update('nilai_mahasiswa', $data);
	}




	public function tampil_data()
	{
		$this->db->select('*');
		$this->db->from('tahun_akademik');
		$this->db->order_by('id_tahun','desc');
		$query = $this->db->get();
		return $query;
	}

	public function simpan()
	{
		$tahun = $this->input->post('thn');
		$ket = $this->input->post('ket');

		$data = array('tahun'=>$tahun,
					  'ket'=>$ket);
		$this->db->insert('tahun_akademik', $data);
	}

	public function tampil_ubah()
	{
		$id = $this->input->post('id');
		$hasil = $this->db->get_where('tahun_akademik', array('id_tahun'=>$id))->row();
		return $hasil;
	}

	public function ubah()
	{
		$id = $this->input->post('id');
		$tahun = $this->input->post('thn');
		$ket = $this->input->post('ket');

		$data = array('tahun'=>$tahun,
					  'ket'=>$ket);
		$this->db->where('id_tahun', $id);
		$this->db->update('tahun_akademik', $data);
	}

	public function hapus()
	{
		$id = $this->input->post('id');
		$this->db->delete('tahun_akademik', array('id_tahun'=>$id));
	}

}