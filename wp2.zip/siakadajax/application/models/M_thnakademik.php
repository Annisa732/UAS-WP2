<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_thnakademik extends CI_Model {

	public function tampil_data()
	{
		$this->db->select('*');
		$this->db->from('tahun_akademik');
		$this->db->order_by('id_tahun','desc');
		$query = $this->db->get();
		return $query;
	}

	public function simpan()
	{
		$tahun = $this->input->post('thn');
		$ket = $this->input->post('ket');

		$data = array('tahun'=>$tahun,
					  'ket'=>$ket);
		$this->db->insert('tahun_akademik', $data);
	}

	public function tampil_ubah()
	{
		$id = $this->input->post('id');
		$hasil = $this->db->get_where('tahun_akademik', array('id_tahun'=>$id))->row();
		return $hasil;
	}

	public function ubah()
	{
		$id = $this->input->post('id');
		$tahun = $this->input->post('thn');
		$ket = $this->input->post('ket');

		$data = array('tahun'=>$tahun,
					  'ket'=>$ket);
		$this->db->where('id_tahun', $id);
		$this->db->update('tahun_akademik', $data);
	}

	public function hapus()
	{
		$id = $this->input->post('id');
		$this->db->delete('tahun_akademik', array('id_tahun'=>$id));
	}

}