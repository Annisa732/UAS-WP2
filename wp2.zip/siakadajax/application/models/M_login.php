<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class M_login extends CI_Model {

		public function cek_mhs($data) {
			$query = $this->db->get_where('mahasiswa', $data);
			return $query;
		}

		public function cek_user($data) {
			$query = $this->db->get_where('users', $data);
			return $query;
		}

	}

?>