<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_semester extends CI_Model {

	
	public function tampil()
	{
		$query = $this->db->query("SELECT * FROM semester ORDER BY id_semester DESC ");
		return $query;
	}

	public function simpan()
	{
		$semester = $this->input->post('semester');
		$data = array('semester' => $semester);
		$this->db->insert('semester', $data);
	}

	public function tampil_edit($id)
	{
		return $this->db->get_where('semester', array('id_semester' => $id))->row();
	}

	public function ubah($id)
	{
		$semester = $this->input->post('semester');
		$data = array('semester' => $semester);
		$this->db->where('id_semester', $id);
		$this->db->update('semester', $data);
	}

	public function hapus($id)
	{
		$this->db->where('id_semester', $id);
	    $this->db->delete('semester');
	}
	
}
