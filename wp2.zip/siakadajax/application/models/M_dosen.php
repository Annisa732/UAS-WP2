<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_dosen extends CI_Model {

	
	public function tampil()
	{
		$query = $this->db->query("SELECT * FROM dosen ORDER BY id_dosen DESC ");
		return $query;
	}

	public function simpan()
	{
		$dosen = $this->input->post('dosen');
		$nidn = $this->input->post('nidn');
		$idprodi = $this->session->userdata('idprodi');
		$data = array(
			'nidn' => $nidn,
			'id_prodi' => $idprodi,
			'nm_dosen' => $dosen);
		$this->db->insert('dosen', $data);
	}

	public function tampil_edit($id)
	{
		return $this->db->get_where('dosen', array('id_dosen' => $id))->row();
	}

	public function ubah($id)
	{
		$dosen = $this->input->post('dosen');
		$nidn = $this->input->post('nidn');

		$data = array(
			'nidn' => $nidn,
			'nm_dosen' => $dosen);
		$this->db->where('id_dosen', $id);
		$this->db->update('dosen', $data);
	}

	public function hapus($id)
	{
		$this->db->where('id_dosen', $id);
	    $this->db->delete('dosen');
	}
	
}
