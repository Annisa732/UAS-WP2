<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_prodi extends CI_Model {

	
	public function tampil()
	{
		$query = $this->db->query("SELECT * FROM prodi ORDER BY id_prodi DESC ");
		return $query;
	}

	public function simpan()
	{
		$prodi = $this->input->post('prodi');
		$data = array('nm_prodi' => $prodi);
		$this->db->insert('prodi', $data);
	}

	public function tampil_edit($id)
	{
		return $this->db->get_where('prodi', array('id_prodi' => $id))->row();
	}

	public function ubah($id)
	{
		$prodi = $this->input->post('prodi');
		$data = array('nm_prodi' => $prodi);
		$this->db->where('id_prodi', $id);
		$this->db->update('prodi', $data);
	}

	public function hapus($id)
	{
		$this->db->where('id_prodi', $id);
	    $this->db->delete('prodi');
	}
	
}
