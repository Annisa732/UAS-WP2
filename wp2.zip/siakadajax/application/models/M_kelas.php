<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_kelas extends CI_Model {

	
	public function tampil()
	{
		$query = $this->db->query("SELECT * FROM kelas,prodi where kelas.id_prodi=prodi.id_prodi ORDER BY kelas.id_kelas DESC ");
		return $query;
	}

	public function simpan()
	{
		$kelas = $this->input->post('kelas');
		$idprodi = $this->input->post('idprodi');
		$data = array('kelas' => $kelas,
					  'id_prodi' => $idprodi);
		$this->db->insert('kelas', $data);
	}

	public function tampil_edit($id)
	{
		return $this->db->get_where('kelas', array('id_kelas' => $id))->row();
	}

	public function ubah($id)
	{
		$kelas = $this->input->post('kelas');
		$idprodi = $this->input->post('idprodi');
		$data = array('kelas' => $kelas,
					  'id_prodi' => $idprodi);
		$this->db->where('id_kelas', $id);
		$this->db->update('kelas', $data);
	}

	public function hapus($id)
	{
		$this->db->where('id_kelas', $id);
	    $this->db->delete('kelas');
	}
	
}
