<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_ruang extends CI_Model {

	
	public function tampil()
	{
		$query = $this->db->query("SELECT * FROM ruang ORDER BY id_ruang DESC ");
		return $query;
	}

	public function simpan()
	{
		$ruang = $this->input->post('ruang');
		$data = array('ruang' => $ruang);
		$this->db->insert('ruang', $data);
	}

	public function tampil_edit($id)
	{
		return $this->db->get_where('ruang', array('id_ruang' => $id))->row();
	}

	public function ubah($id)
	{
		$ruang = $this->input->post('ruang');
		$data = array('ruang' => $ruang);
		$this->db->where('id_ruang', $id);
		$this->db->update('ruang', $data);
	}

	public function hapus($id)
	{
		$this->db->where('id_ruang', $id);
	    $this->db->delete('ruang');
	}
	
}
