<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_matkul extends CI_Model {

	
	public function tampil($idprodi)
	{
		$query = $this->db->query("SELECT * FROM matakuliah, prodi WHERE matakuliah.id_prodi=prodi.id_prodi and matakuliah.id_prodi='$idprodi' ORDER BY matakuliah.kd_matkul DESC ");
		return $query;
	}

	public function simpan()
	{
		$kdmatkul = $this->input->post('kdmk');
		$matkul = $this->input->post('matkul');
		$tipesemester = $this->input->post('tipesemester');
		$semester = $this->input->post('semester');
		$sks = $this->input->post('sks');
		$idprodi = $this->input->post('idprodi');
		$data = array('kd_matkul' => $kdmatkul,
					  'nm_matkul' => $matkul,
					  'tipe_semester' => $tipesemester,
					  'semester' => $semester,
					  'sks' => $sks,
					  'id_prodi' => $idprodi);
		$this->db->insert('matakuliah', $data);
	}

	public function tampil_edit($id)
	{
		return $this->db->get_where('matakuliah', array('kd_matkul' => $id))->row();
	}

	public function ubah($id)
	{
		$matkul = $this->input->post('matkul');
		$tipesemester = $this->input->post('tipesemester');
		$semester = $this->input->post('semester');
		$sks = $this->input->post('sks');
		$idprodi = $this->input->post('idprodi');
		$data = array('nm_matkul' => $matkul,
					  'sks' => $sks,
					  'tipe_semester' => $tipesemester,
					  'semester' => $semester,
					  'id_prodi' => $idprodi);
		$this->db->where('kd_matkul', $id);
		$this->db->update('matakuliah', $data);
	}

	public function hapus($id)
	{
		$this->db->where('kd_matkul', $id);
	    $this->db->delete('matakuliah');
	}
	
}
