<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_pa extends CI_Model {

	
	public function tampil($prodi)
	{
		
		$this->db->from('dosen_pa');
		$this->db->join('mahasiswa', 'mahasiswa.nim=dosen_pa.nim');
		$this->db->join('dosen','dosen.nidn=dosen_pa.nidn');
		$this->db->where('dosen.id_prodi','$prodi');
		return $this->db->get();
	}

	public function simpan()
	{
		$nidn = $this->input->post('nidn');
		$nim = $this->input->post('nim');
		
		$data = array(
			'nidn' => $nidn,
			'nim' => $nim);
		$this->db->insert('dosen_pa', $data);
	}

	public function tampil_edit($id)
	{
		return $this->db->get_where('dosen_pa', array('id_pa' => $id))->row();
	}

	public function ubah($id)
	{
		$nidn = $this->input->post('nidn');
		$nim = $this->input->post('nim');
		
		$data = array(
			'nidn' => $nidn,
			'nim' => $nim);
		$this->db->where('id_pa', $id);
		$this->db->update('dosen_pa', $data);
	}

	public function hapus($id)
	{
		$this->db->where('id_pa', $id);
	    $this->db->delete('dosen_pa');
	}
	
}
