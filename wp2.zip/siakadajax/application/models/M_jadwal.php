<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_jadwal extends CI_Model {

	
	public function tampil()
	{
		$query = $this->db->query("SELECT * FROM jadwal_kuliah, prodi, matakuliah, ruang, dosen, semester WHERE 
			jadwal_kuliah.id_prodi=prodi.id_prodi and 
			jadwal_kuliah.kd_matkul=matakuliah.kd_matkul and 
			jadwal_kuliah.id_ruang=ruang.id_ruang and 
			jadwal_kuliah.id_semester=semester.id_semester and 
			jadwal_kuliah.id_dosen=dosen.id_dosen ORDER BY jadwal_kuliah.id_jadwal DESC ");
		return $query;
	}

	public function simpan()
	{
		$hari = $this->input->post('hari');
		$kdmatkul = $this->input->post('mk');
		$idruang = $this->input->post('ruang');
		$jam_mulai = $this->input->post('jam_mulai');
		$jam_selesai = $this->input->post('jam_selesai');
		$iddosen = $this->input->post('dosen');
		$idprodi = $this->input->post('idprodi');
		$idsemester = $this->input->post('semester');
		
		$data = array('hari' => $hari,
					  'kd_matkul' => $kdmatkul,
					  'id_ruang' => $idruang,
					  'jam_mulai' => $jam_mulai,
					  'jam_selesai' => $jam_selesai,
					  'id_dosen' => $iddosen,
					  'id_semester' => $idsemester,
					  'id_prodi' => $idprodi);
		$this->db->insert('jadwal_kuliah', $data);
	}

	public function tampil_edit($id)
	{
		return $this->db->get_where('jadwal_kuliah', array('id_jadwal' => $id))->row();
	}

	public function ubah($id)
	{
		$hari = $this->input->post('hari');
		$kdmatkul = $this->input->post('mk');
		$idruang = $this->input->post('ruang');
		$jam_mulai = $this->input->post('jam_mulai');
		$jam_selesai = $this->input->post('jam_selesai');
		$iddosen = $this->input->post('dosen');
		$idprodi = $this->input->post('idprodi');
		$idsemester = $this->input->post('semester');
		
		$data = array('hari' => $hari,
					  'kd_matkul' => $kdmatkul,
					  'id_ruang' => $idruang,
					  'jam_mulai' => $jam_mulai,
					  'jam_selesai' => $jam_selesai,
					  'id_dosen' => $iddosen,
					  'id_semester' => $idsemester,
					  'id_prodi' => $idprodi);
		$this->db->where('id_jadwal', $id);
		$this->db->update('jadwal_kuliah', $data);
	}

	public function hapus($id)
	{
		$this->db->where('id_jadwal', $id);
	    $this->db->delete('jadwal_kuliah');
	}
	
}
