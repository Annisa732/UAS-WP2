<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_mhs extends CI_Model {

	var $gallerypath;
  	var $gallery_path_url;

	function __construct(){
	    parent::__construct();

	    $this->gallerypath = realpath(APPPATH . '../image/mhs');
		$this->gallery_path_url = base_url().'image/mhs/';
	}


	public function tampil_data()
	{
		$query = $this->db->query("SELECT * FROM mahasiswa, prodi WHERE
			mahasiswa.id_prodi = prodi.id_prodi 
			ORDER BY mahasiswa.id_mahasiswa DESC ");
		return $query;
	}

	public function simpan()
	{
		$konfigurasi = array('allowed_types' =>'jpg|jpeg|gif|png|bmp',
				             'upload_path' => $this->gallerypath);
		$this->load->library('upload', $konfigurasi);
		$this->upload->do_upload();
		$datafile = $this->upload->data();
		
		$konfigurasi = array('source_image' => $datafile['full_path'],
	                         'new_image' => $this->gallerypath . '/thumbnails',
				             'maintain_ration' => true,
				             'width' => 130,
			                 'height' =>100);

	    $this->load->library('image_lib', $konfigurasi);
		$this->image_lib->resize();

		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$pass = $this->input->post('pass');
		$alamat = $this->input->post('alamat');
		$nohp = $this->input->post('nohp');
		$jk = $this->input->post('jk');
		$tempat = $this->input->post('tempat');
		$tgl = $this->input->post('tgl');
		$idprodi = $this->input->post('idprodi');
		$dosen = $this->input->post('dosen');
		$gambar = $_FILES['userfile']['name'];
		$gambar = preg_replace('/ /', '_', $gambar);

		$data = array('nim'=>$nim,
					  'nama_lengkap'=>$nama,
					  'password'=>$pass,
					  'alamat'=>$alamat,
					  'nohp'=>$nohp,
					  'jk'=>$jk,
					  'tempat'=>$tempat,
					  'tgl_lahir'=>$tgl,
					  'id_prodi'=>$idprodi,
					  'dosen_pa' => $dosen,
					  'foto_mahasiswa'=>$gambar);
		$this->db->insert('mahasiswa', $data);
	}

	public function tampil_ubah()
	{
		$id = $this->input->post('id');
		$hasil = $this->db->get_where('mahasiswa', array('id_mahasiswa'=>$id))->row();
		return $hasil;
	}

	public function ubah()
	{
		$gambar = $_FILES['userfile']['name'];
		if (!empty($gambar)) {

			$konfigurasi = array('allowed_types' =>'jpg|jpeg|gif|png|bmp',
				             'upload_path' => $this->gallerypath);
			$this->load->library('upload', $konfigurasi);
			$this->upload->do_upload();
			$datafile = $this->upload->data();
			
			$konfigurasi = array('source_image' => $datafile['full_path'],
		                         'new_image' => $this->gallerypath . '/thumbnails',
					             'maintain_ration' => true,
					             'width' => 130,
				                 'height' =>100);

		    $this->load->library('image_lib', $konfigurasi);
			$this->image_lib->resize();

			$id = $this->input->post('id');
			$nim = $this->input->post('nim');
			$nama = $this->input->post('nama');
			$pass = $this->input->post('pass');
			$alamat = $this->input->post('alamat');
			$nohp = $this->input->post('nohp');
			$jk = $this->input->post('jk');
			$tempat = $this->input->post('tempat');
			$tgl = $this->input->post('tgl');
			$idprodi = $this->input->post('idprodi');
			$dosen = $this->input->post('dosen');
			$gambar = $_FILES['userfile']['name'];
			$gambar = preg_replace('/ /', '_', $gambar);

			$data = array('nim'=>$nim,
						  'nama_lengkap'=>$nama,
						  'password'=>$pass,
						  'alamat'=>$alamat,
						  'nohp'=>$nohp,
						  'jk'=>$jk,
						  'tempat'=>$tempat,
						  'tgl_lahir'=>$tgl,
						  'id_prodi'=>$idprodi,
						  'dosen_pa'=>$dosen,
						  'foto_mahasiswa'=>$gambar);
			$this->db->where('id_mahasiswa', $id);
			$this->db->update('mahasiswa', $data);
		} else {
			$id = $this->input->post('id');
			$nim = $this->input->post('nim');
			$pass = $this->input->post('pass');
			$nama = $this->input->post('nama');
			$alamat = $this->input->post('alamat');
			$nohp = $this->input->post('nohp');
			$jk = $this->input->post('jk');
			$tempat = $this->input->post('tempat');
			$tgl = $this->input->post('tgl');
			$idprodi = $this->input->post('idprodi');
			$dosen = $this->input->post('dosen');

			$data = array('nim'=>$nim,
						  'nama_lengkap'=>$nama,
						  'password'=>$pass,
						  'alamat'=>$alamat,
						  'nohp'=>$nohp,
						  'jk'=>$jk,
						  'tempat'=>$tempat,
						  'tgl_lahir'=>$tgl,
						  'dosen_pa'=>$dosen,
						  'id_prodi'=>$idprodi);
			$this->db->where('id_mahasiswa', $id);
			$this->db->update('mahasiswa', $data);
		}
		
	}

	public function hapus()
	{
		$id = $this->input->post('id');
		$this->db->delete('mahasiswa', array('id_mahasiswa'=>$id));
	}

}