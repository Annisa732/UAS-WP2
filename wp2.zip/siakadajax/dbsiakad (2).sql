-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2017 at 03:06 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbsiakad`
--

-- --------------------------------------------------------

--
-- Table structure for table `asal_sekolah`
--

CREATE TABLE `asal_sekolah` (
  `nim` varchar(20) DEFAULT NULL,
  `jurusan` varchar(30) DEFAULT NULL,
  `thn_lulus` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `biodata_ortu`
--

CREATE TABLE `biodata_ortu` (
  `nim` varchar(20) DEFAULT NULL,
  `nm_ayah` varchar(50) DEFAULT NULL,
  `nm_ibu` varchar(50) DEFAULT NULL,
  `pekerjaan_ayah` varchar(50) DEFAULT NULL,
  `pekerjaan_ibu` varchar(50) DEFAULT NULL,
  `alamat_ortu` text,
  `penghasilan_ayah` varchar(30) DEFAULT NULL,
  `penghasilan_ibu` varchar(30) DEFAULT NULL,
  `nohp_ortu` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `biodata_pribadi`
--

CREATE TABLE `biodata_pribadi` (
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `jk` enum('Laki-laki','Perempuan') DEFAULT NULL,
  `agama` varchar(15) DEFAULT NULL,
  `tempat_lahir` varchar(50) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  `alamat` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `daftar_kp`
--

CREATE TABLE `daftar_kp` (
  `id_daftar` int(11) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `tempat` varchar(100) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daftar_kp`
--

INSERT INTO `daftar_kp` (`id_daftar`, `nim`, `tempat`, `id_prodi`) VALUES
(1, '1402126', 'PT. Sumber Kawan Lama', 4);

-- --------------------------------------------------------

--
-- Table structure for table `daftar_ulang`
--

CREATE TABLE `daftar_ulang` (
  `id_daftar_ulang` int(11) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `semester` int(3) DEFAULT NULL,
  `tahun_akademik` varchar(10) DEFAULT NULL,
  `id_prodi` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daftar_ulang`
--

INSERT INTO `daftar_ulang` (`id_daftar_ulang`, `nim`, `nama`, `semester`, `tahun_akademik`, `id_prodi`) VALUES
(1, '1402126', 'Boy Kurniawan', 3, '20171', '4'),
(2, '', 'Prodi Tehnik Informatika', 1, '20171', ''),
(3, '1254634', 'rebi', 0, '20172', '3'),
(4, '1254634', 'rebi', 1, '20172', '3');

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `id_dosen` int(5) NOT NULL,
  `nidn` varchar(20) DEFAULT NULL,
  `nm_dosen` varchar(50) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`id_dosen`, `nidn`, `nm_dosen`, `id_prodi`) VALUES
(7, '01180586021', 'Reza Kurnia, MA', 1),
(8, '1420101', 'Irma Wati', 1),
(9, '1111', 'iqbal', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dosen_pa`
--

CREATE TABLE `dosen_pa` (
  `id_pa` int(11) NOT NULL,
  `nidn` varchar(20) DEFAULT NULL,
  `nim` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dosen_pa`
--

INSERT INTO `dosen_pa` (`id_pa`, `nidn`, `nim`) VALUES
(1, 'NID2222', '1402456'),
(2, 'NID2222', '1402145');

-- --------------------------------------------------------

--
-- Table structure for table `informasi`
--

CREATE TABLE `informasi` (
  `id_informasi` int(3) NOT NULL,
  `informasi` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `informasi`
--

INSERT INTO `informasi` (`id_informasi`, `informasi`, `tanggal`) VALUES
(1, 'Kepada seluruh mahasiswa universitas nurdin hamzah jambi agar mendaftarkan nim untuk mengakses halaman akademik ini . pendaftaran bisa di prodi ', '2017-10-29 16:47:32');

-- --------------------------------------------------------

--
-- Table structure for table `ipk_mhs`
--

CREATE TABLE `ipk_mhs` (
  `id_ipk` int(11) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `ipk` float DEFAULT NULL,
  `thn_akademik` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ipk_mhs`
--

INSERT INTO `ipk_mhs` (`id_ipk`, `nim`, `ipk`, `thn_akademik`) VALUES
(3, '1402126', 3.7, '20171'),
(5, '1402456', 0, '20171'),
(6, '1402126', 0, '20172');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_kuliah`
--

CREATE TABLE `jadwal_kuliah` (
  `id_jadwal` int(11) NOT NULL,
  `hari` varchar(10) DEFAULT NULL,
  `kd_matkul` varchar(10) DEFAULT NULL,
  `id_ruang` int(5) DEFAULT NULL,
  `jam_mulai` time DEFAULT NULL,
  `jam_selesai` time DEFAULT NULL,
  `id_dosen` int(5) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  `id_semester` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwal_kuliah`
--

INSERT INTO `jadwal_kuliah` (`id_jadwal`, `hari`, `kd_matkul`, `id_ruang`, `jam_mulai`, `jam_selesai`, `id_dosen`, `id_prodi`, `id_semester`) VALUES
(2, 'Rabu', 'KD64573', 1, '07:00:00', '08:45:00', 2, 4, 2),
(3, 'Selasa', 'MK055463', 2, '09:00:00', '11:30:00', 3, 4, 2),
(4, 'Selasa', 'KD64573', 1, '00:00:00', '00:00:00', 3, 4, 2),
(5, 'Senin', 'MKU101', 1, '00:00:00', '00:00:00', 7, 1, 2),
(6, 'Rabu', 'MKU102', 2, '00:00:00', '00:00:00', 7, 1, 2),
(7, 'Selasa', 'MKU201', 2, '00:00:00', '00:00:00', 7, 1, 3),
(8, 'Rabu', 'YHB201', 2, '00:00:00', '00:00:00', 7, 1, 3),
(9, 'Rabu', 'MKU301', 1, '00:00:00', '00:00:00', 7, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(5) NOT NULL,
  `kelas` varchar(15) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `kelas`, `id_prodi`) VALUES
(1, 'IK A', 1),
(2, 'IK B', 1);

-- --------------------------------------------------------

--
-- Table structure for table `krs`
--

CREATE TABLE `krs` (
  `id_krs` int(20) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `kd_matkul` varchar(20) DEFAULT NULL,
  `thn_akademik` varchar(30) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `krs`
--

INSERT INTO `krs` (`id_krs`, `nim`, `kd_matkul`, `thn_akademik`, `status`) VALUES
(47, '1402126', 'C2KB1316', '20171', '1'),
(48, '1402126', 'MK65364', '20171', '1'),
(49, '1402126', 'MK055463', '20171', '1'),
(51, '1402126', 'KD64573', '20172', '0'),
(57, '1714201001', 'MKU101', '20171', '1'),
(58, '1714201001', 'MKU102', '20171', '1'),
(59, '1714201001', 'MKU301', '20171', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id_mahasiswa` int(11) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `nama_lengkap` varchar(50) DEFAULT NULL,
  `alamat` text,
  `nohp` varchar(12) DEFAULT NULL,
  `jk` enum('Laki-laki','Perempuan') DEFAULT NULL,
  `tempat` varchar(30) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `id_prodi` int(11) DEFAULT NULL,
  `foto_mahasiswa` text,
  `password` varchar(30) DEFAULT NULL,
  `dosen_pa` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`id_mahasiswa`, `nim`, `nama_lengkap`, `alamat`, `nohp`, `jk`, `tempat`, `tgl_lahir`, `id_prodi`, `foto_mahasiswa`, `password`, `dosen_pa`) VALUES
(11, '1714201001', 'RISA HADARA', '', '', 'Laki-laki', 'Bebeban', '1995-01-20', 1, '', '1714201001', '1420101'),
(12, '1714201002', 'Salsabila', '', '', 'Perempuan', 'Bebesan', '1996-02-20', 1, '', '1714201002', '1420101');

-- --------------------------------------------------------

--
-- Table structure for table `matakuliah`
--

CREATE TABLE `matakuliah` (
  `kd_matkul` varchar(10) NOT NULL,
  `nm_matkul` varchar(50) DEFAULT NULL,
  `sks` int(5) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL,
  `tipe_semester` enum('1','2') DEFAULT NULL,
  `semester` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `matakuliah`
--

INSERT INTO `matakuliah` (`kd_matkul`, `nm_matkul`, `sks`, `id_prodi`, `tipe_semester`, `semester`) VALUES
('C2KB1316', 'Pengantar Teknologi Informasi', 3, 4, '1', 1),
('KD64573', 'Pemrograman Web 1', 4, 4, '2', 4),
('MK055463', 'Jaringan Komputer', 4, 4, '1', 5),
('mk12031', 'Kalkulus', 2, 4, '1', 3),
('MK65364', 'Matakuliah aaa', 3, 4, '1', 1),
('MKU101', 'Bahasa Indonesia', 2, 1, '1', 1),
('MKU102', 'Agama', 2, 1, '1', 1),
('MKU201', 'Pancasila', 2, 1, '2', 2),
('MKU301', 'Kewarganegaraan', 2, 1, '1', 1),
('YHB201', 'Pengantar Komputer', 2, 1, '2', 2);

-- --------------------------------------------------------

--
-- Table structure for table `nilai_mahasiswa`
--

CREATE TABLE `nilai_mahasiswa` (
  `id_nilai` int(11) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `kd_matkul` varchar(20) DEFAULT NULL,
  `absen` float DEFAULT '0',
  `kuis` float DEFAULT '0',
  `mid` float DEFAULT '0',
  `uas` float DEFAULT '0',
  `total` float DEFAULT '0',
  `thn_akademik` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai_mahasiswa`
--

INSERT INTO `nilai_mahasiswa` (`id_nilai`, `nim`, `kd_matkul`, `absen`, `kuis`, `mid`, `uas`, `total`, `thn_akademik`) VALUES
(12, '1402126', 'C2KB1316', 80.45, 95.5, 80.9, 45, 69.415, '20171'),
(13, '1402126', 'MK65364', 80, 90, 80.5, 80, 82.15, '20171'),
(14, '1402126', 'MK055463', 90, 80, 95, 80, 85.5, '20171'),
(16, '1402126', 'KD64573', 0, 0, 0, 0, 0, '20172'),
(22, '1714201001', 'MKU101', 0, 0, 0, 0, 0, '20171'),
(23, '1714201001', 'MKU102', 0, 0, 0, 0, 0, '20171'),
(24, '1714201001', 'MKU301', 0, 0, 0, 0, 0, '20171');

-- --------------------------------------------------------

--
-- Table structure for table `pengajuan_cuti`
--

CREATE TABLE `pengajuan_cuti` (
  `id_pengajuan` int(11) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `lama` varchar(30) DEFAULT NULL,
  `alasan` text,
  `id_prodi` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengajuan_cuti`
--

INSERT INTO `pengajuan_cuti` (`id_pengajuan`, `nim`, `lama`, `alasan`, `id_prodi`) VALUES
(1, '1254634', '', '1', 3);

-- --------------------------------------------------------

--
-- Table structure for table `pengajuan_transfer`
--

CREATE TABLE `pengajuan_transfer` (
  `id_transfer` int(11) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `transfer_ke` varchar(100) DEFAULT NULL,
  `jurusan` varchar(30) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengajuan_transfer`
--

INSERT INTO `pengajuan_transfer` (`id_transfer`, `nim`, `transfer_ke`, `jurusan`, `id_prodi`) VALUES
(1, '1402126', 'Unja', 'Ilmu komputer', 4);

-- --------------------------------------------------------

--
-- Table structure for table `prodi`
--

CREATE TABLE `prodi` (
  `id_prodi` int(5) NOT NULL,
  `nm_prodi` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prodi`
--

INSERT INTO `prodi` (`id_prodi`, `nm_prodi`) VALUES
(1, 'Ilmu Keperawatan'),
(3, 'Profesi Ners'),
(4, 'Ilmu Kesehatan Masyarakat');

-- --------------------------------------------------------

--
-- Table structure for table `ruang`
--

CREATE TABLE `ruang` (
  `id_ruang` int(5) NOT NULL,
  `ruang` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ruang`
--

INSERT INTO `ruang` (`id_ruang`, `ruang`) VALUES
(1, 'Ruang 3.1'),
(2, 'Ruang 3.2');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id_semester` int(5) NOT NULL,
  `semester` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id_semester`, `semester`) VALUES
(2, 'Semester 1'),
(3, 'Sementer 2'),
(4, 'Sementer 3'),
(5, 'Sementer 4'),
(6, 'Sementer 5'),
(7, 'Sementer 6'),
(8, 'Semester 7'),
(9, 'Semester 8');

-- --------------------------------------------------------

--
-- Table structure for table `tahun_akademik`
--

CREATE TABLE `tahun_akademik` (
  `id_tahun` int(5) NOT NULL,
  `tahun` varchar(6) DEFAULT NULL,
  `ket` text,
  `status` enum('Tutup','Buka') DEFAULT 'Tutup'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tahun_akademik`
--

INSERT INTO `tahun_akademik` (`id_tahun`, `tahun`, `ket`, `status`) VALUES
(27, '20171', '2017 ganjil', 'Buka'),
(28, '20172', '2017 Genap', 'Tutup');

-- --------------------------------------------------------

--
-- Table structure for table `upload_kp`
--

CREATE TABLE `upload_kp` (
  `id_upload` int(5) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `tempat` varchar(100) DEFAULT NULL,
  `nm_file` varchar(100) DEFAULT NULL,
  `id_prodi` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_kp`
--

INSERT INTO `upload_kp` (`id_upload`, `nim`, `tempat`, `nm_file`, `id_prodi`) VALUES
(18, '1402126', 'PT. SKL', 'lap.docx', 4);

-- --------------------------------------------------------

--
-- Table structure for table `upload_pratikum`
--

CREATE TABLE `upload_pratikum` (
  `id_pratikum` int(11) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `file` varchar(100) DEFAULT NULL,
  `id_prodi` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_pratikum`
--

INSERT INTO `upload_pratikum` (`id_pratikum`, `nim`, `nama`, `file`, `id_prodi`) VALUES
(1, '1402126', 'Boy Kurniawan', 'USULAN PENELITIAN KERJA PRAKTEK.docx', '4');

-- --------------------------------------------------------

--
-- Table structure for table `upload_quiz`
--

CREATE TABLE `upload_quiz` (
  `id_quiz` int(11) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `file` varchar(100) DEFAULT NULL,
  `id_prodi` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_quiz`
--

INSERT INTO `upload_quiz` (`id_quiz`, `nim`, `nama`, `file`, `id_prodi`) VALUES
(1, '1402126', 'Boy Kurniawan', 'USULAN_PENELITIAN_KERJA_PRAKTEK.docx', '4');

-- --------------------------------------------------------

--
-- Table structure for table `upload_tugas`
--

CREATE TABLE `upload_tugas` (
  `id_tugas` int(11) NOT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `file` varchar(100) DEFAULT NULL,
  `id_prodi` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_tugas`
--

INSERT INTO `upload_tugas` (`id_tugas`, `nim`, `nama`, `file`, `id_prodi`) VALUES
(1, '1402126', 'Boy Kurniawan', 'USULAN_PENELITIAN_KERJA_PRAKTEK.docx', '4');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(5) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `nama_lengkap` varchar(50) DEFAULT NULL,
  `foto_user` varchar(50) DEFAULT NULL,
  `level` enum('admin','prodi','dosen') DEFAULT 'prodi',
  `id_prodi` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`, `nama_lengkap`, `foto_user`, `level`, `id_prodi`) VALUES
(10, '133021', 'eedae20fc3c7a6e9c5b1102098771c70', 'STIKes YHB', NULL, 'admin', 1),
(11, '1420101', 'eedae20fc3c7a6e9c5b1102098771c70', 'Irma Wati', NULL, 'dosen', 1),
(12, 'PSIKYHB', 'eedae20fc3c7a6e9c5b1102098771c70', 'Ilmu Keperawatan', NULL, 'prodi', 1),
(13, 'NERSYHB', 'eedae20fc3c7a6e9c5b1102098771c70', 'Profesi Ners', NULL, 'prodi', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daftar_kp`
--
ALTER TABLE `daftar_kp`
  ADD PRIMARY KEY (`id_daftar`);

--
-- Indexes for table `daftar_ulang`
--
ALTER TABLE `daftar_ulang`
  ADD PRIMARY KEY (`id_daftar_ulang`);

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`id_dosen`);

--
-- Indexes for table `dosen_pa`
--
ALTER TABLE `dosen_pa`
  ADD PRIMARY KEY (`id_pa`);

--
-- Indexes for table `informasi`
--
ALTER TABLE `informasi`
  ADD PRIMARY KEY (`id_informasi`);

--
-- Indexes for table `ipk_mhs`
--
ALTER TABLE `ipk_mhs`
  ADD PRIMARY KEY (`id_ipk`);

--
-- Indexes for table `jadwal_kuliah`
--
ALTER TABLE `jadwal_kuliah`
  ADD PRIMARY KEY (`id_jadwal`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`),
  ADD KEY `id_kelas` (`id_kelas`);

--
-- Indexes for table `krs`
--
ALTER TABLE `krs`
  ADD PRIMARY KEY (`id_krs`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id_mahasiswa`);

--
-- Indexes for table `matakuliah`
--
ALTER TABLE `matakuliah`
  ADD PRIMARY KEY (`kd_matkul`);

--
-- Indexes for table `nilai_mahasiswa`
--
ALTER TABLE `nilai_mahasiswa`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `pengajuan_cuti`
--
ALTER TABLE `pengajuan_cuti`
  ADD PRIMARY KEY (`id_pengajuan`);

--
-- Indexes for table `pengajuan_transfer`
--
ALTER TABLE `pengajuan_transfer`
  ADD PRIMARY KEY (`id_transfer`);

--
-- Indexes for table `prodi`
--
ALTER TABLE `prodi`
  ADD PRIMARY KEY (`id_prodi`),
  ADD KEY `id_prodi` (`id_prodi`);

--
-- Indexes for table `ruang`
--
ALTER TABLE `ruang`
  ADD PRIMARY KEY (`id_ruang`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id_semester`);

--
-- Indexes for table `tahun_akademik`
--
ALTER TABLE `tahun_akademik`
  ADD PRIMARY KEY (`id_tahun`);

--
-- Indexes for table `upload_kp`
--
ALTER TABLE `upload_kp`
  ADD PRIMARY KEY (`id_upload`);

--
-- Indexes for table `upload_pratikum`
--
ALTER TABLE `upload_pratikum`
  ADD PRIMARY KEY (`id_pratikum`);

--
-- Indexes for table `upload_quiz`
--
ALTER TABLE `upload_quiz`
  ADD PRIMARY KEY (`id_quiz`);

--
-- Indexes for table `upload_tugas`
--
ALTER TABLE `upload_tugas`
  ADD PRIMARY KEY (`id_tugas`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daftar_kp`
--
ALTER TABLE `daftar_kp`
  MODIFY `id_daftar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `daftar_ulang`
--
ALTER TABLE `daftar_ulang`
  MODIFY `id_daftar_ulang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dosen`
--
ALTER TABLE `dosen`
  MODIFY `id_dosen` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `dosen_pa`
--
ALTER TABLE `dosen_pa`
  MODIFY `id_pa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `informasi`
--
ALTER TABLE `informasi`
  MODIFY `id_informasi` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ipk_mhs`
--
ALTER TABLE `ipk_mhs`
  MODIFY `id_ipk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `jadwal_kuliah`
--
ALTER TABLE `jadwal_kuliah`
  MODIFY `id_jadwal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `krs`
--
ALTER TABLE `krs`
  MODIFY `id_krs` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id_mahasiswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `nilai_mahasiswa`
--
ALTER TABLE `nilai_mahasiswa`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `pengajuan_cuti`
--
ALTER TABLE `pengajuan_cuti`
  MODIFY `id_pengajuan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pengajuan_transfer`
--
ALTER TABLE `pengajuan_transfer`
  MODIFY `id_transfer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `prodi`
--
ALTER TABLE `prodi`
  MODIFY `id_prodi` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ruang`
--
ALTER TABLE `ruang`
  MODIFY `id_ruang` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id_semester` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tahun_akademik`
--
ALTER TABLE `tahun_akademik`
  MODIFY `id_tahun` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `upload_kp`
--
ALTER TABLE `upload_kp`
  MODIFY `id_upload` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `upload_pratikum`
--
ALTER TABLE `upload_pratikum`
  MODIFY `id_pratikum` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `upload_quiz`
--
ALTER TABLE `upload_quiz`
  MODIFY `id_quiz` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `upload_tugas`
--
ALTER TABLE `upload_tugas`
  MODIFY `id_tugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
